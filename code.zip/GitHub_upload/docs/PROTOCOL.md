# Experiment protocol

## Main experiment

Two systems (RBTS and RTS79), wind-residual multipliers 1, 1.5 and 2, and conventional-capacity multipliers 1, 0.85 and 0.7 form 18 cells. Every cell and solver status is retained.

The first 720 hours define fixed offline supports. RBTS evaluates days 31, 151 and 271 (72 hours per cell); RTS79 evaluates day 31 (24 hours per cell). Each cell compares deterministic headroom, empirical CVaR, single-TV, static mixture, rolling mixture and the proposed method.

The baseline settings include K=3, epsilon=0.05, 240 representative samples, rho=0.05 for robust components and delta_w=0.05 for outer protection. All exact parameters are in the archived TOML files. The uncertainty multiplier is applied before clipping to physical wind bounds; it is not an exact ratio of observed standard deviations. Demand is known in this controlled experiment. Pure reactive units with zero active-power limits are excluded consistently.

Only optimal solves contribute dispatch metrics. All 5,184 planned method-hour outcomes remain available: 4,464 optimal, 715 infeasible, 3 time-limit and 2 other failures. Infeasibility is different from a time limit or an implementation failure.

Same-hour realized load shedding is the primary energy outcome. The 96-error future perturbation audit is secondary. Repeated days and overlapping error blocks are not independent replications. Report common-hour comparisons together with full-grid coverage.

## Supplement

The fixed 70-variant manifest covers ambiguity radii, mixture weights, K, support budgets, rolling windows, regularization, alternative support selection, divergence geometry, feasibility diagnostics and chronological replay.

Chronological replay evaluates days 32–38 once per hour using the initial 720-hour supports. RBTS uses the central stress cell; RTS79 uses s=1 and conventional-capacity multiplier 0.85. The common physically admissible comparison contains 168 RBTS hours and 107 RTS79 hours. All nominal outcomes remain in `all_hourly.csv`, including hours with insufficient available wind for scheduled absolute curtailment.

Equal numerical divergence radii do not imply equal statistical coverage. The 60-second primary dispatch limit applies to HiGHS LP runs; modified-chi-square experiments use Clarabel defaults. Reported times describe the recorded runs and are not isolated hardware benchmarks.

## Reproduction boundaries

`reproduce.py main` reads the saved grid configurations and changes output destinations only. `reproduce.py supplement` copies the saved manifest into a new output directory and runs the selected group. The original optimization source is unchanged. Input files are checked against their recorded SHA-256 hashes.

`reproduce.py rebuild` recomputes reports from complete archived CSV files; it does not call Julia or a solver. It retains the original missing-value and common-hour conventions. The repository includes the initial diagnostic archive for traceability, but that archive is not substituted for the complete final replay.
