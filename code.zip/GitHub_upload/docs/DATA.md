# Input data

The upload package contains code and numerical result records. Original input files are kept separately because the wind dataset and benchmark inputs have their own provenance and redistribution terms.

The exact 13 required filenames, byte sizes and SHA-256 checksums are in `data_manifest.json`:

- RBTS: `RBTS.m`, `BUS_LOADS.csv`, `SYSTEM_LOADS.csv`, and wind farm site 5 workbook.
- RTS79: `RTS.m`, `BUS_LOADS.csv`, `SYSTEM_LOADS.csv`, and wind farm site 1–6 workbooks.

Keep filenames unchanged. Given an input directory with `RBTS/` and `RTS_79/` subdirectories:

```sh
python reproduce.py install-data --source /path/to/inputs
```

The installer verifies every file before copying and refuses to overwrite different existing data. Rebuilding the recorded reports does not require the original inputs; rerunning optimization does.

## Sources

- Yongbao Chen and Junjie Xu, *Solar and wind power data from the Chinese State Grid Renewable Energy Generation Forecasting Competition*, Scientific Data 9, 577 (2022). [Dataset description and original data links](https://www.nature.com/articles/s41597-022-01696-6).
- Grigg et al., *The IEEE Reliability Test System-1996*, IEEE Transactions on Power Systems 14(3), 1010–1020 (1999). [Original publication](https://doi.org/10.1109/59.780914).
- Josif Figueroa, Kush Bubbar and Greg Young-Morris, *An Open-Source Tool for Composite Power System Reliability Assessment in Julia*, Energies 17(20), 5023 (2024). [Benchmark tool and references](https://www.mdpi.com/1996-1073/17/20/5023).

The local `.m` files use MATPOWER-format benchmark data. This package does not claim that every local benchmark/time-series file is identical to a current upstream release. The checksums identify the exact experiment inputs. A fresh download that differs from these hashes is not silently substituted for the recorded inputs.

Wind and load calendar records are paired by the experiment's documented synthetic alignment. Preserve the input bytes and perform the configured preprocessing in the engine. Do not replace the wind workbooks with cleaned or differently sampled versions when attempting exact replication.
