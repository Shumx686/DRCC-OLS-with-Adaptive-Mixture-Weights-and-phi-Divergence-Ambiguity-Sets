"""Input-severity and computation tables; no optimization-result selection."""
import argparse
from pathlib import Path
import pandas as pd
from report_capacity_wind_stress import LABELS

p=argparse.ArgumentParser()
p.add_argument('--root',required=True,type=Path)
p.add_argument('--report-dir',required=True,type=Path)
args=p.parse_args()
paper=Path(__file__).resolve().parents[3]/'paper'
inputs=pd.read_csv(args.root/'training_conditions.csv')
inputs=inputs[inputs.conventional_capacity_scale==1].sort_values(['system','wind_error_multiplier'])
assert (inputs.load_error_std_mw==0).all(), 'Expected the known-demand control.'
lines=[r'\begin{table}[htbp]',r'\centering',r'\small',
 r'\caption{Measured wind-error severity in the 720-hour offline history. Bounded amplification changes both residual dispersion and mean output; the numerical multiplier $s$ is not an exact standard-deviation ratio.}',
 r'\label{tab:control_input_stats}',r'\begin{tabular}{lrrrr}',r'\toprule',
 r'System & $s$ & Error SD (MW) & Mean wind (MW) & Mean error (MW) \\',r'\midrule']
for _,r in inputs.iterrows():
    lines.append(f'{r.system.upper()} & {r.wind_error_multiplier:g} & {r.net_error_std_mw:.2f} & {r.mean_wind_actual_mw:.2f} & {r.net_error_mean_mw:.2f}'+r' \\')
lines.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}'])
(paper/'auto_control_inputstats.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
hourly=pd.read_csv(args.report_dir/'hourly_audit.csv')
rows=[]
for (system,method),g in hourly.groupby(['system','method'],sort=False):
    times=g.mean_solve_time_sec.dropna()
    rows.append(dict(system=system,method=method,attempts=len(times),planned=len(g),
       mean=times.mean(),median=times.median(),p95=times.quantile(.95),max=times.max()))
pd.DataFrame(rows).to_csv(args.report_dir/'computation.csv',index=False)
lines=[r'\subsection{Computational Performance}\label{subsec:control_computation}',
 r'Table~\ref{tab:control_computation} reports solver time for every attempted dispatch with a finite timing record, including non-optimal solves. The runs use three independent Julia workers, one Julia/BLAS thread per worker, and the same 60 s dispatch limit. Times are solver-reported LP times; data loading, GMM fitting, model construction, and the emergency replay are excluded. The figures therefore quantify the dispatch optimization step rather than end-to-end latency.',
 r'\begin{table}[htbp]',r'\centering',r'\small',
 r'\caption{Dispatch LP solve times (s per attempted hour), including non-optimal attempts.}',
 r'\label{tab:control_computation}',r'\begin{adjustbox}{max width=\textwidth}',r'\begin{tabular}{llrrrr}',r'\toprule',
 r'System & Method & Timed/planned & Mean (s) & Median (s) & P95 (s) \\',r'\midrule']
for r in sorted(rows,key=lambda x:(x['system'],list(LABELS).index(x['method']))):
    lines.append(f"{r['system'].upper()} & {LABELS[r['method']]} & {r['attempts']}/{r['planned']} & {r['mean']:.3f} & {r['median']:.3f} & {r['p95']:.3f}"+r' \\')
lines.extend([r'\bottomrule',r'\end{tabular}',r'\end{adjustbox}',r'\end{table}'])
(paper/'auto_control_computation.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Wrote input and computation tables, with all attempt denominators.')
