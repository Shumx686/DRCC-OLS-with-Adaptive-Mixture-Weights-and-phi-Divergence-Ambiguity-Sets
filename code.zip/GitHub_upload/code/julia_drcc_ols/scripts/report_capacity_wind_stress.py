#!/usr/bin/env python3
"""Report the complete, manifest-defined wind/capacity stress experiment.

No risk-based configuration selection, zero filtering, or failed-solve deletion is
performed.  A missing/failed planned hour makes its primary cell metric missing;
observed partial metrics and solver status remain in the audit CSV files.

Usage:
    python scripts/report_capacity_wind_stress.py --manifest PATH

The JSON manifest contains ``methods`` and ``scenarios`` (``runs`` is an alias).
Each scenario identifies a ``result_dir``, ``wind_uncertainty_multiplier`` (s),
``thermal_capacity_scale`` (c), ``eval_start_offset``, and ``eval_hours``. These
values can also be read from its saved config_used.json. A CSV manifest with one
row per result directory is supported. The report never scans unrelated runs.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import FuncNorm, Normalize
import numpy as np


PROJECT = Path(__file__).resolve().parents[1]
ROOT = PROJECT.parents[1]
PAPER = ROOT / "paper"
METHODS = [
    "deterministic_headroom", "empirical_cvar", "single_tv",
    "mixture_static", "mixture_rolling", "proposed",
]
LABELS = {
    "deterministic": "Deterministic",
    "deterministic_headroom": "Det. + headroom",
    "empirical_cvar": "Empirical CVaR",
    "single_tv": "Single-TV",
    "mixture_static": "Mixture-static",
    "mixture_rolling": "Mixture-rolling",
    "proposed": "Proposed",
}
METRICS = {
    "planned_eens_mwh": ("load_shed", "sum"),
    "emergency_eens_mwh": ("realized_emergency_shed_mwh", "sum"),
    "total_eens_mwh": ("realized_eens_mwh", "sum"),
    "raw_violation_rate": ("realized_violated", "mean"),
    "residual_security_rate": ("realized_residual_slack", "positive_mean"),
    "lolp": ("realized_lolp", "mean"),
    "wind_curtailment_mwh": ("wind_curtailment", "sum"),
    "mean_solve_time_sec": ("solve_time_sec", "mean"),
    "wind_dispatch_shortfall_mwh": ("realized_wind_dispatch_shortfall_mw", "sum"),
    "future_planned_eens_mwh": ("oos_planned_eens_mwh", "sum"),
    "future_emergency_eens_mwh": ("oos_emergency_eens_mwh", "sum"),
    "future_total_eens_mwh": ("oos_eens_mwh", "sum"),
    "future_raw_violation_rate": ("oos_violation_rate", "mean"),
    "future_residual_security_rate": ("oos_residual_security_rate", "mean"),
    "future_lolp": ("oos_lolp", "mean"),
}
CORE = list(METRICS)[:6]
S_KEYS = ("wind_uncertainty_multiplier", "wind_randomness_scale", "wind_error_multiplier",
          "wind_uncertainty_scale", "wind_error_scale", "uncertainty_multiplier", "s")
C_KEYS = ("thermal_capacity_scale", "conventional_capacity_scale", "generator_capacity_scale",
          "capacity_scale", "c")


def finite(value: Any) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def number(value: Any, default: float = math.nan) -> float:
    return float(value) if finite(value) else default


def boolish(value: Any) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes"}


def read_csv(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def lookup(sources: list[dict], keys: tuple[str, ...], default=None):
    for source in sources:
        for key in keys:
            if key in source and source[key] not in (None, ""):
                return source[key]
    return default


def resolve_source(value: str, manifest: Path) -> Path:
    candidate = Path(value)
    if candidate.is_absolute():
        return candidate
    choices = [manifest.parent / candidate, PROJECT / candidate, ROOT / candidate]
    existing = [p.resolve() for p in choices if p.exists()]
    existing = list(dict.fromkeys(existing))
    if len(existing) > 1:
        raise ValueError(f"Ambiguous manifest path {value!r}: {existing}")
    return existing[0] if existing else choices[0].resolve()


def load_manifest(path: Path) -> tuple[dict, list[dict], list[str]]:
    manifest = {"scenarios": read_csv(path)} if path.suffix == ".csv" else json.loads(path.read_text(encoding="utf-8-sig"))
    if isinstance(manifest, list):
        manifest = {"scenarios": manifest}
    scenarios = manifest.get("scenarios", manifest.get("runs", manifest.get("configurations", [])))
    if not scenarios:
        raise ValueError("Manifest must list every planned scenario, including unstarted runs.")
    methods = manifest.get("methods", manifest.get("comparison_methods", METHODS))
    if isinstance(methods, str):
        methods = [part.strip() for part in methods.replace(";", ",").split(",") if part.strip()]
    if len(set(methods)) != len(methods):
        raise ValueError("Duplicate methods in manifest.")
    runs, identities = [], set()
    for idx, row in enumerate(scenarios):
        result_value = lookup([row], ("result_dir", "output_dir", "out_dir", "directory"))
        if result_value is None:
            raise ValueError(f"Scenario {idx} has no explicit result directory.")
        result_dir = resolve_source(str(result_value), path)
        cfg_path = result_dir / "config_used.json"
        config = json.loads(cfg_path.read_text(encoding="utf-8-sig")) if cfg_path.is_file() else {}
        if not config and row.get("config_path"):
            import tomllib
            cfg_path = resolve_source(row["config_path"], path)
            config = tomllib.loads(cfg_path.read_text(encoding="utf-8-sig"))
        sources = [row, config.get("experiment", {}), config.get("data", {}), manifest]
        s = number(lookup(sources, S_KEYS))
        c = number(lookup(sources, C_KEYS))
        offset = number(lookup(sources, ("eval_start_offset", "window_offset", "offset")), 0)
        hours = number(lookup(sources, ("eval_hours", "expected_hours", "hours")))
        if not all(finite(v) for v in (s, c, offset, hours)) or hours <= 0:
            raise ValueError(f"Scenario {idx} lacks finite s, c, offset or positive eval_hours: {row}")
        seed = int(number(lookup(sources, ("random_seed", "seed")), 20260515))
        system = str(lookup(sources, ("system",), "unknown"))
        identity = (system, s, c, int(offset), seed)
        if identity in identities:
            raise ValueError(f"Duplicate planned scenario {identity}; reports never select between repetitions.")
        identities.add(identity)
        runs.append({
            "run_id": row.get("run_id", row.get("case_id", row.get("scenario_name", result_dir.name))),
            "result_dir": result_dir, "config_path": cfg_path,
            "s": s, "c": c, "offset": int(offset), "eval_hours": int(hours),
            "system": system, "seed": seed, "config": config,
            "calendar_days": str(row.get("calendar_days", "")),
            "hour_offsets": config.get("experiment", {}).get("eval_hour_offsets", list(range(1, int(hours) + 1))),
        })
        configured_methods = config.get("experiment", {}).get("comparison_methods", methods)
        if list(configured_methods) != list(methods):
            raise ValueError(f"Method list in {cfg_path} differs from manifest/default methods.")
        if len(runs[-1]["hour_offsets"]) != int(hours):
            raise ValueError(f"eval_hour_offsets length differs from eval_hours in {cfg_path}")
    return manifest, runs, list(methods)


def load_hourly(runs: list[dict], methods: list[str]) -> tuple[list[dict], list[dict]]:
    hourly, sources = [], []
    for run in runs:
        final = run["result_dir"] / "dispatch_results.csv"
        partial = run["result_dir"] / "dispatch_results_partial.csv"
        source = final if final.is_file() else partial
        records = read_csv(source) if source.is_file() else []
        index: dict[tuple[str, int], dict] = {}
        scenario_ids = defaultdict(set)
        for row in records:
            method = str(row.get("method", ""))
            if method not in methods:
                raise ValueError(f"Unregistered method {method!r} in {source}")
            hour = int(number(row.get("eval_index"), -1))
            if not 1 <= hour <= run["eval_hours"]:
                raise ValueError(f"Out-of-plan eval_index={hour} in {source}")
            key = method, hour
            if key in index:
                raise ValueError(f"Multiple configurations for {key} in {source}; no ex-post selection is permitted.")
            index[key] = row
            scenario_ids[method].add(row.get("scenario_id", ""))
        if any(len(ids) > 1 for ids in scenario_ids.values()):
            raise ValueError(f"Multiple scenario_id values for a method in {source}.")
        source_record = {"run_id": run["run_id"], "result_dir": str(run["result_dir"]),
                         "dispatch_path": str(source) if source.is_file() else "",
                         "dispatch_sha256": sha256(source) if source.is_file() else "",
                         "config_path": str(run["config_path"]),
                         "config_sha256": sha256(run["config_path"]) if run["config_path"].is_file() else ""}
        sources.append(source_record)
        for method in methods:
            for hour in range(1, run["eval_hours"] + 1):
                row = index.get((method, hour), {})
                result = {
                    "run_id": run["run_id"], "system": run["system"], "s": run["s"], "c": run["c"],
                    "offset": run["offset"], "seed": run["seed"], "method": method,
                    "eval_index": hour, "time": row.get("time", ""),
                    "status": row.get("status", "MISSING"), "present": bool(row),
                    "has_values": boolish(row.get("has_values", False)),
                    "reliability_samples": int(number(row.get("reliability_samples"), 0)),
                    "rho": number(row.get("rho")), "delta_w": number(row.get("delta_w")),
                    "risk_slack": number(row.get("risk_slack")),
                    "calendar_day": (int(run["config"].get("experiment", {}).get("train_hours", 720))
                                     + run["offset"] + int(run["hour_offsets"][hour - 1]) - 1) // 24 + 1,
                }
                result["optimal"] = result["status"] == "OPTIMAL" and result["has_values"]
                for metric, (field, operation) in METRICS.items():
                    value = number(row.get(field))
                    result[metric] = float(value > 1e-6) if operation == "positive_mean" and finite(value) else value
                result["realized_residual_slack_mw"] = number(row.get("realized_residual_slack"))
                shortfall = result["wind_dispatch_shortfall_mwh"]
                result["wind_shortfall_hour"] = finite(shortfall) and shortfall > 1e-6
                result["wind_deliverability_audited"] = finite(shortfall)
                valid = result["optimal"] and all(finite(result[m]) for m in CORE)
                result["audit_valid"] = valid
                result["decomposition_error_mwh"] = (
                    result["total_eens_mwh"] - result["planned_eens_mwh"] - result["emergency_eens_mwh"]
                    if all(finite(result[m]) for m in CORE[:3]) else math.nan
                )
                if valid and abs(result["decomposition_error_mwh"]) > 1e-5:
                    raise ValueError(f"EENS decomposition mismatch: {run['run_id']} / {method} / {hour}")
                for metric in ("raw_violation_rate", "residual_security_rate", "lolp"):
                    if finite(result[metric]) and not -1e-9 <= result[metric] <= 1 + 1e-9:
                        raise ValueError(f"Invalid probability in {run['run_id']}: {metric}={result[metric]}")
                hourly.append(result)
    return hourly, sources


def aggregate(rows: list[dict], keys: tuple[str, ...]) -> list[dict]:
    groups: dict[tuple, list[dict]] = defaultdict(list)
    for row in rows:
        groups[tuple(row[key] for key in keys)].append(row)
    output = []
    for key, group in groups.items():
        result = dict(zip(keys, key))
        result.update({
            "expected_hours": len(group), "present_hours": sum(r["present"] for r in group),
            "optimal_hours": sum(r["optimal"] for r in group),
            "audited_hours": sum(r["audit_valid"] for r in group),
            "wind_shortfall_hours": sum(r["wind_shortfall_hour"] for r in group),
            "wind_deliverability_audited_hours": sum(r["wind_deliverability_audited"] for r in group),
            "window_count": len({(r["system"], r["s"], r["c"], r["calendar_day"], r["seed"]) for r in group}),
            "statuses": json.dumps(dict(sorted(Counter(r["status"] for r in group).items()))),
        })
        result["complete"] = result["audited_hours"] == len(group)
        result["availability_rate"] = result["optimal_hours"] / len(group)
        for metric, (_, operation) in METRICS.items():
            values = [r[metric] for r in group if r["audit_valid"] and finite(r[metric])]
            observed = (sum(values) if operation == "sum" else sum(values) / len(values)) if values else math.nan
            result["observed_" + metric] = observed
            result[metric] = observed if len(values) == len(group) else math.nan
        output.append(result)
    return output


def paired_comparisons(hourly: list[dict], methods: list[str]) -> list[dict]:
    if "proposed" not in methods:
        return []
    index = {(r["system"], r["s"], r["c"], r["offset"], r["seed"], r["eval_index"], r["method"]): r for r in hourly}
    pairs = defaultdict(list)
    for proposed in hourly:
        if proposed["method"] != "proposed":
            continue
        key = tuple(proposed[k] for k in ("system", "s", "c", "offset", "seed", "eval_index"))
        for baseline in methods:
            if baseline != "proposed":
                pairs[(proposed["system"], proposed["s"], proposed["c"], baseline)].append((proposed, index[key + (baseline,)]))
    output = []
    for (system, s, c, baseline), group in pairs.items():
        valid = [(p, b) for p, b in group if p["audit_valid"] and b["audit_valid"]]
        row = {"system": system, "s": s, "c": c, "baseline": baseline, "expected_pairs": len(group),
               "valid_pairs": len(valid), "complete_pairs": len(group) == len(valid)}
        for metric in CORE:
            deltas = [p[metric] - b[metric] for p, b in valid]
            row["observed_mean_delta_" + metric] = sum(deltas) / len(deltas) if deltas else math.nan
            row["mean_delta_" + metric] = row["observed_mean_delta_" + metric] if len(valid) == len(group) else math.nan
            row["proposed_lower_" + metric] = sum(d < -1e-6 for d in deltas)
            row["ties_" + metric] = sum(abs(d) <= 1e-6 for d in deltas)
            row["proposed_higher_" + metric] = sum(d > 1e-6 for d in deltas)
        output.append(row)
    return output


def fmt(value: Any, digits: int = 2) -> str:
    if not finite(value):
        return "--"
    x = float(value)
    if abs(x) < 5e-7:
        return "0"
    return f"{x:,.{digits}f}"


def plot_grid(cells: list[dict], methods: list[str], stem: Path, future_panel: bool = True) -> None:
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "pdf.fonttype": 42, "ps.fonttype": 42,
                         "axes.titlesize": 10, "axes.labelsize": 9})
    grids = sorted({(r["s"], r["c"]) for r in cells}, key=lambda pair: (-pair[1], pair[0]))
    index = {(r["method"], r["s"], r["c"]): r for r in cells}
    specs = [
        ("total_eens_mwh", "(a) Realized total ENS", "MWh", "YlOrRd", 1),
        (("future_raw_violation_rate", "(b) Future-error raw violation", "%", "Blues", 100) if future_panel else
         ("raw_violation_rate", "(b) Same-hour raw violation", "%", "Blues", 100)),
        ("availability_rate", "(c) Solver availability", "Optimal / planned hours", "Greens", 1),
    ]
    fig, axes = plt.subplots(3, 1, figsize=(7.4, 8.6), constrained_layout=True)
    for ax, (metric, title, unit, cmap_name, factor) in zip(axes.flat, specs):
        data = np.array([[number(index.get((method, s, c), {}).get(metric)) * factor
                          for s, c in grids] for method in methods])
        available = data[np.isfinite(data)]
        vmax = max(float(available.max()), 1e-6) if len(available) else 1.0
        is_energy = metric.endswith("eens_mwh")
        norm = FuncNorm((np.log1p, np.expm1), vmin=0, vmax=vmax) if is_energy and vmax > 20 else Normalize(0, 1 if metric == "availability_rate" else vmax)
        cmap = plt.colormaps[cmap_name].copy()
        cmap.set_bad("#e5e7eb")
        heat = ax.imshow(np.ma.masked_invalid(data), cmap=cmap, norm=norm, aspect="auto")
        ax.set_title(title, loc="left", pad=29, fontweight="bold")
        ax.set_yticks(range(len(methods)), [LABELS.get(m, m) for m in methods])
        ax.tick_params(axis="both", length=0)
        ax.set_xticks(range(len(grids)), [f"{s:g}" for s, _ in grids])
        ax.set_xlabel(r"Wind-error multiplier $s$", labelpad=5)
        for x in range(1, len(grids)):
            if grids[x][1] != grids[x - 1][1]:
                ax.axvline(x - .5, color="#6b7280", linewidth=1.3)
        for c in sorted({c for _, c in grids}, reverse=True):
            positions = [i for i, (_, value) in enumerate(grids) if value == c]
            ax.text(float(np.mean(positions)), -0.76, f"c = {c:g}", ha="center", va="bottom", fontsize=8, clip_on=False)
        for yi, method in enumerate(methods):
            for xi, (s, c) in enumerate(grids):
                cell = index.get((method, s, c), {})
                value = data[yi, xi]
                if metric == "availability_rate":
                    label = f"{cell.get('optimal_hours', 0)}/{cell.get('expected_hours', 0)}"
                elif not finite(value):
                    label = "--"
                elif abs(value) < 5e-7:
                    label = "0"
                elif is_energy:
                    label = f"{value:.0f}" if value >= 100 else (f"{value:.1f}" if value >= .1 else "<0.1")
                else:
                    label = f"{value:.1f}" if value >= .1 else "<0.1"
                color = "white" if finite(value) and norm(value) > .62 else "#111827"
                ax.text(xi, yi, label, ha="center", va="center", fontsize=9.4, color=color,
                        fontweight="bold" if method == "proposed" else "normal")
        ax.set_xticks(np.arange(-.5, len(grids), 1), minor=True)
        ax.set_yticks(np.arange(-.5, len(methods), 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=.5)
        ax.tick_params(which="minor", bottom=False, left=False)
        for spine in ax.spines.values():
            spine.set_visible(False)
        bar = fig.colorbar(heat, ax=ax, fraction=.027, pad=.025, shrink=.88)
        if isinstance(norm, FuncNorm):
            powers = [10.0 ** power for power in range(-1, 8) if 10.0 ** power < .65 * vmax]
            ticks = [0] + powers + [vmax]
            bar.set_ticks(ticks)
            bar.set_ticklabels([f"{tick:g}" if tick < 1000 else f"{tick / 1000:.1f}k" for tick in ticks])
        bar.ax.tick_params(labelsize=7)
        bar.set_label(unit + ("; log(1+x) color" if isinstance(norm, FuncNorm) else ""), fontsize=7)
    stem.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight", metadata={"Title": "Complete wind uncertainty and conventional capacity stress grid"})
    fig.savefig(stem.with_suffix(".png"), dpi=190, bbox_inches="tight")
    plt.close(fig)


def plot_paired(pairs: list[dict], methods: list[str], stem: Path) -> None:
    systems = sorted({row["system"] for row in pairs})
    baselines = [method for method in methods if method != "proposed"]
    grids = sorted({(r["s"], r["c"]) for r in pairs}, key=lambda pair: (-pair[1], pair[0]))
    fig, axes = plt.subplots(len(systems), 2, figsize=(11.5, 3.2 * len(systems)),
                             squeeze=False, constrained_layout=True)
    for sy, system in enumerate(systems):
        index = {(r["baseline"], r["s"], r["c"]): r for r in pairs if r["system"] == system}
        for col, (metric, label) in enumerate((("total_eens_mwh", "total ENS"),
                                              ("emergency_eens_mwh", "emergency ENS"))):
            ax = axes[sy, col]
            data = np.array([[number(index.get((m, s, c), {}).get("observed_mean_delta_" + metric))
                              for s, c in grids] for m in baselines])
            valid = np.abs(data[np.isfinite(data)])
            bound = max(float(valid.max()), .01) if len(valid) else 1
            cmap = plt.colormaps["RdBu_r"].copy()
            cmap.set_bad("#e5e7eb")
            heat = ax.imshow(np.ma.masked_invalid(data), vmin=-bound, vmax=bound, cmap=cmap, aspect="auto")
            ax.set_title(f"{system.upper()}: paired mean difference in {label}", loc="left", fontweight="bold", fontsize=10, pad=32)
            ax.set_yticks(range(len(baselines)), [LABELS.get(m, m) for m in baselines])
            ax.set_xticks(range(len(grids)), [f"{s:g}" for s, _ in grids])
            ax.set_xlabel(r"Wind-error multiplier $s$")
            ax.tick_params(length=0)
            for c in sorted({c for _, c in grids}, reverse=True):
                positions = [i for i, (_, value) in enumerate(grids) if value == c]
                ax.text(float(np.mean(positions)), -.73, f"c = {c:g}", ha="center", va="bottom", fontsize=8, clip_on=False)
            for x in range(1, len(grids)):
                if grids[x][1] != grids[x - 1][1]:
                    ax.axvline(x - .5, color="#6b7280", linewidth=1.2)
            for y, method in enumerate(baselines):
                for x, (s, c) in enumerate(grids):
                    row = index.get((method, s, c), {})
                    value = data[y, x]
                    label_value = fmt(value, 1) if finite(value) else "--"
                    label_value += f"\n{row.get('valid_pairs', 0)}/{row.get('expected_pairs', 0)}"
                    color = "white" if finite(value) and abs(value) / bound > .60 else "#111827"
                    ax.text(x, y, label_value, ha="center", va="center", fontsize=7.2, color=color)
            for spine in ax.spines.values():
                spine.set_visible(False)
            bar = fig.colorbar(heat, ax=ax, fraction=.025, pad=.025)
            bar.set_label("MWh per paired hour", fontsize=8)
            bar.ax.tick_params(labelsize=7)
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=190, bbox_inches="tight")
    plt.close(fig)


def latex_escape(value: Any) -> str:
    return str(value).replace("\\", r"\textbackslash{}").replace("_", r"\_").replace("%", r"\%")


def write_system_latex(runs: list[dict], methods: list[str], cells: list[dict], totals: list[dict], pairs: list[dict], system: str, primary_system: str) -> str:
    index = {r["method"]: r for r in totals}
    expected = sum(r["eval_hours"] for r in runs)
    windows = sorted({int(day) for r in runs for day in r["calendar_days"].split(";") if day})
    sv = ",".join(f"{x:g}" for x in sorted({r["s"] for r in runs}))
    cv = ",".join(f"{x:g}" for x in sorted({r["c"] for r in runs}, reverse=True))
    valid = sum(r["audited_hours"] for r in totals)
    lines = [
        f"\\paragraph{{{system.upper()} results.}}",
        f"The nine combinations of $s\\in\\{{{sv}\\}}$ and $c\\in\\{{{cv}\\}}$ "
        f"cover calendar days {', '.join(map(str, windows))}, yielding {expected} operating exposures per method. "
        "Forecast conditions, realized errors, and ambiguity budgets are shared across methods within each cell. "
        f"Of the {expected * len(methods)} scheduled method-hour problems, {valid} yield optimal dispatches "
        "with complete replay metrics. The tables report energy and security outcomes, while the figures "
        "show their variation across wind and capacity levels. Complete-grid totals are reported where "
        "all scheduled hours are available.", "",
        r"\begin{table}[htbp]", r"\centering", r"\small",
        f"\\caption{{{system.upper()} complete-grid chronological replay. ENS values sum the scheduled test exposures; security rates average the same hourly realizations. Missing complete-grid metrics are denoted by --.}}",
        f"\\label{{tab:capacity_wind_stress_{system}}}", r"\resizebox{\textwidth}{!}{%",
        r"\begin{tabular}{lrrrrrr}", r"\toprule",
        r"Method & Planned ENS & Emergency ENS & Total ENS & Raw viol. & Residual viol. & Optimal/planned \\",
        r" & (MWh) & (MWh) & (MWh) & (\%) & (\%) & (hours) \\", r"\midrule",
    ]
    for method in methods:
        r = index[method]
        values = [fmt(r[key]) for key in CORE[:3]]
        values += [fmt(100 * r[key]) for key in CORE[3:5]]
        values += [f"{r['optimal_hours']}/{r['expected_hours']}"]
        lines.append(latex_escape(LABELS.get(method, method)) + " & " + " & ".join(values) + r" \\")
    figure = "fig_capacity_wind_stress" if system == primary_system else f"fig_capacity_wind_stress_{system}"
    lines += [r"\bottomrule", r"\end{tabular}}", r"\end{table}", "",
              r"\begin{figure}[p]", r"\centering",
              f"\\includegraphics[width=\\textwidth,height=0.80\\textheight,keepaspectratio]{{auto_figures/{figure}.pdf}}",
              f"\\caption{{{system.upper()} complete wind--capacity grid: realized total ENS, future-error raw violation frequency (secondary audit), and solver availability. Same-hour security is reported in Table~\\ref{{tab:capacity_wind_stress_{system}}}. Gray cells denote incomplete replay; zeros are retained. ENS annotations are MWh, with logarithmic color scaling where needed.}}",
              f"\\label{{fig:capacity_wind_stress_{system}}}", r"\end{figure}", ""]
    proposed = index.get("proposed")
    if proposed and proposed["complete"]:
        lines.append(f"Across the full grid, the proposed model records planned, realized emergency, and total ENS "
                     f"of {fmt(proposed['planned_eens_mwh'])}, {fmt(proposed['emergency_eens_mwh'])}, and "
                     f"{fmt(proposed['total_eens_mwh'])} MWh, respectively, with raw and residual security violation "
                     f"rates of {fmt(100 * proposed['raw_violation_rate'])}\\% and {fmt(100 * proposed['residual_security_rate'])}\\%.")
        robust = [m for m in methods if m not in ("proposed", "deterministic", "deterministic_headroom") and index[m]["complete"]]
        tied = [m for m in robust if all(abs(proposed[key] - index[m][key]) <= 1e-5 for key in CORE[:5])]
        if tied:
            lines.append("The complete-grid energy and security metrics coincide with " +
                         ", ".join(latex_escape(LABELS[m]) for m in tied) +
                         "; this experiment therefore does not establish a strict advantage over those methods.")
        headroom = index.get("deterministic_headroom")
        if headroom and headroom["complete"]:
            dt = proposed["total_eens_mwh"] - headroom["total_eens_mwh"]
            de = proposed["emergency_eens_mwh"] - headroom["emergency_eens_mwh"]
            lines.append(f"Relative to the deterministic headroom baseline, the signed proposed-minus-baseline "
                         f"differences are {fmt(dt)} MWh in total ENS and {fmt(de)} MWh in realized emergency ENS. "
                         "The decomposition relates preventive reserve placement to the correction required after wind errors are observed.")
    else:
        lines.append("The proposed model is evaluated on its successfully solved hours in the common-hour comparison below. "
                     "The availability panel identifies the stress levels at which the present configuration supplies an optimal dispatch.")
    lines += ["", r"\begin{table}[htbp]", r"\centering", r"\small",
              f"\\caption{{{system.upper()} auxiliary diagnostics on available numerical replays. Excess curtailment is scheduled curtailment exceeding observed wind availability. Future-block EENS is a separate perturbation audit.}}",
              f"\\label{{tab:capacity_wind_stress_diagnostics_{system}}}", r"\resizebox{\textwidth}{!}{%",
              r"\begin{tabular}{lrrrrr}", r"\toprule",
              r"Method & Excess-curtailment hours & Excess curtailment & Future EENS & Future raw viol. & Audited/planned \\",
              r" & (hours) & (MWh) & (MWh) & (\%) & (hours) \\", r"\midrule"]
    for method in methods:
        row = index[method]
        values = [str(row["wind_shortfall_hours"]), fmt(row["observed_wind_dispatch_shortfall_mwh"]),
                  fmt(row["observed_future_total_eens_mwh"]), fmt(100 * row["observed_future_raw_violation_rate"]),
                  f"{row['audited_hours']}/{row['expected_hours']}"]
        lines.append(latex_escape(LABELS.get(method, method)) + " & " + " & ".join(values) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}}", r"\end{table}", ""]
    return "\n".join(lines) + "\n"


def write_latex(path: Path, runs: list[dict], methods: list[str], cells: list[dict], totals: list[dict], pairs: list[dict]) -> None:
    systems = sorted({r["system"] for r in runs})
    lines = ["% Generated by report_capacity_wind_stress.py; do not edit numerical rows manually.",
             r"\subsection{Wind-Error Variability and Conventional-Capacity Stress}", "",
             "The results combine same-hour dispatch replay with the future-error perturbation audit "
             "defined in Section~\\ref{subsec:audit_metrics}. Realized ENS describes unserved energy on "
             "the scheduled trajectory; the secondary audit examines security under subsequent error conditions.", ""]
    for system in systems:
        lines.append(write_system_latex([r for r in runs if r["system"] == system], methods,
                                       [r for r in cells if r["system"] == system],
                                       [r for r in totals if r["system"] == system],
                                       [r for r in pairs if r["system"] == system], system, systems[0]))
    lines += ["Paired component comparisons are reported next; detailed proposed-versus-baseline plots and all hourly values are retained in the reproducibility files.", ""]
    path.write_text("\n".join(lines), encoding="utf-8")


def write_markdown(path: Path, manifest_path: Path, runs: list[dict], methods: list[str],
                   totals: list[dict], cells: list[dict], pairs: list[dict]) -> None:
    lines = ["# Wind uncertainty / conventional capacity stress report", "",
             f"Manifest: `{manifest_path}`", f"Manifest SHA-256: `{sha256(manifest_path)}`", "",
             "This report uses only the explicitly listed planned runs. It does not choose a best ambiguity radius, "
             "select favorable windows, suppress zero cells, or discard failed dispatches. The saved manifest and "
             "configuration files define the comparison set.", "",
             "## Complete planned coverage", "",
             "| System | Method | Optimal/planned hours | Audited/planned hours | Planned ENS (MWh) | Realized emergency ENS (MWh) | Realized total ENS (MWh) | Raw violation (%) | Residual violation (%) |",
             "|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in totals:
        vals = [r["system"].upper(), LABELS.get(r["method"], r["method"]), f"{r['optimal_hours']}/{r['expected_hours']}",
                f"{r['audited_hours']}/{r['expected_hours']}"]
        vals += [fmt(r[k]) for k in CORE[:3]] + [fmt(100 * r[k]) for k in CORE[3:5]]
        lines.append("| " + " | ".join(vals) + " |")
    lines += ["", "## Definitions and interpretation", "",
              "- Each dispatch interval is one hour. Planned ENS equals scheduled shedding MW times one hour. "
              "Realized emergency ENS replays the same hour's realized error; realized total ENS is their sum. "
              "CSV `*_eens_mwh` names retain the engine's historical naming, but unprefixed values here are realized ENS. "
              "Only `future_*` metrics average over the next 96 errors and have the interpretation of a perturbation-audit EENS.",
              "- ENS totals describe the planned finite stress exposures, not annual EENS. Adjacent future audit "
              "blocks can overlap. No independence-based confidence intervals or statistical significance claims are made.",
              "- Raw violation is the chronological frequency of any generator/reserve/line violation before emergency correction. "
              "Residual security is the frequency of remaining positive security slack after corrective load shedding.",
              "- OPTIMAL plus available primal values defines a solved dispatch. Complete reliability metrics are "
              "additionally required for the primary energy and security comparisons. A failed or missing planned "
              "hour makes the corresponding complete-cell metric missing; `observed_*` fields retain partial data.",
              "- A positive corrective residual means the emergency model has not restored all security constraints. "
              "ENS and residual security must therefore be interpreted together. The wind-deliverability diagnostic "
              "additionally counts hours and energy where scheduled wind curtailment exceeds realized wind availability; these "
              "are not certified as physically feasible merely because residual generator/line slack is zero.",
              "- `paired_comparisons.csv` reports proposed-minus-baseline differences on identical hours; negative "
              "differences favor the proposed method. Primary differences require every planned pair. Counts of "
              "lower/tied/higher results preserve all ties, including common zeros.",
              "- Figure colors for ENS use log(1+x) only where needed; annotations and CSV values remain in MWh. "
              "Methods appear in separate rows so overlapping curves cannot hide equal outcomes.", "",
              "## Reproduction", "", "```powershell",
              f'python "{PROJECT / "scripts" / "report_capacity_wind_stress.py"}" --manifest "{manifest_path}"',
              "```", "", "## Planned runs", "",
              "| Run | Wind multiplier s | Capacity c | Calendar days | Planned hours | Seed |",
              "|---|---:|---:|---:|---:|---:|"]
    for r in runs:
        lines.append(f"| {r['run_id']} | {r['s']:g} | {r['c']:g} | {r['calendar_days']} | {r['eval_hours']} | {r['seed']} |")
    lines += ["", "## Retained files", "",
              "- `hourly_audit.csv`: every planned method-hour, including missing rows and exact source statuses.",
              "- `window_summary.csv`: every fixed window by method.",
              "- `grid_summary.csv`: all wind/capacity cells by method.",
              "- `method_summary.csv`: planned full-grid exposure by method.",
              "- `paired_comparisons.csv`: paired deltas and lower/tied/higher counts, with planned denominators.",
              "- `provenance.json`: source hashes and reporting definitions.", ""]
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=PROJECT / "results" / "capacity_wind_stress_report")
    parser.add_argument("--paper-dir", type=Path, default=PAPER)
    args = parser.parse_args()
    manifest_path = args.manifest.resolve()
    manifest, runs, methods = load_manifest(manifest_path)
    hourly, sources = load_hourly(runs, methods)
    windows = aggregate(hourly, ("system", "run_id", "s", "c", "offset", "calendar_day", "seed", "method"))
    cells = aggregate(hourly, ("system", "s", "c", "method"))
    totals = aggregate(hourly, ("system", "method"))
    pairs = paired_comparisons(hourly, methods)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.paper_dir.mkdir(parents=True, exist_ok=True)
    for name, rows in (("hourly_audit", hourly), ("window_summary", windows), ("grid_summary", cells),
                       ("method_summary", totals), ("paired_comparisons", pairs)):
        write_csv(args.output_dir / f"{name}.csv", rows)
    systems = sorted({r["system"] for r in runs})
    for system in systems:
        stem = "fig_capacity_wind_stress" if system == systems[0] else f"fig_capacity_wind_stress_{system}"
        plot_grid([row for row in cells if row["system"] == system], methods, args.paper_dir / "auto_figures" / stem)
        plot_grid([row for row in cells if row["system"] == system], methods,
                  args.output_dir / f"grid_same_hour_{system}", future_panel=False)
    plot_paired(pairs, methods, args.paper_dir / "auto_figures" / "fig_capacity_wind_stress_paired")
    write_latex(args.paper_dir / "auto_capacity_wind_stress.tex", runs, methods, cells, totals, pairs)
    write_markdown(args.output_dir / "REPORT.md", manifest_path, runs, methods, totals, cells, pairs)
    provenance = {"generated_at_utc": datetime.now(timezone.utc).isoformat(),
                  "manifest_path": str(manifest_path), "manifest_sha256": sha256(manifest_path),
                  "report_script_sha256": sha256(Path(__file__)), "methods": methods,
                  "planned_runs": len(runs), "planned_method_hours": len(hourly),
                  "optimal_method_hours": sum(r["optimal"] for r in hourly),
                  "audited_method_hours": sum(r["audit_valid"] for r in hourly),
                  "selection_rule": "All manifest entries; one registered configuration per method and run; zeros retained",
                  "missing_rule": "Incomplete primary aggregates are NaN; observed partial metrics retained separately",
                  "sources": sources}
    (args.output_dir / "provenance.json").write_text(json.dumps(provenance, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({key: provenance[key] for key in ("planned_runs", "planned_method_hours", "optimal_method_hours", "audited_method_hours")}, indent=2))
    print(f"Report: {args.output_dir / 'REPORT.md'}")
    print(f"LaTeX: {args.paper_dir / 'auto_capacity_wind_stress.tex'}")


if __name__ == "__main__":
    main()
