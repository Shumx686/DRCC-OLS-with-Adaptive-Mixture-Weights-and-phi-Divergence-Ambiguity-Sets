#!/usr/bin/env julia

project_dir = normpath(joinpath(@__DIR__, ".."))
push!(LOAD_PATH, joinpath(project_dir, "src"))

using DRCCOLS

config_path = length(ARGS) >= 1 ? abspath(ARGS[1]) : joinpath(project_dir, "config", "small.toml")
DRCCOLS.run_experiment(config_path)
