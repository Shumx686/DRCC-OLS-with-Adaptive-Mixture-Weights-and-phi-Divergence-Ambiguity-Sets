"""Audit the complete predeclared grid without selecting favorable cells."""
from pathlib import Path
import csv
import json
import math
import sys

ROOT = Path(__file__).resolve().parents[1] / "results" / "capacity_wind_stress_20260908"
if len(sys.argv) > 1:
    ROOT = Path(sys.argv[1]).resolve()
manifest = list(csv.DictReader((ROOT / "manifest.csv").open(encoding="utf-8-sig")))
rows = []
availability = []
for cell in manifest:
    file = Path(cell["result_dir"]) / "dispatch_results.csv"
    if not file.exists():
        availability.append({"case_id": cell["case_id"], "status": "missing_complete_output"})
        continue
    loaded = list(csv.DictReader(file.open(encoding="utf-8-sig")))
    expected = 6 * int(cell["eval_hours"])
    availability.append({"case_id": cell["case_id"], "status": "complete" if len(loaded) == expected else "wrong_row_count", "rows": len(loaded), "expected": expected})
    for row in loaded:
        row.update(system=cell["system"], s=float(cell["wind_error_multiplier"]), c=float(cell["conventional_capacity_scale"]))
        rows.append(row)
groups = {}
for row in rows:
    key = (row["system"], row["s"], row["method"], row["time"])
    groups.setdefault(key, []).append(row)
issues = []
comparisons = 0
for key, group in groups.items():
    ordered = sorted(group, key=lambda row: -row["c"])
    for loose, tight in zip(ordered, ordered[1:]):
        # All configured minimum generation limits are zero. Thus reducing Pmax
        # shrinks the feasible set while leaving data/support/cost unchanged.
        if loose["status"] == "INFEASIBLE" and tight["status"] == "OPTIMAL":
            issues.append({"kind": "feasibility_non_nested", "key": key, "loose_c": loose["c"], "tight_c": tight["c"]})
        if loose["status"] == tight["status"] == "OPTIMAL":
            comparisons += 1
            a, b = float(loose["objective"]), float(tight["objective"])
            tolerance = max(1e-5, 1e-6 * max(abs(a), abs(b)))
            if b < a - tolerance:
                issues.append({"kind": "objective_decreased_when_capacity_tightened", "key": key, "loose_c": loose["c"], "tight_c": tight["c"], "loose_objective": a, "tight_objective": b})
result = {"manifest_cells": len(manifest), "availability": availability,
          "optimal_adjacent_capacity_comparisons": comparisons, "issues": issues,
          "scope": "Capacity monotonicity applies because all scenario Pmin values are zero. TIME_LIMIT and other failures are retained and are not declared mathematical infeasibility."}
(ROOT / "grid_consistency.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps({"complete_cells": sum(x["status"] == "complete" for x in availability), "expected_cells": len(manifest), "optimal_comparisons": comparisons, "issues": len(issues)}))
