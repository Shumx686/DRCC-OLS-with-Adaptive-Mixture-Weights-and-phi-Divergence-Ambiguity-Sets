"""Summarize every declared supplementary variant and create publication figures."""
from pathlib import Path
import json
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

parser=argparse.ArgumentParser()
parser.add_argument('--partial',action='store_true')
args=parser.parse_args()
project=Path(__file__).resolve().parents[1]
root=project/'results/review_supplement_20260913'
paper=project.parents[1]/'paper'
manifest=json.loads((root/'manifest.json').read_text())
frames=[]
for mode,variants in manifest.items():
    p=root/(mode+'.csv')
    if not p.exists() and args.partial: p=root/(mode+'_partial.csv')
    if not p.exists():
        if args.partial: continue
        raise RuntimeError('Incomplete job: '+mode)
    a=pd.read_csv(p)
    if not args.partial:
        expected={(v['id'],t) for v in variants for t in v['hours']}
        observed=set(zip(a.variant,a.t))
        assert observed==expected and len(a)==len(expected),(mode,len(a),len(expected))
    frames.append(a)
d=pd.concat(frames,ignore_index=True)
common_hours={}
if 'wind_shortfall' in d:
    for sy,g in d[d.family=='chronological'].groupby('system'):
        admissible=(g.status=='OPTIMAL')&g.wind_shortfall.le(1e-6)
        h=g.assign(admissible=admissible).groupby('t').admissible.agg(['all','size'])
        common_hours[sy]=set(h.index[h['all']&(h['size']==3)])
rows=[]
for name,a in d.groupby('variant',sort=False):
    b=a[(a.status=='OPTIMAL')&np.isfinite(a.total_ens)]
    optimal=len(b)
    is_chron=a.iloc[0].family=='chronological' and a.iloc[0].system in common_hours
    if is_chron: b=b[b.t.isin(common_hours[a.iloc[0].system])]
    row=a.iloc[0][['variant','family','system','s','c','K','rho','delta','theta','window','kappa','budget','selection','method','divergence','tie','line_factor','q']].to_dict()
    row.update(attempts=len(a),optimal=optimal,common_hours=len(b),ens=b.total_ens.sum() if len(b)>0 and (is_chron or len(b)==len(a)) else np.nan,
        planned=b.planned_ens.sum() if len(b)>0 and (is_chron or len(b)==len(a)) else np.nan,
        emergency=b.emergency_ens.sum() if len(b)>0 and (is_chron or len(b)==len(a)) else np.nan,
        raw=100*b.raw_violation.mean(),residual=100*b.residual_violation.mean(),
        future_eens=b.future_eens.sum(min_count=1) if len(b)==len(a) else np.nan,
        future_raw=100*b.future_raw.mean(),future_residual=100*b.future_residual.mean(),
        solve_mean=b.solve_sec.mean(),solve_p95=b.solve_sec.quantile(.95))
    rows.append(row)
a=pd.DataFrame(rows)
a.to_csv(root/('partial_summary.csv' if args.partial else 'summary.csv'),index=False)
if args.partial:
    print(a[['variant','optimal','attempts','ens','raw','future_raw']].to_string(index=False))
    raise SystemExit
d.to_csv(root/'all_hourly.csv',index=False)
chron=d[d.family=='chronological']
physics=chron.assign(admissible=(chron.status=='OPTIMAL')&chron.wind_shortfall.le(1e-6))
physics=physics.groupby(['system','variant','day']).agg(hours=('t','size'),admissible=('admissible','sum'),max_wind_shortfall=('wind_shortfall','max')).reset_index()
physics.to_csv(root/'chronological_physical_validity.csv',index=False)
chron=chron.copy()
chron['common_admissible']=[t in common_hours[sy] for sy,t in zip(chron.system,chron.t)]
chron.loc[~chron.common_admissible,['total_ens','raw_violation','residual_violation']]=np.nan
daily=chron.groupby(['system','variant','day']).agg(hours=('t','size'),optimal=('status',lambda x:(x=='OPTIMAL').sum()),common_hours=('common_admissible','sum'),ens=('total_ens',lambda x:x.sum(min_count=1)),raw=('raw_violation','mean'),residual=('residual_violation','mean')).reset_index()
daily.to_csv(root/'chronological_daily.csv',index=False)
plt.rcParams.update({'font.family':'STIXGeneral','font.size':10,'axes.labelsize':10,'axes.titlesize':11,
    'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#98a2ad',
    'axes.linewidth':.6,'xtick.color':'#34424c','ytick.color':'#34424c','text.color':'#24343f'})
figdir=paper/'auto_figures'
def save(fig,name):
    for ext in ['pdf','png']: fig.savefig(figdir/(name+'.'+ext),dpi=240,bbox_inches='tight',pad_inches=.06)
    plt.close(fig)
colors=['#536b98','#a0825f','#187d79']
fig,axes=plt.subplots(2,2,figsize=(7.1,5.1),layout='constrained')
for ri,(family,xcol,title) in enumerate([('rho','rho',r'Local radius $\rho$'),('delta','delta',r'Weight radius $\delta_w$')]):
    for ci,(metric,ylab) in enumerate([('ens','Realized ENS (MWh)'),('future_raw','Future raw violations (%)')]):
        ax=axes[ri,ci]
        for method,label,color in [('single','Single-TV',colors[0]),('mixture','Proposed',colors[2])]:
            b=a[(a.family==family)&(a.method==method)].sort_values(xcol)
            if len(b): ax.plot(b[xcol],b[metric],marker='o',ms=4,lw=1.4,color=color,label=label)
        ax.axvline(.05,color='#b9bec4',ls=':',lw=.9)
        ax.set(xlabel=title,ylabel=ylab)
        ax.set_title(('a','b','c','d')[ri*2+ci],loc='left',fontweight='bold')
        ax.grid(axis='y',alpha=.15)
axes[0,0].legend(frameon=False,fontsize=9)
save(fig,'review_radius_sensitivity')
fig,axes=plt.subplots(1,2,figsize=(7.1,2.85),layout='constrained')
for ax,sy,title in zip(axes,['rbts','rts79'],['a   RBTS: daily energy','b   RTS79: physical replay coverage']):
    if sy=='rts79':
        counts=[len(common_hours[sy]&set(range((day-1)*24+1,day*24+1))) for day in range(32,39)]
        ax.bar(range(32,39),counts,width=.6,color='#788ba8')
        ax.axhline(24,color='#b9bec4',ls=':',lw=.9)
        for day,n in zip(range(32,39),counts): ax.text(day,n+.4,str(n),ha='center',fontsize=9)
        ax.set(title=title,xlabel='Held-out calendar day',ylabel='Common admissible hours',ylim=(0,27))
        ax.set_xticks(range(32,39));ax.set_yticks([0,6,12,18,24])
        continue
    for method,label,col in zip(['single','rolling','protected'],['Single-TV','Rolling mixture','Proposed'],colors):
        b=daily[(daily.system==sy)&(daily.variant==f'chron_{sy}_{method}')]
        ax.plot(b.day,b.ens,marker='o',ms=3,lw=1.4,color=col,label=label)
    ax.set(title=title,xlabel='Held-out calendar day',ylabel='Daily realized ENS (MWh)')
    ax.set_xticks(range(32,39));ax.grid(axis='y',alpha=.15)
axes[0].legend(frameon=False,fontsize=8)
save(fig,'review_chronological')
def fmt(v): return '--' if not np.isfinite(v) else f'{0. if abs(v)<.005 else v:,.2f}'
def table(caption,label,columns,body):
    return '\n'.join([r'\begin{table}[htbp]',r'\centering\small',r'\caption{'+caption+'}',r'\label{'+label+'}',r'\begin{adjustbox}{max width=\textwidth}',r'\begin{tabular}{l'+'r'*(len(columns)-1)+'}',r'\toprule',' & '.join(columns)+r' \\',r'\midrule',*body,r'\bottomrule',r'\end{tabular}',r'\end{adjustbox}',r'\end{table}'])+'\n'
body=[]
for name,label in [('static','Static'),('historical',r'Historical only ($\theta=0$)'),('predictive',r'Predictive only ($\theta=1$)'),('blended',r'Blended ($\theta=0.5$)'),('protected','Blended + weight protection')]:
    r=a[a.variant=='weights_'+name].iloc[0]
    body.append(' & '.join([label,fmt(r.ens),fmt(r.future_raw)])+r' \\')
(paper/'auto_review_weights.tex').write_text(table(r'Weight-component comparison on RBTS day 31 at $(s,c)=(1.5,0.85)$. The first four variants have $\delta_w=0$; the last uses $\delta_w=0.05$. All share $\rho_k=0.05$ and the same local supports, with zero actual raw and residual violations.','tab:review_weights',['Weight center','ENS (MWh)',r'Future raw (\%)'],body),encoding='utf-8')
body=[]
for sy in ['rbts','rts79']:
    if sy=='rts79': body.append(r'\midrule')
    for method,label in [('single','Single-TV'),('rolling','Rolling'),('protected','Proposed')]:
        r=a[a.variant==f'chron_{sy}_{method}'].iloc[0]
        body.append(' & '.join([sy.upper()+' '+label,f'{r.common_hours}/{r.attempts}',fmt(r.ens),fmt(r.emergency),fmt(r.raw),fmt(r.residual)])+r' \\')
(paper/'auto_review_chronology.tex').write_text(table('Chronological replay on days 32--38: RBTS $(s,c)=(1.5,0.85)$ and RTS79 $(s,c)=(1,0.85)$. Within each system, energy and security use the same hours with optimal dispatches and scheduled curtailment no greater than actual wind for all three methods. The denominator retains all 168 prescribed hours.','tab:review_chronology',['System / method','Common hours','ENS (MWh)','Emergency',r'Raw (\%)',r'Residual (\%)'],body),encoding='utf-8')
body=[]
for rule,label in [('posterior','Posterior-ranked'),('distance_stratified','Distance-stratified'),('full','Full support')]:
    for method in ['static','mixture']:
        r=a[a.variant==f'support_{rule}_{method}'].iloc[0]
        body.append(' & '.join([label+' / '+('static' if method=='static' else 'proposed'),str(sum(map(int,r.q.split(';')))),fmt(r.ens),fmt(r.future_raw),fmt(r.solve_mean)])+r' \\')
(paper/'auto_review_support.tex').write_text(table('Support-selection comparison on the same RBTS day and central stress condition. Local sample counts are matched for the first two rules; full support retains all hard-assigned training observations.','tab:review_support',['Selection / method',r'$\sum_k q_k$','ENS (MWh)',r'Future raw (\%)','Mean solve (s)'],body),encoding='utf-8')
body=[]
for sy,stress in [('rbts',1.),('rbts',1.5),('rts79',1.)]:
    if body: body.append(r'\midrule')
    for dv,label in [('empirical','Empirical'),('tv','TV'),('chi2',r'$\chi^2$')]:
        r=a[a.variant==f'geometry_{sy}_{stress}_{dv}'].iloc[0]
        body.append(' & '.join([sy.upper()+f' $s={stress:g}$ / '+label,f'{r.optimal}/{r.attempts}',fmt(r.ens),fmt(r.future_raw),fmt(r.solve_mean)])+r' \\')
(paper/'auto_review_geometry.tex').write_text(table(r'Finite-support geometry comparison on six evenly spaced hours of day 31. The RBTS conditions have $c=1$ and $0.85$, respectively; RTS79 has $c=0.85$. TV and modified $\chi^2$ use local and weight radii 0.05; equal numerical radii do not imply equal confidence coverage.','tab:review_geometry',['System / geometry','Optimal','ENS (MWh)',r'Future raw (\%)','Mean solve (s)'],body),encoding='utf-8')
body=[]
for family,label in [('K','$K$'),('budget','Support cap'),('window','$T_w$'),('kappa',r'$\kappa$'),('tie',r'$\sigma$')]:
    b=a[a.family==family]
    vals=r'$10^{-7},10^{-6},10^{-5}$' if family=='tie' else ', '.join(f'{x:g}' for x in sorted(b[family].unique()))
    body.append(' & '.join([label,vals,fmt(b.ens.min())+'--'+fmt(b.ens.max()),fmt(b.future_raw.min())+'--'+fmt(b.future_raw.max())])+r' \\')
(paper/'auto_review_auxiliary.tex').write_text(table('Additional one-factor sensitivity ranges on RBTS day 31 at $(s,c)=(1.5,0.85)$. Every prescribed value is included in the supplementary archive.','tab:review_auxiliary',['Parameter','Values','ENS range (MWh)',r'Future raw range (\%)'],body),encoding='utf-8')
print('Complete:',len(d),'hourly attempts;',len(a),'variants')
