using TOML, Dates, CSV, DataFrames, JSON
project = normpath(joinpath(@__DIR__, ".."))
root = joinpath(project, "results", "wind_control_final_20260911")
mkpath(root)
mode = isempty(ARGS) ? "prepare" : ARGS[1]

if mode == "prepare"
    manifest = DataFrame()
    # This complete grid and these calendar windows are fixed before outcomes.
    for system in ("rts79", "rbts"), s in (1.0, 1.5, 2.0), c in (1.0, 0.85, 0.7)
        case_id = "$(system)_s$(round(Int,100*s))_c$(round(Int,100*c))"
        cfg = TOML.parsefile(joinpath(project, "config", system == "rts79" ? "rts79_comparison.toml" : "comparison.toml"))
        cfg["name"] = "capacity_wind_stress_" * case_id
        cfg["data"]["error_scale"] = 1.0
        cfg["data"]["load_error_mode"] = "known_forecast"
        cfg["data"]["exclude_zero_active_power_units"] = true
        cfg["data"]["wind_error_multiplier"] = s
        cfg["data"]["conventional_capacity_scale"] = c
        exp = cfg["experiment"]
        exp["comparison_methods"][1] = "deterministic_headroom"
        exp["solver_time_limit_sec"] = 60.0
        days = system == "rts79" ? [31] : [31, 151, 271]
        offsets = [24 * (d - 31) + h for d in days for h in 1:24]
        exp["eval_hour_offsets"] = offsets
        exp["eval_hours"] = length(offsets)
        exp["output_subdir"] = joinpath(basename(root), case_id)
        exp["experiment_protocol"] = "predeclared_full_factorial_realized_audit_v1"
        exp["main_evaluation"] = "same_hour_realized_error_with_fixed_policy_emergency_audit"
        exp["calendar_days"] = days
        config_path = joinpath(root, case_id * ".toml")
        open(io -> TOML.print(io, cfg; sorted=true), config_path, "w")
        push!(manifest, (case_id=case_id, system=system, wind_error_multiplier=s,
            conventional_capacity_scale=c, eval_hours=length(offsets),
            calendar_days=join(days, ";"), config_path=config_path,
            result_dir=joinpath(root, case_id)))
    end
    CSV.write(joinpath(root, "manifest.csv"), manifest)
    open(joinpath(root, "PROTOCOL.md"), "w") do io
        println(io, "# Capacity and wind residual stress protocol")
        println(io, "Canonical DC active-power device set: exclude units with both Pmax=Pmin=0 before optimization and replay. The RTS79 bus-14 reactive-only unit would otherwise insert a redundant nonnegative loss into max(G), forcing the CVaR surrogate to enforce all support samples. This correction preserves active nameplate capacity and is applied to every method. The interrupted pre-correction diagnostic remains archived under wind_isolation_20260911.")
        println(io, "Wind-only control grid fixed before its solves: ", now())
        println(io, "Full 3x3 grid: wind_error_multiplier = 1, 1.5, 2; conventional_capacity_scale = 1, 0.85, 0.7. RTS79 day 31 (24 h); RBTS days 31, 151, 271 (72 h). All listed cells and every failed solve are retained.")
        println(io, "Raw wind and load source files remain unchanged. Wind actual is transformed as clip(forecast + s*(actual-forecast), 0, scaled nameplate capacity); forecast is unchanged. Demand is known: load_actual equals load_forecast from SYSTEM_LOADS. This is a wind-only control, not a claim of perfect operational forecasting. The source_pair grid is preserved separately as a diagnostic because source forecast/realization semantics are unverified. The legacy joint error multiplier is fixed to 1. Conventional Pmax and Pmin are both multiplied by c. Wind capacity and line limits are unchanged.")
        println(io, "All methods share the first 720 training hours, the same evaluation timestamps and seed 20260515, 240 support points, K=3, epsilon=0.05. Single-TV and all mixtures use rho=0.05; proposed uses delta_w=0.05. No method-specific tuning or selection. Original wind cleanup and 24-hour persistence forecast are retained. GMM is fitted once per scenario; mixture weights use only history available before each target hour.")
        println(io, "Six methods: deterministic_headroom, empirical_cvar, single_tv, mixture_static, mixture_rolling, proposed. deterministic_headroom uses the original forecast-optimal dispatch and capacity-proportional AGC with its entire free physical upward/downward headroom. The legacy zero-reserve deterministic is excluded from the new comparison.")
        println(io, "Primary evaluation uses the realized error at each evaluated hour. Report planned shedding, fixed-policy additional emergency shedding, total lost energy, raw violation, residual security slack, and wind dispatch shortfall separately. The 96 strictly future errors remain a secondary additive perturbation audit. These audits use fixed AGC, fixed scheduled wind spill, forecast-based load-shed bounds, and explicit security slack; they are not proofs of implementable real-time recourse.")
        println(io, "Only OPTIMAL solves contribute numerical dispatch metrics. Missing or failed hours must be shown in availability and never silently removed from primary complete-window comparisons. Partial finite-row values may be retained as diagnostics with their denominators. No automatic best-result paper updater is called.")
        println(io, "Solver cap is 60 seconds per primary LP; each worker sets Julia and BLAS threads to one. Three independent workers partition the predetermined manifest by row number. The preparatory four-hour RTS79 smoke benchmark is excluded from reported grid results.")
    end
    println("Prepared manifest: ", joinpath(root, "manifest.csv"))
elseif mode == "run"
    worker = parse(Int, get(ARGS, 2, "1"))
    workers = parse(Int, get(ARGS, 3, "1"))
    push!(LOAD_PATH, joinpath(project, "src"))
    @eval using DRCCOLS, LinearAlgebra
    LinearAlgebra.BLAS.set_num_threads(1)
    manifest = CSV.read(joinpath(root, "manifest.csv"), DataFrame)
    for (i, row) in enumerate(eachrow(manifest))
        mod(i-1, workers)+1 == worker || continue
        status_path = joinpath(root, row.case_id * "_status.json")
        if isfile(status_path)
            old = JSON.parsefile(status_path)
            get(old, "status", "") == "complete" && continue
        end
        state = Dict("case_id"=>row.case_id, "status"=>"running", "started"=>string(now()), "result_dir"=>row.result_dir)
        open(io -> JSON.print(io, state, 2), status_path, "w")
        println("START ", row.case_id, " ", now()); flush(stdout)
        try
            result_dir = DRCCOLS.run_experiment(row.config_path)
            state["status"] = "complete"
            state["result_dir"] = result_dir
        catch err
            state["status"] = "failed"
            state["error"] = sprint(showerror, err, catch_backtrace())
            println(stderr, "FAILED ", row.case_id, ": ", state["error"])
        end
        state["finished"] = string(now())
        open(io -> JSON.print(io, state, 2), status_path, "w")
        flush(stdout)
        GC.gc()
    end
else
    error("Usage: run_wind_isolation.jl prepare | run [worker workers]")
end
