"""Publication presentation of the complete audited grid; no outcome selection."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import FuncNorm, LinearSegmentedColormap
from matplotlib.patches import Rectangle
from matplotlib.ticker import MaxNLocator

p = argparse.ArgumentParser()
p.add_argument('--report-dir', required=True, type=Path)
args = p.parse_args()
out = args.report_dir
paper = Path(__file__).resolve().parents[3] / 'paper'
figdir = paper / 'auto_figures'
methods = ['deterministic_headroom','empirical_cvar','single_tv','mixture_static','mixture_rolling','proposed']
labels = dict(zip(methods,['Det. + headroom','Empirical CVaR','Single-TV','Static mixture','Rolling mixture','Proposed']))
grid = pd.read_csv(out/'grid_summary.csv')
totals = pd.read_csv(out/'method_summary.csv')
common = pd.read_csv(out/'common_hour_comparisons.csv')
components = pd.read_csv(out/'component_effects.csv')
timing = pd.read_csv(out/'computation.csv')
plt.rcParams.update({'font.family':'STIXGeneral','font.size':10,'axes.labelsize':10,
    'axes.titlesize':11,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,
    'axes.spines.right':False,'axes.edgecolor':'#98a2ad','axes.linewidth':.6,
    'xtick.color':'#34424c','ytick.color':'#34424c','text.color':'#24343f'})

def save(fig, stem):
    fig.savefig(figdir/(stem+'.pdf'),bbox_inches='tight',pad_inches=.06)
    fig.savefig(figdir/(stem+'.png'),dpi=240,bbox_inches='tight',pad_inches=.06)
    plt.close(fig)

def pressure_figure(system):
    d=grid[grid.system==system].set_index(['method','c','s'])
    cols=[(c,s) for c in [1,.85,.7] for s in [1,1.5,2]]
    xs=np.array([i+0.24*(i//3) for i in range(9)])
    fig,axes=plt.subplots(2,1,figsize=(7.2,5.45))
    fig.subplots_adjust(left=.185,right=.905,top=.91,bottom=.09,hspace=.55)
    specs=[('total_eens_mwh','a   Realized unserved energy','MWh',1,['#f4f8f7','#a9ccc5','#478d87','#164d53']),
           ('future_raw_violation_rate','b   Future-error security violations','%',100,['#f5f6fa','#bdc8df','#788db7','#354873'])]
    for ax,(metric,title,unit,scale,colors) in zip(axes,specs):
        vals=np.array([[float(d.loc[(m,c,s),metric])*scale for c,s in cols] for m in methods])
        vmax=float(np.nanmax(vals)); vmax=max(vmax,1)
        norm=FuncNorm((np.log1p,np.expm1),vmin=0,vmax=vmax)
        cmap=LinearSegmentedColormap.from_list('paper',colors)
        for iy,m in enumerate(methods):
            for ix,x in enumerate(xs):
                v=vals[iy,ix]; good=np.isfinite(v)
                patch=Rectangle((x-.48,iy-.46),.96,.92,facecolor=cmap(norm(v)) if good else '#f1f2f3',
                    edgecolor='white' if good else '#d9dde0',linewidth=.35,hatch=None if good else '///')
                ax.add_patch(patch)
                if not good: txt='--'
                elif abs(v)<1e-6: txt='0'
                elif metric=='total_eens_mwh': txt=f'{v:.0f}' if v>=100 else f'{v:.1f}'
                else: txt=f'{v:.1f}' if v>=.1 else '<0.1'
                ax.text(x,iy,txt,ha='center',va='center',fontsize=9.3,
                    color='white' if good and norm(v)>.70 else '#253541')
        ax.set_xlim(-.6,xs[-1]+.6);ax.set_ylim(5.55,-.55)
        ax.set_yticks(range(6),[labels[m] for m in methods])
        ax.get_yticklabels()[-1].set_fontweight('bold')
        ax.set_xticks(xs,[f'{s:g}' for c,s in cols]);ax.tick_params(length=0,pad=5)
        ax.set_xlabel('Wind-error multiplier $s$',labelpad=5)
        ax.set_title(title,loc='left',pad=31,fontweight='bold')
        for k,c in enumerate([1,.85,.7]):
            mid=xs[k*3:k*3+3].mean()
            ax.text(mid,-.84,f'Capacity {100*c:g}%',ha='center',va='bottom',fontsize=9.5)
        for spine in ax.spines.values():spine.set_visible(False)
        sm=plt.cm.ScalarMappable(norm=norm,cmap=cmap)
        box=ax.get_position();cax=fig.add_axes([.928,box.y0+.01,.013,box.height-.02])
        cb=fig.colorbar(sm,cax=cax)
        ticks=([0,10,100,1000] if scale==1 else [0,1,5,20])+[vmax]
        ticks=[v for v in ticks if v<=vmax]
        # Keep the maximum separate from a nearby fixed tick.
        if len(ticks)>2 and ticks[-1]/max(ticks[-2],1)<1.35: ticks.pop(-2)
        cb.set_ticks(ticks);cb.set_ticklabels([f'{v/1000:.1f}k' if v>=1000 else f'{v:g}' if v==int(v) else f'{v:.0f}' for v in ticks])
        cb.ax.tick_params(labelsize=8,length=2,width=.5);cb.outline.set_visible(False)
        cb.ax.set_title(unit,fontsize=9,pad=7)
    save(fig,'fig_capacity_wind_stress' if system=='rbts' else 'fig_capacity_wind_stress_rts79')

for sy in ['rbts','rts79']:pressure_figure(sy)

# Directly labelled trade-off diagram: all five stochastic alternatives.
fig,axes=plt.subplots(1,2,figsize=(7.2,3.25))
fig.subplots_adjust(left=.075,right=.985,bottom=.19,top=.83,wspace=.32)
short={'empirical_cvar':'Empirical','single_tv':'Single-TV','mixture_static':'Static','mixture_rolling':'Rolling','proposed':'Proposed'}
marks={'empirical_cvar':'s','single_tv':'P','mixture_static':'o','mixture_rolling':'^','proposed':'D'}
for ax,sy in zip(axes,['rbts','rts79']):
    d=common[common.system==sy].set_index('method')
    pts={m:(d.loc[m,'future_eens']/1000,d.loc[m,'future_raw_pct']) for m in methods[1:]}
    for a,b in [('mixture_static','mixture_rolling'),('mixture_rolling','proposed')]:
        ax.annotate('',xy=pts[b],xytext=pts[a],arrowprops=dict(arrowstyle='->',color='#9ba6af',lw=.9,shrinkA=7,shrinkB=7),zorder=1)
    offsets=({'empirical_cvar':(-15,17),'single_tv':(-3,6),'mixture_static':(-28,-18),'mixture_rolling':(7,-3),'proposed':(7,5)} if sy=='rbts' else
             {'empirical_cvar':(7,-3),'single_tv':(5,-3),'mixture_static':(-29,-18),'mixture_rolling':(-52,5),'proposed':(-48,18)})
    for m,(x,y) in pts.items():
        color='#be713d' if m=='proposed' else '#337b80' if m=='mixture_rolling' else '#5e7181'
        ax.scatter(x,y,s=43 if m=='proposed' else 33,marker=marks[m],color=color,edgecolor='white',linewidth=.6,zorder=3)
        ax.annotate(short[m],(x,y),xytext=offsets[m],textcoords='offset points',fontsize=9,
                    fontweight='bold' if m=='proposed' else 'normal',color=color)
    n=int(d.loc['proposed','common_hours']);planned=int(d.loc['proposed','planned_hours'])
    ax.set_title(f'{sy.upper()}   |   {n}/{planned} common hours',loc='left',fontweight='bold',fontsize=10.5,pad=12)
    ax.set_xlabel('Future-error EENS ($10^3$ MWh)')
    ax.set_ylabel('Future-error violation (%)' if sy=='rbts' else '')
    ax.grid(axis='y',color='#e5e9ec',lw=.6);ax.set_axisbelow(True)
    if sy=='rbts':ax.set_xlim(2.85,4.58);ax.set_ylim(-.45,3.15);ax.set_yticks([0,1,2,3])
    else:ax.set_xlim(5.98,6.76);ax.set_ylim(8.35,12.15);ax.set_yticks([9,10,11,12])
    ax.xaxis.set_major_locator(MaxNLocator(4));ax.tick_params(labelsize=9,length=3,width=.5)
save(fig,'fig_component_tradeoff')

def fmt(x):
    return '--' if pd.isna(x) else '0' if abs(x)<.0005 else f'{x:,.2f}'
def row(values,bold=False):
    vals=[str(v) for v in values]
    if bold: vals=[r'\textbf{'+v+'}' for v in vals]
    return ' & '.join(vals)+r' \\'
def table(caption,label,cols,header,body):
    return '\n'.join([r'\begin{table}[htbp]',r'\centering',r'\small',r'\setlength{\tabcolsep}{5pt}',
        r'\renewcommand{\arraystretch}{1.13}',r'\caption{'+caption+'}',r'\label{'+label+'}',
        r'\begin{adjustbox}{max width=\textwidth}',r'\begin{tabular}{'+cols+'}',r'\toprule',*header,r'\midrule',*body,
        r'\bottomrule',r'\end{tabular}',r'\end{adjustbox}',r'\end{table}'])

sections=[r'\subsection{Wind-Error Variability and Conventional-Capacity Stress}',
    r'The pressure maps show how energy and security outcomes vary across the complete wind--capacity grid. Same-hour ENS and future-error security are displayed separately, following the definitions in Section~\ref{subsec:audit_metrics}.']
for sy in ['rbts','rts79']:
    d=totals[totals.system==sy].set_index('method')
    sections += [r'\paragraph{'+sy.upper()+' results.}',
        f'The nine stress combinations provide {int(d.expected_hours.iloc[0])} exposures per method. '
        f'All methods share forecast conditions and realized errors within each cell; stochastic comparisons use the prescribed support budgets and method-specific radii. '
        f'The experiment yields {int(d.optimal_hours.sum()):,} optimal dispatches out of {int(d.expected_hours.sum()):,} attempts.']
    if sy=='rbts':
        body=[row([labels[m],fmt(d.loc[m,'planned_eens_mwh']),fmt(d.loc[m,'emergency_eens_mwh']),fmt(d.loc[m,'total_eens_mwh']),
             fmt(100*d.loc[m,'raw_violation_rate']),fmt(100*d.loc[m,'residual_security_rate'])],m=='proposed') for m in methods]
        sections.append(table('RBTS complete-grid replay. Energy values are MWh and security frequencies are percentages; all methods cover 648/648 exposures.',
            'tab:capacity_wind_stress_rbts','lrrrrr',
            [r' & \multicolumn{3}{c}{Realized unserved energy (MWh)} & \multicolumn{2}{c}{Security (\%)} \\',
             r'\cmidrule(lr){2-4}\cmidrule(lr){5-6}',r'Method & Planned & Emergency & Total & Raw & Residual \\'],body))
    else:
        body=[]
        for m in methods:
            z=json.loads(d.loc[m,'statuses']);others=sum(v for k,v in z.items() if k not in ['OPTIMAL','INFEASIBLE','TIME_LIMIT'])
            body.append(row([labels[m],f"{int(d.loc[m,'optimal_hours'])}/{int(d.loc[m,'expected_hours'])}",z.get('INFEASIBLE',0),z.get('TIME_LIMIT',0),others],m=='proposed'))
        sections.append(table(r'RTS79 dispatch coverage over all nine stress cells. Energy and security comparisons on common solved hours appear in Table~\ref{tab:control_common}.',
            'tab:capacity_wind_stress_rts79','lrrrr',[r'Method & Optimal/planned & Infeasible & Time limit & Other \\'],body))
    stem='fig_capacity_wind_stress' if sy=='rbts' else 'fig_capacity_wind_stress_rts79'
    sections.extend([r'\begin{figure}[htbp]',r'\centering',r'\includegraphics[width=\textwidth]{auto_figures/'+stem+'.pdf}',
        r'\caption{'+sy.upper()+r' wind--capacity response. Columns are grouped by remaining conventional capacity. Numbers give realized ENS (MWh) and future-error raw violation frequency (\%); color intensity uses $\log(1+x)$ in both panels. Hatched cells have no complete numerical replay. Coverage is reported in Table~\ref{tab:capacity_wind_stress_'+sy+r'}.}',
        r'\label{fig:capacity_wind_stress_'+sy+'}',r'\end{figure}'])
sections.append('No excess-curtailment event occurs in the successful same-hour replays of this original stress grid. Full hourly records, secondary diagnostics, and solver statuses are retained in the reproducibility files.')
(paper/'auto_capacity_wind_stress.tex').write_text('\n\n'.join(sections)+'\n',encoding='utf-8')

body=[]
for sy in ['rbts','rts79']:
    d=common[common.system==sy].set_index('method')
    if body:body.append(r'\addlinespace[5pt]')
    body.append(r'\multicolumn{6}{l}{\textit{'+sy.upper()+f" --- {int(d.common_hours.iloc[0])}/{int(d.planned_hours.iloc[0])} common exposures"+r'}} \\')
    for m in methods:
        z=d.loc[m];body.append(row([labels[m],fmt(z.total_ens),fmt(z.raw_pct),fmt(z.future_eens),fmt(z.future_raw_pct),fmt(z.residual_pct)],m=='proposed'))
commontex=[r'\subsection{Comparison on Common Solved Hours}\label{subsec:control_common}',
    r'Table~\ref{tab:control_common} compares every method on identical solved hours: the complete RBTS grid and the jointly solved RTS79 subset. Figure~\ref{fig:component_tradeoff} places the five stochastic alternatives in the energy--security plane of the secondary audit, making the effects of reweighting and weight protection visible.',
    table('Energy and security on common solved hours. Energy values are MWh; violation frequencies are percentages. Same-hour residual security is retained to distinguish energy supply from restored security.',
      'tab:control_common','lrrrrr',[r' & \multicolumn{2}{c}{Same-hour replay} & \multicolumn{2}{c}{Future-error audit} & Same-hour \\',
       r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}',r'Method & ENS & Raw (\%) & EENS & Raw (\%) & Residual (\%) \\'],body),
    r'\begin{figure}[htbp]',r'\centering',r'\includegraphics[width=\textwidth]{auto_figures/fig_component_tradeoff.pdf}',
    r'\caption{Energy--security trade-offs among stochastic methods on common solved hours. Both axes use the future-error audit; lower values are preferable. Arrows follow static mixture $\rightarrow$ rolling mixture $\rightarrow$ proposed. Each panel has its own axis range.}',
    r'\label{fig:component_tradeoff}',r'\end{figure}']
(paper/'auto_control_common.tex').write_text('\n'.join(commontex)+'\n',encoding='utf-8')

# Remove the planned-ENS column that duplicates total ENS in every paired row.
assert np.allclose(components.delta_planned_eens_mwh,components.delta_total_eens_mwh)
body=[]
for sy in ['rbts','rts79']:
    if body:body.append(r'\addlinespace[5pt]')
    body.append(r'\multicolumn{5}{l}{\textit{'+sy.upper()+r'}} \\')
    for _,z in components[components.system==sy].iterrows():
        delta=lambda x:'0' if abs(x)<.0005 else f'{x:+.3f}'
        body.append(row([z.label,f'{z.valid_pairs}/{z.planned_pairs}',delta(z.delta_total_eens_mwh),delta(100*z.delta_future_raw_violation_rate),f'{z.lower}/{z.tie}/{z.higher}']))
old=(paper/'auto_control_components.tex').read_text(encoding='utf-8');intro=old.split(r'\begin{table}')[0]
(paper/'auto_control_components.tex').write_text(intro+table(
    'Incremental effects on identical paired hours. Energy differences are realized MWh per hour and equal the planned-shedding differences in this experiment. Risk differences are future-error percentage points. L/T/H counts lower/tied/higher realized ENS.',
    'tab:control_components','lrrrr',[r'Transition & Paired/planned & $\Delta$ENS & $\Delta$future raw & L/T/H \\'],body)+'\n',encoding='utf-8')

body=[]
for m in methods:
    vals=[labels[m]]
    for sy in ['rbts','rts79']:
        z=timing[(timing.system==sy)&(timing.method==m)].iloc[0]
        assert z.attempts==z.planned
        vals += [f'{z["mean"]:.3f}',f'{z.p95:.3f}']
    body.append(row(vals,m=='proposed'))
old=(paper/'auto_control_computation.tex').read_text(encoding='utf-8');intro=old.split(r'\begin{table}')[0]
(paper/'auto_control_computation.tex').write_text(intro+table(
    'Dispatch LP time in seconds, including non-optimal attempts. All 648 RBTS and 216 RTS79 attempts per method have timing records. Medians and maxima are retained in the reproducibility data.',
    'tab:control_computation','lrrrr',[r' & \multicolumn{2}{c}{RBTS} & \multicolumn{2}{c}{RTS79} \\',r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}',r'Method & Mean & P95 & Mean & P95 \\'],body)+'\n',encoding='utf-8')
print('Redesigned pressure maps, trade-off diagram, and five compact table layouts.')
