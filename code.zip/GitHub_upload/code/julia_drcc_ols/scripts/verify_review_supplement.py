"""Cross-check the supplementary protocol, duplicated controls and original data."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
project=Path(__file__).resolve().parents[1]
root=project/'results/review_supplement_20260913'
d=pd.read_csv(root/'all_hourly.csv')
manifest=json.loads((root/'manifest.json').read_text())
expected={(v['id'],t) for vs in manifest.values() for v in vs for t in v['hours']}
assert set(zip(d.variant,d.t))==expected and len(d)==len(expected)
ok=d[d.status=='OPTIMAL']
assert np.isfinite(ok[['objective','total_ens','raw_violation','residual_violation']]).all().all()
assert (ok.total_ens>=-1e-6).all()
assert np.allclose(ok.total_ens,ok.planned_ens+ok.emergency_ens,atol=1e-7)
baseline=d[d.variant=='weights_protected'].set_index('t')
duplicates=['rho_0.05_mixture','delta_0.05','K_3','budget_240','window_48','kappa_10.0','tie_1.0e-6','support_posterior_mixture']
for name in duplicates:
    other=d[d.variant==name].set_index('t')
    for c in ['objective','total_ens','raw_violation','future_raw']:
        assert np.allclose(baseline[c],other.loc[baseline.index,c],atol=1e-7),name
original=pd.read_csv(project/'results/wind_control_final_20260911/rbts_s150_c85/dispatch_results.csv')
original=original[(original.method=='proposed')&(original.eval_index<=24)].set_index('time')
assert np.allclose(baseline.set_index('time').loc[original.index,'total_ens'],original.realized_eens_mwh,atol=1e-7)
chron=d[d.family=='chronological']
assert chron.wind_shortfall.notna().all()
assert (chron.groupby(['system','method','delta']).size()==168).all()
assert set(chron.t)==set(range(745,913))
assert (chron[chron.system=='rbts'].wind_shortfall<=1e-6).all()
for item in json.loads((project/'results/wind_control_final_20260911/engine_hashes.json').read_text(encoding='utf-8-sig')):
    assert hashlib.sha256(Path(item['Path']).read_bytes()).hexdigest().upper()==item['Hash']
provenance=json.loads((project/'results/wind_control_final_report/provenance.json').read_text(encoding='utf-8'))
for item in provenance['sources']:
    for p,h in [('dispatch_path','dispatch_sha256'),('config_path','config_sha256')]:
        assert hashlib.sha256(Path(item[p]).read_bytes()).hexdigest()==item[h]
record=dict(attempts=len(d),variants=d.variant.nunique(),statuses=d.status.value_counts().to_dict(),
    duplicate_baseline_variants_verified=len(duplicates),original_baseline_reproduced=True,
    chronological_hours_per_method_system=168,chronological_wind_shortfall_max=float(chron.wind_shortfall.max()),
    chronological_physical_validity_reported=True,
    original_engine_results_and_configuration_hashes_unchanged=True,
    source_hashes={str(p.relative_to(project)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'manifest.json',root/'all_hourly.csv',project/'scripts/review_supplement.jl',project/'scripts/report_review_supplement.py']})
(root/'verification.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
