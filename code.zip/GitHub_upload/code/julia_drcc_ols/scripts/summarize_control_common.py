"""Compare every method on the same jointly audited hours; retain full-grid denominators."""
import argparse
from pathlib import Path
import pandas as pd
from report_capacity_wind_stress import LABELS

p = argparse.ArgumentParser()
p.add_argument('--report-dir', required=True, type=Path)
args = p.parse_args()
df = pd.read_csv(args.report_dir / 'hourly_audit.csv')
keys = ['system', 's', 'c', 'eval_index']
methods = list(df.method.unique())
coverage = df.groupby(keys).agg(valid=('audit_valid', 'sum'), count=('method', 'nunique')).reset_index()
common = coverage[(coverage.valid == len(methods)) & (coverage['count'] == len(methods))]
selected = df.merge(common[keys], on=keys, validate='many_to_one')
rows = []
for system in sorted(df.system.unique()):
    planned = int((df.system == system).sum() / len(methods))
    for method in methods:
        g = selected[(selected.system == system) & (selected.method == method)]
        rows.append(dict(system=system, method=method, common_hours=len(g), planned_hours=planned,
            planned_ens=g.planned_eens_mwh.sum() if len(g) else float('nan'),
            emergency_ens=g.emergency_eens_mwh.sum() if len(g) else float('nan'),
            total_ens=g.total_eens_mwh.sum() if len(g) else float('nan'),
            raw_pct=100*g.raw_violation_rate.mean(), residual_pct=100*g.residual_security_rate.mean(),
            future_eens=g.future_total_eens_mwh.sum() if len(g) else float('nan'),
            future_raw_pct=100*g.future_raw_violation_rate.mean()))
pd.DataFrame(rows).to_csv(args.report_dir/'common_hour_comparisons.csv', index=False)
common[keys].to_csv(args.report_dir/'common_hour_indices.csv', index=False)
lines = [r'\subsection{Comparison on Common Solved Hours}\label{subsec:control_common}',
    r'Table~\ref{tab:control_common} compares all six methods on the same successfully solved hours. This gives equal exposure for the energy and security comparisons: the full RBTS grid and the jointly solved subset of RTS79. The common/planned denominator specifies the coverage, with the remaining stress levels characterized by the availability panels.',
    r'\begin{table}[htbp]', r'\centering', r'\small',
    r'\caption{Equal-exposure comparison on jointly solved hours. ENS and future-block EENS are MWh; raw violation frequencies are percentages. The common/planned denominator applies separately to each method.}',
    r'\label{tab:control_common}', r'\begin{adjustbox}{max width=\textwidth}',
    r'\begin{tabular}{llrrrrrr}', r'\toprule',
    r'System & Method & Common/planned & Planned ENS & Total ENS & Raw (\%) & Future EENS & Future raw (\%) \\', r'\midrule']
for r in rows:
    values = ' & '.join('--' if pd.isna(r[k]) else f'{r[k]:.2f}' for k in ['planned_ens','total_ens','raw_pct','future_eens','future_raw_pct'])
    lines.append(f"{r['system'].upper()} & {LABELS[r['method']]} & {r['common_hours']}/{r['planned_hours']} & {values}" + r' \\')
lines += [r'\bottomrule',r'\end{tabular}',r'\end{adjustbox}',r'\end{table}']
(Path(__file__).resolve().parents[3]/'paper'/'auto_control_common.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(pd.DataFrame(rows).to_string(index=False))
