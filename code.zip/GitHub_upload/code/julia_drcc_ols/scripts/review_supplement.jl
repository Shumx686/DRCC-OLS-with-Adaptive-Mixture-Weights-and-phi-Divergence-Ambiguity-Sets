using TOML, CSV, DataFrames, JSON, Statistics, LinearAlgebra, Dates, SHA
project=normpath(joinpath(@__DIR__,".."))
push!(LOAD_PATH,joinpath(project,"src"))
using DRCCOLS
BLAS.set_num_threads(1)
root=get(ENV,"DRCC_SUPPLEMENT_OUTPUT",joinpath(project,"results","replications","supplement"))
mkpath(root)
mode=isempty(ARGS) ? "prepare" : ARGS[1]

function variant(id;family="weights",system="rbts",s=1.5,c=.85,K=3,rho=.05,delta=.05,
        theta=.5,window=48,kappa=10.,budget=240,selection="posterior",method="mixture",
        divergence="tv",tie=1e-6,hours=collect(721:744),future=96,line_factor=1.)
    Dict("id"=>id,"family"=>family,"system"=>system,"s"=>s,"c"=>c,"K"=>K,"rho"=>rho,
        "delta"=>delta,"theta"=>theta,"window"=>window,"kappa"=>kappa,"budget"=>budget,
        "selection"=>selection,"method"=>method,"divergence"=>divergence,"tie"=>tie,
        "hours"=>hours,"future"=>future,"line_factor"=>line_factor)
end
if mode=="prepare"
    jobs=Dict("sensitivity"=>Any[],"chronological_rbts"=>Any[],"chronological_rts79"=>Any[])
    v=jobs["sensitivity"]
    for r in [0.,.02,.05,.10,.20], m in ["single","mixture"]
        push!(v,variant("rho_$(r)_$(m)";family="rho",rho=r,method=m,delta=m=="single" ? 0. : .05))
    end
    for d in [0.,.02,.05,.10,.20]
        push!(v,variant("delta_$(d)";family="delta",delta=d))
    end
    for (name,theta) in [("historical",0.),("predictive",1.),("blended",.5)]
        push!(v,variant("weights_$(name)";theta=theta,delta=0.))
    end
    push!(v,variant("weights_static";method="static",delta=0.))
    push!(v,variant("weights_protected"))
    for k in 1:5
        push!(v,variant("K_$(k)";family="K",K=k))
    end
    for q in [120,240,480]
        push!(v,variant("budget_$(q)";family="budget",budget=q))
    end
    for w in [24,48,96]
        push!(v,variant("window_$(w)";family="window",window=w))
    end
    for k in [0.,10.,30.]
        push!(v,variant("kappa_$(k)";family="kappa",kappa=k))
    end
    for t in [1e-5,1e-6,1e-7]
        push!(v,variant("tie_$(t)";family="tie",tie=t))
    end
    for rule in ["posterior","distance_stratified","full"], m in ["static","mixture"]
        push!(v,variant("support_$(rule)_$(m)";family="support",selection=rule,method=m,delta=m=="static" ? 0. : .05))
    end
    for sy in ["rbts","rts79"],m in ["single","rolling","protected"]
        push!(jobs["chronological_$(sy)"],variant("chron_$(sy)_$(m)";family="chronological",system=sy,
            s=sy=="rbts" ? 1.5 : 1.,method=m=="single" ? "single" : "mixture",
            delta=m=="protected" ? .05 : 0.,hours=collect(745:912),future=0))
    end
    for (sy,s,c) in [("rbts",1.,1.),("rbts",1.5,.85),("rts79",1.,.85)],dv in ["empirical","tv","chi2"]
        push!(jobs[sy=="rbts" ? "chronological_rbts" : "chronological_rts79"],
            variant("geometry_$(sy)_$(s)_$(dv)";family="geometry",system=sy,s=s,c=c,
            method=dv=="empirical" ? "single" : "mixture",divergence=dv=="chi2" ? "chi2" : "tv",
            rho=dv=="empirical" ? 0. : .05,delta=dv=="empirical" ? 0. : .05,hours=collect(721:4:744),future=96))
    end
    # Constraint-relaxation diagnostics precede the larger RTS79 chronology.
    diags=Any[]
    for s in [1.5,2.],f in [1.,2.,100.],m in ["single","mixture"]
        push!(diags,variant("network_diag_$(s)_$(f)_$(m)";family="feasibility_diagnostic",system="rts79",
            s=s,c=1.,line_factor=f,method=m,rho=m=="single" ? 0. : .05,
            delta=m=="single" ? 0. : .05,hours=[721],future=0))
    end
    jobs["chronological_rts79"]=vcat(diags,jobs["chronological_rts79"])
    open(io->JSON.print(io,jobs,2),joinpath(root,"manifest.json"),"w")
    write(joinpath(root,"PROTOCOL.md"),"""
    # Review supplement: fixed design before supplementary outcomes
    Created $(now()). This supplement retains the original physical model and main grid.
    Sensitivity/weight/support experiments: RBTS day 31, s=1.5, c=0.85 (central grid cell), same 720-hour training history and 96-error secondary audit. Every declared variant is retained. These are diagnostic sensitivity runs, not retrospective statistical calibration.
    Chronology: days 32--38, every hour exactly once, fixed initial 720-hour supports; RBTS central grid cell, RTS79 s=1 and c=0.85. Same-hour realized outcomes are primary, no overlapping future audit. The source records retain the main experiment's retrospective quality control; this does not certify streaming preprocessing. No test-day tuning or support refit.
    Geometry: six evenly spaced hours on day 31, two RBTS conditions and the feasible RTS79 condition; empirical, TV and modified chi-square. Equal numerical radii do not imply equal statistical coverage. Conic solver defaults are retained and timing/status reported explicitly.
    Support alternatives preserve the original per-regime q allocation for posterior/distance-stratified comparison. Distance stratification spans sorted squared diagonal Mahalanobis distances within each hard-assigned regime; for q>=2 it includes nearest and farthest samples. Full support uses every hard-assigned sample. No fixed 60/20/20 proportions are imposed.
    Feasibility diagnostic: on RTS79 day31 hour1 at s=1.5 and 2, multiply only line limits by 1,2,100, retaining other decisions/data. These relaxations identify binding network restrictions; they are not proposed operating settings or evidence that a specific recourse extension is sufficient.
    All weights and ambiguities use the existing source. No model is changed merely to attain a target percentage of successful solves.
    """)
    println("Prepared ",sum(length(v) for v in values(jobs))," variants")
    exit()
end

jobs=JSON.parsefile(joinpath(root,"manifest.json"));variants=jobs[mode]
if length(ARGS)>1
    part=ARGS[2]
    variants=filter(v->part=="other" ? v["family"]!="chronological" : part=="chron" ? v["family"]=="chronological" : v["id"]=="chron_$(v["system"])_$(part)",variants)
    mode*= "_"*part
end
source_cache=Dict{String,Any}();context_cache=Dict{String,Any}();records=DataFrame();supportlog=Dict{String,Any}()
function source(system)
    get!(source_cache,system) do
        cfg=TOML.parsefile(joinpath(project,"config",system=="rbts" ? "comparison.toml" : "rts79_comparison.toml"))
        d=cfg["data"]
        p(k)=cfg["paths"][k] isa AbstractVector ? [normpath(joinpath(project,x)) for x in cfg["paths"][k]] : normpath(joinpath(project,cfg["paths"][k]))
        ca=DRCCOLS.load_rbts(p("rbts");replace_gen_indices=d["replace_gen_indices"],pmin_scale=d["pmin_scale"])
        da=DRCCOLS.load_experiment_data(ca,p("system_loads"),p("bus_loads"),p("wind_xlsx");wind_scale=d["wind_scale"],wind_lag=d["wind_forecast_lag_hours"],error_scale=1.)
        caps=DRCCOLS.wind_capacity_from_filename.(DRCCOLS.as_string_vector(p("wind_xlsx"))) .* DRCCOLS.expand_to_length(DRCCOLS.as_float_vector(d["wind_scale"]),size(da.wind_actual,2))
        (ca,da,caps)
    end
end
function context(v)
    key=join([v[k] for k in ["system","s","c","K","budget","selection","line_factor"]],"_")
    get!(context_cache,key) do
        ca,da,caps=source(v["system"])
        ca,da,_=DRCCOLS.apply_physical_stress(ca,da,caps;conventional_capacity_scale=v["c"],wind_error_multiplier=v["s"],load_error_mode="known_forecast")
        ca=DRCCOLS.active_power_case(ca)
        if v["line_factor"]!=1
            ca=DRCCOLS.RBTSCase(ca.base_mva,ca.bus,ca.gen,ca.branch,ca.bus_ids,ca.gen_bus_idx,ca.wind_bus_idx,ca.line_rates.*v["line_factor"],ca.ptdf)
        end
        x=da.omega[1:720,:];gmm=DRCCOLS.fit_diag_gmm(x,v["K"];max_iter=120,seed=20260515)
        ids=DRCCOLS.representative_indices(gmm.gamma_train,1.;max_per_regime=v["budget"],max_total=v["budget"])
        hard=[argmax(@view gmm.gamma_train[i,:]) for i in axes(x,1)]
        if v["selection"]!="posterior"
            z=(x.-gmm.center')./gmm.scale'
            for k in eachindex(ids)
                candidates=findall(==(k),hard);isempty(candidates)&&(candidates=copy(ids[k]))
                if v["selection"]=="full"
                    ids[k]=candidates
                else
                    dist=[sum((z[i,:].-gmm.means[k,:]).^2 ./ gmm.variances[k,:]) for i in candidates]
                    order=candidates[sortperm(dist)];q=length(ids[k])
                    ids[k]=q==1 ? order[1:1] : order[unique(round.(Int,range(1,length(order),length=q)))]
                end
            end
        end
        global_ids=DRCCOLS.global_representative_indices(gmm.gamma_train,v["budget"];mode="budgeted")
        # Cache the full record of responsibilities, as later variants may run longer.
        gamma=DRCCOLS.responsibilities(gmm,da.omega)
        supportlog[key]=Dict("local_indices"=>ids,"global_indices"=>global_ids,"q"=>length.(ids),"weights"=>gmm.weights,"loglik"=>gmm.loglik)
        open(io->JSON.print(io,supportlog,2),joinpath(root,mode*"_supports.json"),"w")
        (case=ca,data=da,gmm=gmm,gamma=gamma,reps=[x[i,:] for i in ids],global_reps=[x[global_ids,:]],q=join(length.(ids),";"))
    end
end

for (vi,v) in enumerate(variants)
    println("START ",mode," ",vi,"/",length(variants)," ",v["id"]," ",now());flush(stdout)
    ctx=context(v);ca=ctx.case;da=ctx.data
    for t in v["hours"]
        L=vec(da.load_forecast[t,:]);W=vec(da.wind_forecast[t,:]);om=vec(da.omega[t,:])
        reps=v["method"]=="single" ? ctx.global_reps : ctx.reps
        pi=v["method"]=="single" ? [1.] : v["method"]=="static" ? ctx.gmm.weights :
            DRCCOLS.rolling_weights_from_history(ctx.gmm,ctx.gamma[1:t-1,:],vec(da.omega[t-1,:]);window=v["window"],kappa=v["kappa"],blend_rho=v["theta"])
        sol=DRCCOLS.solve_drcc_ols(ca,L,W,pi,reps,fill(v["rho"],length(reps));epsilon=.05,delta_w=v["delta"],divergence=v["divergence"],time_limit=60.,tie_breaker=v["tie"],wind_spill_penalty=.001)
        mv=DRCCOLS.max_violation(ca,sol,L,W,om)
        em=DRCCOLS.emergency_shed_if_needed(ca,sol,L,W,om;violation=mv)
        fut=v["future"]>0 ? DRCCOLS.oos_stats(ca,sol,L,W,da.omega[t+1:t+v["future"],:];reliability_sample_limit=v["future"]) : nothing
        push!(records,(variant=v["id"],family=v["family"],system=v["system"],s=v["s"],c=v["c"],K=v["K"],rho=v["rho"],delta=v["delta"],theta=v["theta"],window=v["window"],kappa=v["kappa"],budget=v["budget"],selection=v["selection"],method=v["method"],divergence=v["divergence"],tie=v["tie"],line_factor=v["line_factor"],t=t,time=da.times[t],day=cld(t,24),status=sol.status,
            objective=sol.objective,planned_ens=sol.load_shed,emergency_ens=em.shed,total_ens=sol.load_shed+em.shed,
            raw_violation=isfinite(mv) ? Float64(mv>1e-6) : NaN,residual_violation=isfinite(em.residual_slack) ? Float64(em.residual_slack>1e-6) : NaN,
            future_eens=fut===nothing ? NaN : fut.eens_mwh,future_raw=fut===nothing ? NaN : fut.violation_rate,future_residual=fut===nothing ? NaN : fut.residual_security_rate,
            wind_shortfall=sol.has_values ? sum(max.(sol.wind_spill.-vec(da.wind_actual[t,:]),0.)) : NaN,
            wind_curtailment=sol.wind_curtailment,
            solve_sec=sol.solve_time,q=ctx.q,loglik=ctx.gmm.loglik))
        length(records.variant)%24==0 && CSV.write(joinpath(root,mode*"_partial.csv"),records)
    end
    CSV.write(joinpath(root,mode*"_partial.csv"),records)
end
CSV.write(joinpath(root,mode*".csv"),records)
println("COMPLETE ",mode," rows=",nrow(records));flush(stdout)
