"""Generate paired component comparisons from the full wind-control hourly audit."""
import argparse
import csv
from pathlib import Path
import numpy as np
import pandas as pd

p=argparse.ArgumentParser()
p.add_argument('--report-dir',type=Path,required=True)
p.add_argument('--paper-dir',type=Path,default=Path(__file__).resolve().parents[3]/'paper')
args=p.parse_args()
df=pd.read_csv(args.report_dir/'hourly_audit.csv')
transitions=[('single_tv','mixture_static','Single-TV $\\to$ static'),
             ('mixture_static','mixture_rolling','Static $\\to$ rolling'),
             ('mixture_rolling','proposed','Rolling $\\to$ proposed')]
keys=['system','s','c','eval_index']
metrics=['planned_eens_mwh','emergency_eens_mwh','total_eens_mwh','raw_violation_rate','residual_security_rate',
         'future_total_eens_mwh','future_raw_violation_rate','future_residual_security_rate']
rows=[]
for system in sorted(df.system.unique()):
    for baseline,candidate,label in transitions:
        a=df[(df.system==system)&(df.method==baseline)]
        b=df[(df.system==system)&(df.method==candidate)]
        pair=a.merge(b,on=keys,suffixes=('_b','_c'),validate='one_to_one')
        valid=pair.audit_valid_b & pair.audit_valid_c
        row=dict(system=system,baseline=baseline,candidate=candidate,label=label,
                 planned_pairs=len(pair),valid_pairs=int(valid.sum()))
        for m in metrics:
            d=pair.loc[valid,m+'_c']-pair.loc[valid,m+'_b']
            assert d.notna().all(), f'Missing paired metric: {m}'
            row['delta_'+m]=float(d.mean()) if len(d) else np.nan
            if m=='total_eens_mwh':
                row.update(lower=int((d < -1e-6).sum()),tie=int((abs(d)<=1e-6).sum()),higher=int((d>1e-6).sum()))
        if valid.any():
            assert abs(row['delta_total_eens_mwh']-row['delta_planned_eens_mwh']-row['delta_emergency_eens_mwh'])<1e-5
        rows.append(row)
out=pd.DataFrame(rows)
out.to_csv(args.report_dir/'component_effects.csv',index=False)
def f(x):
    if not np.isfinite(x): return '--'
    if abs(x)<0.00005:return '0'
    return f'{x:+.3f}'
lines=[r'\subsection{Incremental Value of the Mixture Layers}\label{subsec:control_components}',
 r'Table~\ref{tab:control_components} compares successive model variants within the wind-only grid. Entries are candidate-minus-baseline averages over identical hours for which both variants have optimal dispatches and finite replay metrics. Negative energy differences indicate less unserved energy; negative violation differences indicate fewer violations. Each denominator is shown, and no missing dispatch is assigned zero loss.',
 r'The single-TV-to-static transition is a comparison of uncertainty representations: the local TV radius is unchanged, but partitioning and representative sample locations can differ. The static-to-rolling and rolling-to-proposed transitions retain the same local supports and radii, isolating the online weights and outer weight-ambiguity layer, respectively.',
 r'\begin{table}[htbp]',r'\centering',r'\small',
 r'\caption{Paired component comparisons in the wind-only grid. Energy differences are realized MWh per paired hour; future raw-violation differences are percentage points in the secondary perturbation audit. L/T/H counts indicate lower/tied/higher realized total ENS for the candidate; these are not independent statistical trials.}',
 r'\label{tab:control_components}',r'\begin{adjustbox}{max width=\textwidth}',
 r'\begin{tabular}{llrrrrr}',r'\toprule',
 r'System & Transition & Paired/planned & $\Delta E_{\rm plan}$ & $\Delta\mathrm{ENS}$ & $\Delta$future raw (pp) & L/T/H \\',r'\midrule']
for r in rows:
    lines.append(f"{r['system'].upper()} & {r['label']} & {r['valid_pairs']}/{r['planned_pairs']} & {f(r['delta_planned_eens_mwh'])} & {f(r['delta_total_eens_mwh'])} & {f(100*r['delta_future_raw_violation_rate'])} & {r['lower']}/{r['tie']}/{r['higher']}"+r' \\')
lines += [r'\bottomrule',r'\end{tabular}',r'\end{adjustbox}',r'\end{table}']
(args.paper_dir/'auto_control_components.tex').write_text('\n\n'.join(lines)+'\n',encoding='utf-8')
print(out[['system','label','valid_pairs','delta_total_eens_mwh','delta_raw_violation_rate']].to_string(index=False))
