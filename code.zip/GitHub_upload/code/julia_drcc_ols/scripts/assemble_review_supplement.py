from pathlib import Path
import pandas as pd
import numpy as np
root=Path(__file__).resolve().parents[1]/'results/review_supplement_20260913'
def compare(old,new):
    a=old.merge(new,on=['variant','t'],suffixes=('_old','_new'),validate='one_to_one')
    assert (a.status_old==a.status_new).all()
    for c in ['total_ens','raw_violation','residual_violation']:
        assert np.allclose(a[c+'_old'],a[c+'_new'],atol=1e-5,rtol=1e-8,equal_nan=True),c
    return len(a)
rts=pd.concat([pd.read_csv(root/f'chronological_rts79_{part}.csv') for part in ['single','rolling','protected','other']],ignore_index=True)
print('RTS reproduced archive rows:',compare(pd.read_csv(root/'initial_rts79_diagnostic_archive.csv'),rts))
rts.to_csv(root/'chronological_rts79.csv',index=False)
old=pd.read_csv(root/'chronological_rbts.csv')
rbts=pd.read_csv(root/'chronological_rbts_chron.csv')
print('RBTS chronological rows reproduced:',compare(old[old.family=='chronological'],rbts))
pd.concat([rbts,old[old.family!='chronological']],ignore_index=True).to_csv(root/'chronological_rbts.csv',index=False)
chron=pd.concat([rbts,rts[rts.family=='chronological']])
assert chron.wind_shortfall.notna().all()
print('Chronological physics:',chron.groupby('system').wind_shortfall.agg(['max','sum']).to_string())
