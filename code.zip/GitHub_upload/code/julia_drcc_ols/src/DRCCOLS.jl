module DRCCOLS

using CSV
using Clarabel
using DataFrames
using Dates
using HiGHS
using JSON
using JuMP
using LinearAlgebra
using Printf
using Random
using Statistics
using TOML
using XLSX

const SMALL = 1.0e-9

struct RBTSCase
    base_mva::Float64
    bus::Matrix{Float64}
    gen::Matrix{Float64}
    branch::Matrix{Float64}
    bus_ids::Vector{Int}
    gen_bus_idx::Vector{Int}
    wind_bus_idx::Vector{Int}
    line_rates::Vector{Float64}
    ptdf::Matrix{Float64}
end

struct ExperimentData
    times::Vector{String}
    load_forecast::Matrix{Float64}
    load_actual::Matrix{Float64}
    wind_actual::Matrix{Float64}
    wind_forecast::Matrix{Float64}
    omega::Matrix{Float64}
    wind_quality::DataFrame
    load_quality::DataFrame
end

struct DiagGMM
    weights::Vector{Float64}
    means::Matrix{Float64}
    variances::Matrix{Float64}
    center::Vector{Float64}
    scale::Vector{Float64}
    gamma_train::Matrix{Float64}
    loglik::Float64
end

function parse_matpower_matrix(text::AbstractString, field::AbstractString)
    pat = Regex("mpc\\.$field\\s*=\\s*\\[(.*?)\\];", "s")
    m = match(pat, text)
    m === nothing && error("Cannot find mpc.$field in MATPOWER file")
    rows = Vector{Vector{Float64}}()
    for raw in split(m.captures[1], '\n')
        line = strip(replace(split(raw, "%")[1], ";" => " "))
        isempty(line) && continue
        vals = parse.(Float64, split(line))
        push!(rows, vals)
    end
    ncols = maximum(length.(rows))
    out = zeros(Float64, length(rows), ncols)
    for (i, row) in enumerate(rows)
        out[i, 1:length(row)] .= row
    end
    return out
end

function parse_matpower_scalar(text::AbstractString, field::AbstractString, default::Float64)
    m = match(Regex("mpc\\.$field\\s*=\\s*([0-9.]+)"), text)
    return m === nothing ? default : parse(Float64, m.captures[1])
end

function compute_ptdf(bus::Matrix{Float64}, branch::Matrix{Float64})
    nb = size(bus, 1)
    nl = size(branch, 1)
    ids = Int.(round.(bus[:, 1]))
    id_to_idx = Dict(id => i for (i, id) in enumerate(ids))
    incidence = zeros(Float64, nl, nb)
    susceptance = zeros(Float64, nl)
    for e in 1:nl
        from = id_to_idx[Int(round(branch[e, 1]))]
        to = id_to_idx[Int(round(branch[e, 2]))]
        status = size(branch, 2) >= 11 ? branch[e, 11] : 1.0
        x = branch[e, 4]
        susceptance[e] = status == 0.0 ? 0.0 : 1.0 / x
        incidence[e, from] = 1.0
        incidence[e, to] = -1.0
    end
    bbus = incidence' * Diagonal(susceptance) * incidence
    bf = Diagonal(susceptance) * incidence
    slack_candidates = findall(bus[:, 2] .== 3.0)
    slack = isempty(slack_candidates) ? 1 : first(slack_candidates)
    keep = [i for i in 1:nb if i != slack]
    h = zeros(Float64, nl, nb)
    h[:, keep] = bf[:, keep] * inv(bbus[keep, keep])
    return h
end

function as_int_vector(x)
    return x isa AbstractVector ? Int.(x) : [Int(x)]
end

function as_bool(x)
    x isa Bool && return x
    s = lowercase(String(x))
    return s in ("true", "1", "yes", "y")
end

function parse_float_value(x; default::Float64=0.0)
    ismissing(x) && return default
    x isa Real && return Float64(x)
    s = strip(String(x))
    isempty(s) && return default
    uppercase(s) == "NA" && return default
    val = tryparse(Float64, s)
    return val === nothing ? default : val
end

function parse_int_value(x; default::Int=0)
    return round(Int, parse_float_value(x; default=Float64(default)))
end

function column_vector(df::DataFrame, name::AbstractString)
    return df[!, Symbol(name)]
end

function empty_wind_quality()
    return DataFrame(
        source=String[],
        capacity_mw=Float64[],
        observations=Int[],
        missing_or_nonfinite=Int[],
        negative=Int[],
        above_capacity=Int[],
        isolated_spikes_repaired=Int[],
        suspicious_large_jumps=Int[],
        cleaned_share=Float64[],
        min_cleaned_mw=Float64[],
        max_cleaned_mw=Float64[],
        mean_cleaned_mw=Float64[]
    )
end

function empty_load_quality()
    return DataFrame(
        source=String[],
        bus=Int[],
        observations=Int[],
        missing_or_nonfinite=Int[],
        negative=Int[],
        isolated_spikes_repaired=Int[],
        suspicious_large_jumps=Int[],
        cleaned_share=Float64[],
        min_cleaned_mw=Float64[],
        max_cleaned_mw=Float64[],
        mean_cleaned_mw=Float64[]
    )
end

function wind_capacity_from_filename(path::AbstractString)
    m = match(r"Nominal capacity-([0-9.]+)MW", basename(path))
    return m === nothing ? NaN : parse(Float64, m.captures[1])
end

function fill_missing_wind!(vals::Vector{Float64})
    n = length(vals)
    valid = findall(isfinite, vals)
    if isempty(valid)
        vals .= 0.0
        return n
    end
    first_valid = first(valid)
    last_valid = last(valid)
    vals[1:first_valid-1] .= vals[first_valid]
    vals[last_valid+1:end] .= vals[last_valid]
    repaired = count(!isfinite, vals)
    i = first_valid + 1
    while i < last_valid
        if isfinite(vals[i])
            i += 1
            continue
        end
        lo = i - 1
        hi = i
        while hi <= last_valid && !isfinite(vals[hi])
            hi += 1
        end
        span = hi - lo
        for j in i:hi-1
            vals[j] = vals[lo] + (vals[hi] - vals[lo]) * (j - lo) / span
        end
        i = hi + 1
    end
    return repaired
end

function fill_missing_series!(vals::Vector{Float64})
    n = length(vals)
    valid = findall(isfinite, vals)
    if isempty(valid)
        vals .= 0.0
        return n
    end
    first_valid = first(valid)
    last_valid = last(valid)
    vals[1:first_valid-1] .= vals[first_valid]
    vals[last_valid+1:end] .= vals[last_valid]
    repaired = count(!isfinite, vals)
    i = first_valid + 1
    while i < last_valid
        if isfinite(vals[i])
            i += 1
            continue
        end
        lo = i - 1
        hi = i
        while hi <= last_valid && !isfinite(vals[hi])
            hi += 1
        end
        span = hi - lo
        for j in i:hi-1
            vals[j] = vals[lo] + (vals[hi] - vals[lo]) * (j - lo) / span
        end
        i = hi + 1
    end
    return repaired
end

function repair_isolated_wind_spikes!(vals::Vector{Float64}, capacity::Float64, jump_fraction::Real)
    n = length(vals)
    n < 3 && return 0, 0
    threshold = isfinite(capacity) && capacity > SMALL ? Float64(jump_fraction) * capacity :
        max(4.0 * std(vals), 1.0)
    repaired = 0
    suspicious = 0
    for i in 2:n-1
        left_jump = abs(vals[i] - vals[i-1])
        right_jump = abs(vals[i] - vals[i+1])
        neighbor_jump = abs(vals[i-1] - vals[i+1])
        if left_jump > threshold || right_jump > threshold
            suspicious += 1
        end
        if left_jump > threshold && right_jump > threshold && neighbor_jump <= threshold / 3.0
            vals[i] = 0.5 * (vals[i-1] + vals[i+1])
            repaired += 1
        end
    end
    return repaired, suspicious
end

function repair_isolated_load_spikes!(vals::Vector{Float64}, jump_fraction::Real)
    n = length(vals)
    n < 3 && return 0, 0
    positive = [x for x in vals if isfinite(x) && x > SMALL]
    scale = isempty(positive) ? 0.0 : median(positive)
    threshold = max(Float64(jump_fraction) * scale, 4.0 * std(vals), 1.0)
    repaired = 0
    suspicious = 0
    for i in 2:n-1
        left_jump = abs(vals[i] - vals[i-1])
        right_jump = abs(vals[i] - vals[i+1])
        neighbor_jump = abs(vals[i-1] - vals[i+1])
        if left_jump > threshold || right_jump > threshold
            suspicious += 1
        end
        if left_jump > threshold && right_jump > threshold && neighbor_jump <= threshold / 3.0
            vals[i] = 0.5 * (vals[i-1] + vals[i+1])
            repaired += 1
        end
    end
    return repaired, suspicious
end

function clean_wind_series(raw_values, source::AbstractString; capacity::Real=NaN,
        capacity_tolerance::Real=0.02, jump_fraction::Real=0.75,
        repair_isolated_spikes::Bool=true)
    vals = [parse_float_value(v; default=NaN) for v in raw_values]
    missing_count = count(!isfinite, vals)
    negative_count = count(x -> isfinite(x) && x < 0.0, vals)
    for i in eachindex(vals)
        if isfinite(vals[i]) && vals[i] < 0.0
            vals[i] = 0.0
        end
    end
    cap = Float64(capacity)
    above_capacity_count = 0
    if isfinite(cap) && cap > SMALL
        high_limit = cap * (1.0 + Float64(capacity_tolerance))
        above_capacity_count = count(x -> isfinite(x) && x > high_limit, vals)
        for i in eachindex(vals)
            if isfinite(vals[i]) && vals[i] > cap
                vals[i] = cap
            end
        end
    end
    interpolated_count = fill_missing_wind!(vals)
    spike_count = 0
    suspicious_count = 0
    if repair_isolated_spikes
        spike_count, suspicious_count = repair_isolated_wind_spikes!(vals, cap, jump_fraction)
    end
    cleaned_events = missing_count + negative_count + above_capacity_count + spike_count
    quality = empty_wind_quality()
    push!(quality, (
        source=String(source),
        capacity_mw=cap,
        observations=length(vals),
        missing_or_nonfinite=missing_count,
        negative=negative_count,
        above_capacity=above_capacity_count,
        isolated_spikes_repaired=spike_count,
        suspicious_large_jumps=suspicious_count,
        cleaned_share=length(vals) == 0 ? 0.0 : cleaned_events / length(vals),
        min_cleaned_mw=isempty(vals) ? NaN : minimum(vals),
        max_cleaned_mw=isempty(vals) ? NaN : maximum(vals),
        mean_cleaned_mw=isempty(vals) ? NaN : mean(vals)
    ))
    return vals, quality
end

function clean_load_series(raw_values, source::AbstractString, bus::Integer;
        jump_fraction::Real=0.75, repair_isolated_spikes::Bool=true)
    vals = [parse_float_value(v; default=NaN) for v in raw_values]
    missing_count = count(!isfinite, vals)
    negative_count = count(x -> isfinite(x) && x < 0.0, vals)
    for i in eachindex(vals)
        if isfinite(vals[i]) && vals[i] < 0.0
            vals[i] = 0.0
        end
    end
    fill_missing_series!(vals)
    spike_count = 0
    suspicious_count = 0
    if repair_isolated_spikes
        spike_count, suspicious_count = repair_isolated_load_spikes!(vals, jump_fraction)
    end
    cleaned_events = missing_count + negative_count + spike_count
    quality = empty_load_quality()
    push!(quality, (
        source=String(source),
        bus=Int(bus),
        observations=length(vals),
        missing_or_nonfinite=missing_count,
        negative=negative_count,
        isolated_spikes_repaired=spike_count,
        suspicious_large_jumps=suspicious_count,
        cleaned_share=length(vals) == 0 ? 0.0 : cleaned_events / length(vals),
        min_cleaned_mw=isempty(vals) ? NaN : minimum(vals),
        max_cleaned_mw=isempty(vals) ? NaN : maximum(vals),
        mean_cleaned_mw=isempty(vals) ? NaN : mean(vals)
    ))
    return vals, quality
end

function clean_load_matrix(mat::Matrix{Float64}, source::AbstractString;
        jump_fraction::Real=0.75, repair_isolated_spikes::Bool=true)
    cleaned = copy(mat)
    quality_parts = DataFrame[]
    for b in 1:size(cleaned, 2)
        vals, quality = clean_load_series(cleaned[:, b], source, b;
            jump_fraction=jump_fraction,
            repair_isolated_spikes=repair_isolated_spikes)
        cleaned[:, b] .= vals
        push!(quality_parts, quality)
    end
    quality = isempty(quality_parts) ? empty_load_quality() : vcat(quality_parts...; cols=:union)
    return cleaned, quality
end

function load_rbts(path::AbstractString; wind_bus=6, replace_gen_indices=Int[], pmin_scale::Real=1.0)
    text = read(path, String)
    bus = parse_matpower_matrix(text, "bus")
    gen = parse_matpower_matrix(text, "gen")
    branch = parse_matpower_matrix(text, "branch")
    base_mva = parse_matpower_scalar(text, "baseMVA", 100.0)
    bus_ids = Int.(round.(bus[:, 1]))
    id_to_idx = Dict(id => i for (i, id) in enumerate(bus_ids))

    replace_ids = as_int_vector(replace_gen_indices)
    if !isempty(replace_ids)
        any(i -> i < 1 || i > size(gen, 1), replace_ids) &&
            error("replace_gen_indices contains an index outside 1:$(size(gen, 1))")
        length(unique(replace_ids)) == length(replace_ids) ||
            error("replace_gen_indices must not contain duplicates")
        replaced_bus_ids = Int.(round.(gen[replace_ids, 1]))
        wind_bus_idx = [id_to_idx[id] for id in replaced_bus_ids]
        keep = trues(size(gen, 1))
        keep[replace_ids] .= false
        gen = gen[keep, :]
    else
        wind_bus_idx = [id_to_idx[Int(wb)] for wb in as_int_vector(wind_bus)]
    end
    gen[:, 10] .*= Float64(pmin_scale)

    gen_bus_idx = [id_to_idx[Int(round(gen[j, 1]))] for j in 1:size(gen, 1)]
    line_rates = branch[:, 6]
    ptdf = compute_ptdf(bus, branch)
    return RBTSCase(base_mva, bus, gen, branch, bus_ids, gen_bus_idx, wind_bus_idx, line_rates, ptdf)
end

function gmlc_source_dir(root::AbstractString)
    return joinpath(root, "SourceData")
end

function gmlc_timeseries_dir(root::AbstractString)
    return joinpath(root, "timeseries_data_files")
end

function gmlc_wind_columns(root::AbstractString, wind_columns=String[])
    wind_path = joinpath(gmlc_timeseries_dir(root), "WIND", "DAY_AHEAD_wind.csv")
    header = split(readline(wind_path), ",")
    available = String.(header[5:end])
    selected = wind_columns === nothing ? String[] : as_string_vector(wind_columns)
    isempty(selected) && return available
    missing_cols = setdiff(selected, available)
    isempty(missing_cols) || error("RTS_GMLC wind columns not found: $(join(missing_cols, ", "))")
    return selected
end

function gmlc_wind_bus_ids(wind_columns::Vector{String})
    return [parse(Int, split(col, "_")[1]) for col in wind_columns]
end

function gmlc_wind_capacities(root::AbstractString, wind_columns::Vector{String})
    gen_df = CSV.read(joinpath(gmlc_source_dir(root), "gen.csv"), DataFrame)
    cap_by_uid = Dict{String, Float64}()
    for row in eachrow(gen_df)
        uid = String(row[Symbol("GEN UID")])
        cap_by_uid[uid] = parse_float_value(row[Symbol("PMax MW")]; default=NaN)
    end
    return [get(cap_by_uid, col, NaN) for col in wind_columns]
end

function gmlc_bus_matrix(bus_df::DataFrame)
    nb = nrow(bus_df)
    bus = zeros(Float64, nb, 13)
    bus_ids = [parse_int_value(v) for v in column_vector(bus_df, "Bus ID")]
    for i in 1:nb
        bus[i, 1] = bus_ids[i]
        bus_type = uppercase(strip(String(column_vector(bus_df, "Bus Type")[i])))
        bus[i, 2] = occursin("REF", bus_type) || occursin("SLACK", bus_type) ? 3.0 :
                    occursin("PV", bus_type) ? 2.0 : 1.0
        bus[i, 3] = parse_float_value(column_vector(bus_df, "MW Load")[i])
        bus[i, 4] = parse_float_value(column_vector(bus_df, "MVAR Load")[i])
        bus[i, 8] = parse_float_value(column_vector(bus_df, "V Angle")[i])
        bus[i, 9] = parse_float_value(column_vector(bus_df, "MW Shunt G")[i])
        bus[i, 10] = parse_float_value(column_vector(bus_df, "MVAR Shunt B")[i])
        bus[i, 11] = parse_float_value(column_vector(bus_df, "Area")[i])
        bus[i, 12] = 1.0
        bus[i, 13] = parse_float_value(column_vector(bus_df, "BaseKV")[i])
    end
    if !any(bus[:, 2] .== 3.0)
        slack = something(findfirst(bus[:, 2] .== 2.0), 1)
        bus[slack, 2] = 3.0
    end
    return bus, bus_ids
end

function is_gmlc_dispatchable(row)
    uid = uppercase(strip(String(row[Symbol("GEN UID")])))
    fuel = uppercase(strip(String(row[Symbol("Fuel")])))
    category = uppercase(strip(String(row[Symbol("Category")])))
    pmax = parse_float_value(row[Symbol("PMax MW")])
    pmax <= SMALL && return false
    occursin("WIND", uid) && return false
    fuel in ("WIND", "SOLAR", "STORAGE", "SYNC_COND") && return false
    occursin("SOLAR", category) && return false
    category in ("CSP", "WIND", "STORAGE", "SYNC_COND") && return false
    return true
end

function gmlc_gen_matrix(gen_df::DataFrame; aggregate_generators::Bool=true, pmin_scale::Real=0.0)
    if aggregate_generators
        agg = Dict{Int, Vector{Float64}}()
        for row in eachrow(gen_df)
            is_gmlc_dispatchable(row) || continue
            bus_id = parse_int_value(row[Symbol("Bus ID")])
            vals = get!(agg, bus_id, [0.0, 0.0, 0.0])
            vals[1] += parse_float_value(row[Symbol("PMax MW")])
            vals[2] += Float64(pmin_scale) * parse_float_value(row[Symbol("PMin MW")])
            vals[3] += parse_float_value(row[Symbol("MW Inj")])
        end
        keys_sorted = sort(collect(keys(agg)))
        gen = zeros(Float64, length(keys_sorted), 21)
        for (j, bus_id) in enumerate(keys_sorted)
            pmax, pmin, pg = agg[bus_id]
            gen[j, 1] = bus_id
            gen[j, 2] = clamp(pg, pmin, pmax)
            gen[j, 6] = 1.0
            gen[j, 7] = 100.0
            gen[j, 8] = 1.0
            gen[j, 9] = pmax
            gen[j, 10] = pmin
        end
        return gen
    end
    rows = [row for row in eachrow(gen_df) if is_gmlc_dispatchable(row)]
    gen = zeros(Float64, length(rows), 21)
    for (j, row) in enumerate(rows)
        pmax = parse_float_value(row[Symbol("PMax MW")])
        pmin = Float64(pmin_scale) * parse_float_value(row[Symbol("PMin MW")])
        gen[j, 1] = parse_int_value(row[Symbol("Bus ID")])
        gen[j, 2] = clamp(parse_float_value(row[Symbol("MW Inj")]), pmin, pmax)
        gen[j, 6] = 1.0
        gen[j, 7] = 100.0
        gen[j, 8] = 1.0
        gen[j, 9] = pmax
        gen[j, 10] = pmin
    end
    return gen
end

function gmlc_branch_matrix(branch_df::DataFrame, bus_ids::Vector{Int})
    idset = Set(bus_ids)
    rows = Vector{Vector{Float64}}()
    for row in eachrow(branch_df)
        from = parse_int_value(row[Symbol("From Bus")])
        to = parse_int_value(row[Symbol("To Bus")])
        (from in idset && to in idset) || continue
        x = parse_float_value(row[Symbol("X")])
        abs(x) > SMALL || continue
        rate = parse_float_value(row[Symbol("Cont Rating")]; default=1.0e6)
        rate = rate <= SMALL ? 1.0e6 : rate
        push!(rows, [
            Float64(from),
            Float64(to),
            parse_float_value(row[Symbol("R")]),
            x,
            parse_float_value(row[Symbol("B")]),
            rate,
            rate,
            rate,
            0.0,
            0.0,
            1.0,
            -360.0,
            360.0
        ])
    end
    branch = zeros(Float64, length(rows), 13)
    for (i, row) in enumerate(rows)
        branch[i, :] .= row
    end
    return branch
end

function load_gmlc_case(root::AbstractString; wind_columns=String[],
        aggregate_generators::Bool=true, pmin_scale::Real=0.0)
    src = gmlc_source_dir(root)
    bus_df = CSV.read(joinpath(src, "bus.csv"), DataFrame)
    gen_df = CSV.read(joinpath(src, "gen.csv"), DataFrame)
    branch_df = CSV.read(joinpath(src, "branch.csv"), DataFrame)
    bus, bus_ids = gmlc_bus_matrix(bus_df)
    gen = gmlc_gen_matrix(gen_df; aggregate_generators=aggregate_generators, pmin_scale=pmin_scale)
    branch = gmlc_branch_matrix(branch_df, bus_ids)
    id_to_idx = Dict(id => i for (i, id) in enumerate(bus_ids))
    gen_bus_idx = [id_to_idx[Int(round(gen[j, 1]))] for j in 1:size(gen, 1)]
    wind_names = gmlc_wind_columns(root, wind_columns)
    wind_bus_idx = [id_to_idx[id] for id in gmlc_wind_bus_ids(wind_names)]
    line_rates = branch[:, 6]
    ptdf = compute_ptdf(bus, branch)
    return RBTSCase(100.0, bus, gen, branch, bus_ids, gen_bus_idx, wind_bus_idx, line_rates, ptdf)
end

function bus_matrix_from_csv(path::AbstractString, nb::Integer)
    df = CSV.read(path, DataFrame)
    mat = zeros(Float64, nrow(df), nb)
    for cname in names(df)[2:end]
        bus_id = parse(Int, String(cname))
        1 <= bus_id <= nb || continue
        mat[:, bus_id] .= [parse_float_value(v; default=NaN) for v in df[!, cname]]
    end
    return String.(df[!, names(df)[1]]), mat
end

function sequential_hourly_calendar(times::Vector{String})
    isempty(times) && return String[]
    start = to_datetime(times[1])
    return [Dates.format(start + Hour(i - 1), dateformat"yyyy-mm-dd HH:MM") for i in 1:length(times)]
end

function to_datetime(v)
    v isa DateTime && return v
    v isa Date && return DateTime(v)
    s = strip(string(v))
    for fmt in (dateformat"yyyy-mm-dd HH:MM:SS", dateformat"yyyy-mm-dd HH:MM",
                dateformat"yyyy-mm-dd H:M", dateformat"yyyy/mm/dd HH:MM:SS",
                dateformat"yyyy/mm/dd HH:MM")
        dt = tryparse(DateTime, s, fmt)
        dt !== nothing && return dt
    end
    error("Unrecognized timestamp: $s")
end

# Place an hour-keyed series (times, vals) on a dense, gap-free hourly grid over
# [t0, t1].  Missing clock hours are filled by fill_missing_series! so that every
# wind farm shares an identical, continuous hourly timestamp vector.
function dense_hourly(times::Vector{String}, vals::Vector{Float64}, t0::DateTime, t1::DateTime)
    lookup = Dict(times[i] => vals[i] for i in 1:length(times))
    out_times = String[]
    out_vals = Float64[]
    t = t0
    while t <= t1
        key = Dates.format(t, dateformat"yyyy-mm-dd HH:MM")
        push!(out_times, key)
        push!(out_vals, get(lookup, key, NaN))
        t += Hour(1)
    end
    fill_missing_series!(out_vals)
    return out_times, out_vals
end

function read_wind_hourly(path::AbstractString; capacity::Real=wind_capacity_from_filename(path),
        capacity_tolerance::Real=0.02, jump_fraction::Real=0.75,
        repair_isolated_spikes::Bool=true)
    sheet = XLSX.openxlsx(path) do xf
        XLSX.sheetnames(xf)[1]
    end
    raw = DataFrame(XLSX.readtable(path, sheet; infer_eltypes=true))
    power_col = first([name for name in names(raw) if occursin("Power", String(name))])
    time_col = first([name for name in names(raw) if occursin("Time", String(name))])
    power, quality = clean_wind_series(raw[!, power_col], basename(path);
        capacity=capacity,
        capacity_tolerance=capacity_tolerance,
        jump_fraction=jump_fraction,
        repair_isolated_spikes=repair_isolated_spikes)
    # Bucket the (15-minute) samples into clock hours by their own timestamps so
    # that intra-hour averaging is calendar-correct even when a series starts off
    # the hour or has internal gaps.
    stamps = raw[!, time_col]
    buckets = Dict{String, Vector{Float64}}()
    order = String[]
    for i in 1:length(power)
        dt = floor(to_datetime(stamps[i]), Hour(1))
        key = Dates.format(dt, dateformat"yyyy-mm-dd HH:MM")
        if !haskey(buckets, key)
            buckets[key] = Float64[]
            push!(order, key)
        end
        push!(buckets[key], power[i])
    end
    sort!(order)
    hourly = [mean(buckets[k]) for k in order]
    return order, hourly, quality
end

function lag_forecast(actual::Vector{Float64}, lag::Integer)
    n = length(actual)
    forecast = zeros(Float64, n)
    seed_mean = mean(@view actual[1:min(n, max(1, lag))])
    for t in 1:n
        forecast[t] = t > lag ? actual[t-lag] : (t > 1 ? actual[t-1] : seed_mean)
    end
    return forecast
end

function as_string_vector(x)
    return x isa AbstractVector ? String.(x) : [String(x)]
end

function as_float_vector(x)
    return x isa AbstractVector ? Float64.(x) : [Float64(x)]
end

function expand_to_length(vals::Vector{Float64}, n::Integer)
    length(vals) == n && return vals
    length(vals) == 1 && return fill(vals[1], n)
    error("Expected either 1 value or $n values, got $(length(vals))")
end

function load_experiment_data(case::RBTSCase, system_loads::AbstractString, bus_loads::AbstractString,
        wind_xlsx; wind_scale=0.5, wind_lag::Integer=24, error_scale::Real=1.0,
        wind_capacity_tolerance::Real=0.02, wind_jump_fraction::Real=0.75,
        wind_repair_isolated_spikes::Bool=true,
        load_jump_fraction::Real=0.75, load_repair_isolated_spikes::Bool=true)
    times_lf, load_forecast = bus_matrix_from_csv(system_loads, size(case.bus, 1))
    times_la, load_actual = bus_matrix_from_csv(bus_loads, size(case.bus, 1))
    times_la == times_lf || @warn "Load forecast/actual timestamps differ; using forecast calendar."
    # The RBTS/RTS79 load files use a power-system hour-ending convention in
    # which the 24th hourly row can be written as 0:00 on the row's operating
    # day.  Rebuild the calendar by row order so downstream rolling windows see
    # a unique, gap-free hourly axis.
    times_lf = sequential_hourly_calendar(times_lf)
    times_la = sequential_hourly_calendar(times_la)
    load_forecast, load_forecast_quality = clean_load_matrix(load_forecast, "load_forecast";
        jump_fraction=load_jump_fraction,
        repair_isolated_spikes=load_repair_isolated_spikes)
    load_actual, load_actual_quality = clean_load_matrix(load_actual, "load_actual";
        jump_fraction=load_jump_fraction,
        repair_isolated_spikes=load_repair_isolated_spikes)
    load_quality = vcat(load_forecast_quality, load_actual_quality; cols=:union)
    wind_paths = as_string_vector(wind_xlsx)
    scales = expand_to_length(as_float_vector(wind_scale), length(wind_paths))
    wind_reads = [read_wind_hourly(path;
        capacity_tolerance=wind_capacity_tolerance,
        jump_fraction=wind_jump_fraction,
        repair_isolated_spikes=wind_repair_isolated_spikes) for path in wind_paths]
    wind_quality = vcat([r[3] for r in wind_reads]...; cols=:union)
    # Put every wind farm on one shared, gap-free hourly grid over their common
    # span so the farms are mutually time-consistent (fixes the site-5 offset).
    fmt = dateformat"yyyy-mm-dd HH:MM"
    t0 = maximum(DateTime(first(r[1]), fmt) for r in wind_reads)
    t1 = minimum(DateTime(last(r[1]), fmt) for r in wind_reads)
    t0 <= t1 || error("Wind farms have no overlapping hourly span")
    wind_times = String[]
    wind_dense = Vector{Vector{Float64}}()
    for (k, r) in enumerate(wind_reads)
        tk, vk = dense_hourly(r[1], r[2], t0, t1)
        k == 1 && (wind_times = tk)
        push!(wind_dense, vk)
    end
    # Wind (2019-2020) and load (2022) share no calendar, so they are paired as an
    # explicit synthetic benchmark: shift the wind grid so its hour-of-day matches
    # the load calendar, then pair sequentially (both advance Jan->Dec from the
    # start, keeping diurnal phase and seasonal phase consistent).
    load_hod = Dates.hour(to_datetime(times_lf[1]))
    w0 = findfirst(ts -> Dates.hour(DateTime(ts, fmt)) == load_hod, wind_times)
    w0 === nothing && (w0 = 1)
    wind_times = wind_times[w0:end]
    wind_dense = [v[w0:end] for v in wind_dense]
    n = minimum(vcat([size(load_forecast, 1), size(load_actual, 1)], length.(wind_dense)))
    load_forecast = load_forecast[1:n, :]
    load_actual = load_actual[1:n, :]
    times = times_lf[1:n]
    nw = length(wind_paths)
    wind_actual = zeros(Float64, n, nw)
    wind_forecast = zeros(Float64, n, nw)
    for w in 1:nw
        wind_actual[:, w] .= scales[w] .* wind_dense[w][1:n]
        wind_forecast[:, w] .= scales[w] .* lag_forecast(wind_dense[w][1:n], wind_lag)
    end
    # Nodal net-injection error: (wind actual - forecast) - (load actual - forecast).
    omega = .-(load_actual .- load_forecast)
    length(case.wind_bus_idx) == nw || error("Number of wind buses ($(length(case.wind_bus_idx))) must match wind files ($nw)")
    for (w, wb) in enumerate(case.wind_bus_idx)
        omega[:, wb] .+= wind_actual[:, w] .- wind_forecast[:, w]
    end
    omega .*= Float64(error_scale)
    return ExperimentData(times, load_forecast, load_actual, wind_actual, wind_forecast, omega, wind_quality, load_quality)
end

function read_gmlc_timeseries(path::AbstractString, value_cols::Vector{String})
    df = CSV.read(path, DataFrame)
    n = nrow(df)
    years = [parse_int_value(df[i, Symbol("Year")]) for i in 1:n]
    months = [parse_int_value(df[i, Symbol("Month")]) for i in 1:n]
    days = [parse_int_value(df[i, Symbol("Day")]) for i in 1:n]
    periods = [parse_int_value(df[i, Symbol("Period")]) for i in 1:n]
    raw = zeros(Float64, n, length(value_cols))
    for (j, col) in enumerate(value_cols)
        raw[:, j] .= [parse_float_value(v; default=NaN) for v in df[!, Symbol(col)]]
    end
    # Periods per day: 24 for the day-ahead hourly grid, 288 for the 5-minute
    # real-time grid.  Sub-hourly series are averaged into clock hours so that
    # the day-ahead and real-time series share a common hourly timestamp grid.
    max_period = isempty(periods) ? 24 : maximum(periods)
    periods_per_hour = max(1, div(max_period, 24))
    if periods_per_hour == 1
        times = [Dates.format(DateTime(years[i], months[i], days[i]) + Hour(max(periods[i] - 1, 0)),
            dateformat"yyyy-mm-dd HH:MM") for i in 1:n]
        return times, raw
    end
    buckets = Dict{String, Vector{Int}}()
    order = String[]
    for i in 1:n
        hour = div(max(periods[i] - 1, 0), periods_per_hour)
        key = Dates.format(DateTime(years[i], months[i], days[i]) + Hour(hour), dateformat"yyyy-mm-dd HH:MM")
        if !haskey(buckets, key)
            buckets[key] = Int[]
            push!(order, key)
        end
        push!(buckets[key], i)
    end
    sort!(order)
    hourly = zeros(Float64, length(order), length(value_cols))
    for (h, key) in enumerate(order)
        rows = buckets[key]
        for j in 1:length(value_cols)
            vals = [raw[r, j] for r in rows if isfinite(raw[r, j])]
            hourly[h, j] = isempty(vals) ? NaN : mean(vals)
        end
    end
    return order, hourly
end

# Restrict a collection of (timestamp, matrix) series to their common timestamps,
# returned in chronological order.  Alignment is by timestamp, never by row index,
# so day-ahead (forecast) and real-time (actual) series stay time-consistent even
# when they have different native resolutions or partial coverage.
function align_series_by_time(series::Vector{<:Tuple{Vector{String}, Matrix{Float64}}})
    isempty(series) && error("align_series_by_time requires at least one series")
    common = Set(series[1][1])
    for k in 2:length(series)
        common = intersect(common, Set(series[k][1]))
    end
    common_sorted = sort(collect(common))
    isempty(common_sorted) && error("align_series_by_time found no overlapping timestamps across series")
    aligned = Matrix{Float64}[]
    for (times, mat) in series
        idx = Dict(times[i] => i for i in 1:length(times))
        rows = [idx[ts] for ts in common_sorted]
        push!(aligned, mat[rows, :])
    end
    return common_sorted, aligned
end

function distribute_gmlc_regional_loads(case::RBTSCase, root::AbstractString,
        regional::Matrix{Float64}, region_cols::Vector{String}; load_scale::Real=1.0)
    bus_df = CSV.read(joinpath(gmlc_source_dir(root), "bus.csv"), DataFrame)
    static_load = Dict{Int, Float64}()
    bus_area = Dict{Int, String}()
    for row in eachrow(bus_df)
        bus_id = parse_int_value(row[Symbol("Bus ID")])
        static_load[bus_id] = max(parse_float_value(row[Symbol("MW Load")]), 0.0)
        bus_area[bus_id] = string(parse_int_value(row[Symbol("Area")]))
    end
    area_to_indices = Dict{String, Vector{Int}}(area => Int[] for area in region_cols)
    for (idx, bus_id) in enumerate(case.bus_ids)
        area = get(bus_area, bus_id, "")
        haskey(area_to_indices, area) && push!(area_to_indices[area], idx)
    end
    mat = zeros(Float64, size(regional, 1), length(case.bus_ids))
    for (ridx, area) in enumerate(region_cols)
        bus_indices = get(area_to_indices, area, Int[])
        isempty(bus_indices) && continue
        weights = [get(static_load, case.bus_ids[idx], 0.0) for idx in bus_indices]
        total_weight = sum(weights)
        if total_weight <= SMALL
            weights .= 1.0 / length(weights)
        else
            weights ./= total_weight
        end
        for (local_i, bus_idx) in enumerate(bus_indices)
            mat[:, bus_idx] .+= Float64(load_scale) .* regional[:, ridx] .* weights[local_i]
        end
    end
    return mat
end

function load_gmlc_load_data(case::RBTSCase, root::AbstractString; load_scale::Real=1.0)
    load_dir = joinpath(gmlc_timeseries_dir(root), "Load")
    da_path = joinpath(load_dir, "DAY_AHEAD_regional_Load.csv")
    rt_path = joinpath(load_dir, "REAL_TIME_regional_Load.csv")
    header = split(readline(da_path), ",")
    region_cols = String.(header[5:end])
    da_times, regional_forecast = read_gmlc_timeseries(da_path, region_cols)
    rt_times, regional_actual = read_gmlc_timeseries(rt_path, region_cols)
    times, aligned = align_series_by_time([(da_times, regional_forecast), (rt_times, regional_actual)])
    load_forecast = distribute_gmlc_regional_loads(case, root, aligned[1], region_cols; load_scale=load_scale)
    load_actual = distribute_gmlc_regional_loads(case, root, aligned[2], region_cols; load_scale=load_scale)
    return times, load_forecast, load_actual
end

function load_gmlc_experiment_data(case::RBTSCase, root::AbstractString;
        wind_columns=String[], wind_scale=1.0, load_scale::Real=1.0, error_scale::Real=1.0,
        wind_capacity_tolerance::Real=0.02, wind_jump_fraction::Real=0.75,
        wind_repair_isolated_spikes::Bool=true,
        load_jump_fraction::Real=0.75, load_repair_isolated_spikes::Bool=true)
    times_load, load_forecast_raw, load_actual_raw = load_gmlc_load_data(case, root; load_scale=load_scale)
    wind_names = gmlc_wind_columns(root, wind_columns)
    wind_dir = joinpath(gmlc_timeseries_dir(root), "WIND")
    wf_times, wind_forecast_raw = read_gmlc_timeseries(joinpath(wind_dir, "DAY_AHEAD_wind.csv"), wind_names)
    wa_times, wind_actual_raw = read_gmlc_timeseries(joinpath(wind_dir, "REAL_TIME_wind.csv"), wind_names)
    # Align load forecast/actual and wind forecast/actual on a common hourly timestamp grid.
    times, aligned = align_series_by_time([
        (times_load, load_forecast_raw),
        (times_load, load_actual_raw),
        (wf_times, wind_forecast_raw),
        (wa_times, wind_actual_raw),
    ])
    load_forecast = aligned[1]
    load_actual = aligned[2]
    wind_forecast = aligned[3]
    wind_actual = aligned[4]
    load_forecast, load_forecast_quality = clean_load_matrix(load_forecast, "load_forecast";
        jump_fraction=load_jump_fraction,
        repair_isolated_spikes=load_repair_isolated_spikes)
    load_actual, load_actual_quality = clean_load_matrix(load_actual, "load_actual";
        jump_fraction=load_jump_fraction,
        repair_isolated_spikes=load_repair_isolated_spikes)
    load_quality = vcat(load_forecast_quality, load_actual_quality; cols=:union)
    nw = length(wind_names)
    scales = expand_to_length(as_float_vector(wind_scale), nw)
    capacities = gmlc_wind_capacities(root, wind_names)
    quality_parts = DataFrame[]
    for w in 1:nw
        cleaned_forecast, forecast_quality = clean_wind_series(wind_forecast[:, w], "DAY_AHEAD_$(wind_names[w])";
            capacity=capacities[w],
            capacity_tolerance=wind_capacity_tolerance,
            jump_fraction=wind_jump_fraction,
            repair_isolated_spikes=wind_repair_isolated_spikes)
        cleaned_actual, actual_quality = clean_wind_series(wind_actual[:, w], "REAL_TIME_$(wind_names[w])";
            capacity=capacities[w],
            capacity_tolerance=wind_capacity_tolerance,
            jump_fraction=wind_jump_fraction,
            repair_isolated_spikes=wind_repair_isolated_spikes)
        wind_forecast[:, w] .= cleaned_forecast
        wind_actual[:, w] .= cleaned_actual
        push!(quality_parts, forecast_quality)
        push!(quality_parts, actual_quality)
    end
    wind_quality = isempty(quality_parts) ? empty_wind_quality() : vcat(quality_parts...; cols=:union)
    for w in 1:nw
        wind_forecast[:, w] .*= scales[w]
        wind_actual[:, w] .*= scales[w]
    end
    # Nodal net-injection error: (wind actual - forecast) - (load actual - forecast).
    omega = .-(load_actual .- load_forecast)
    length(case.wind_bus_idx) == nw || error("Number of RTS_GMLC wind buses ($(length(case.wind_bus_idx))) must match wind columns ($nw)")
    for (w, wb) in enumerate(case.wind_bus_idx)
        omega[:, wb] .+= wind_actual[:, w] .- wind_forecast[:, w]
    end
    omega .*= Float64(error_scale)
    return ExperimentData(times, load_forecast, load_actual, wind_actual, wind_forecast, omega, wind_quality, load_quality)
end

function logsumexp(v::AbstractVector{<:Real})
    m = maximum(v)
    return m + log(sum(exp.(v .- m)))
end

function standardize(x::Matrix{Float64})
    center = vec(mean(x, dims=1))
    scale = vec(std(x, dims=1))
    scale .= ifelse.(scale .< 1.0e-6, 1.0, scale)
    z = (x .- center') ./ scale'
    return z, center, scale
end

function diag_logpdf_rows(x::Matrix{Float64}, means::Matrix{Float64}, vars::Matrix{Float64}, weights::Vector{Float64})
    n, d = size(x)
    kmax = length(weights)
    out = zeros(Float64, n, kmax)
    for k in 1:kmax
        const_term = log(max(weights[k], SMALL)) - 0.5 * sum(log.(2.0 * pi .* vars[k, :]))
        for i in 1:n
            q = sum(((x[i, :] .- means[k, :]).^2) ./ vars[k, :])
            out[i, k] = const_term - 0.5 * q
        end
    end
    return out
end

function responsibilities_from_standardized(x::Matrix{Float64}, weights::Vector{Float64},
        means::Matrix{Float64}, vars::Matrix{Float64})
    logp = diag_logpdf_rows(x, means, vars, weights)
    n, kmax = size(logp)
    gamma = zeros(Float64, n, kmax)
    ll = 0.0
    for i in 1:n
        lse = logsumexp(@view logp[i, :])
        ll += lse
        gamma[i, :] .= exp.(@view(logp[i, :]) .- lse)
    end
    return gamma, ll
end

function fit_diag_gmm(raw_x::Matrix{Float64}, kmax::Integer; max_iter::Integer=100,
        seed::Integer=1, reg::Real=1.0e-4)
    Random.seed!(seed)
    x, center, scale = standardize(raw_x)
    n, d = size(x)
    kmax <= n || error("K=$kmax is larger than the number of training samples $n")
    score = vec(sum(x, dims=2))
    order = sortperm(score)
    init_idx = [order[clamp(round(Int, 1 + (j - 1) * (n - 1) / max(1, kmax - 1)), 1, n)] for j in 1:kmax]
    means = copy(x[init_idx, :])
    vars = repeat(vec(var(x, dims=1))', kmax, 1) .+ reg
    weights = fill(1.0 / kmax, kmax)
    gamma = fill(1.0 / kmax, n, kmax)
    old_ll = -Inf
    ll = -Inf
    for _ in 1:max_iter
        gamma, ll = responsibilities_from_standardized(x, weights, means, vars)
        nk = vec(sum(gamma, dims=1)) .+ SMALL
        weights = nk ./ sum(nk)
        for k in 1:kmax
            means[k, :] .= vec((gamma[:, k]' * x) ./ nk[k])
            diffs = x .- means[k, :]'
            vars[k, :] .= vec((gamma[:, k]' * (diffs .^ 2)) ./ nk[k]) .+ reg
        end
        isfinite(old_ll) && abs(ll - old_ll) <= 1.0e-5 * max(1.0, abs(old_ll)) && break
        old_ll = ll
    end
    gamma, ll = responsibilities_from_standardized(x, weights, means, vars)
    return DiagGMM(weights, means, vars, center, scale, gamma, ll)
end

function responsibilities(gmm::DiagGMM, raw_x::Matrix{Float64})
    z = (raw_x .- gmm.center') ./ gmm.scale'
    gamma, _ = responsibilities_from_standardized(z, gmm.weights, gmm.means, gmm.variances)
    return gamma
end

function responsibility(gmm::DiagGMM, raw_x::AbstractVector{<:Real})
    mat = reshape(Float64.(raw_x), 1, :)
    return vec(responsibilities(gmm, mat))
end

function representative_indices(gamma::Matrix{Float64}, rep_ratio::Real;
        max_per_regime::Integer=25, max_total::Integer=0)
    n, kmax = size(gamma)
    hard = [argmax(@view gamma[i, :]) for i in 1:n]
    reps = Vector{Vector{Int}}(undef, kmax)
    for k in 1:kmax
        candidates = findall(==(k), hard)
        if isempty(candidates)
            candidates = sortperm(gamma[:, k], rev=true)[1:1]
        end
        q = max(1, ceil(Int, rep_ratio * length(candidates)))
        q = max_per_regime > 0 ? min(q, max_per_regime) : q
        ordered = sort(candidates, by=i -> gamma[i, k], rev=true)
        reps[k] = ordered[1:min(q, length(ordered))]
    end
    if max_total > 0 && sum(length.(reps)) > max_total
        keep = [Set{Int}() for _ in 1:kmax]
        # Keep one high-responsibility representative per nonempty regime first.
        for k in 1:kmax
            if !isempty(reps[k]) && sum(length.(keep)) < max_total
                push!(keep[k], reps[k][1])
            end
        end
        pool = Tuple{Float64,Int,Int}[]
        for k in 1:kmax
            for i in reps[k]
                i in keep[k] && continue
                push!(pool, (gamma[i, k], k, i))
            end
        end
        sort!(pool, by=x -> x[1], rev=true)
        for (_, k, i) in pool
            sum(length.(keep)) >= max_total && break
            push!(keep[k], i)
        end
        for k in 1:kmax
            reps[k] = [i for i in reps[k] if i in keep[k]]
        end
    end
    return reps
end

function rolling_weights_from_history(gmm::DiagGMM, gamma_history::Matrix{Float64},
        omega_hat::Vector{Float64}; window::Integer=24, kappa::Real=5.0,
        blend_rho::Real=0.5)
    kmax = length(gmm.weights)
    n = size(gamma_history, 1)
    if n > 0
        past_lo = max(1, n - window + 1)
        roll_counts = vec(sum(view(gamma_history, past_lo:n, :), dims=1))
        denom = (n - past_lo + 1) + kappa
    else
        roll_counts = zeros(Float64, kmax)
        denom = kappa
    end
    pi_roll = (roll_counts .+ kappa .* gmm.weights) ./ denom
    pi_pred = responsibility(gmm, omega_hat)
    pi = blend_rho .* pi_pred .+ (1.0 - blend_rho) .* pi_roll
    return pi ./ sum(pi)
end

function rolling_weights(gmm::DiagGMM, gamma_all::Matrix{Float64}, omega_hat::Vector{Float64},
        t::Integer; window::Integer=24, kappa::Real=5.0, blend_rho::Real=0.5)
    kmax = length(gmm.weights)
    past_hi = max(0, t - 1)
    past_lo = max(1, past_hi - window + 1)
    if past_hi >= past_lo
        roll_counts = vec(sum(view(gamma_all, past_lo:past_hi, :), dims=1))
        denom = (past_hi - past_lo + 1) + kappa
    else
        roll_counts = zeros(Float64, kmax)
        denom = kappa
    end
    pi_roll = (roll_counts .+ kappa .* gmm.weights) ./ denom
    pi_pred = responsibility(gmm, omega_hat)
    pi = blend_rho .* pi_pred .+ (1.0 - blend_rho) .* pi_roll
    return pi ./ sum(pi)
end

is_optimal_status(status::AbstractString) = status == "OPTIMAL"

function model_size(model::Model)
    constraint_count = 0
    for (func_type, set_type) in list_of_constraint_types(model)
        constraint_count += num_constraints(model, func_type, set_type)
    end
    return (variables=num_variables(model), constraints=constraint_count)
end

function solve_drcc_ols(case::RBTSCase, load_t::Vector{Float64}, wind_t::Vector{Float64},
        pi_t::Vector{Float64}, reps::Vector{Matrix{Float64}}, rho_vec::Vector{Float64};
        epsilon::Real=0.05, delta_w::Real=0.05, divergence::AbstractString="tv",
        time_limit::Real=120.0, tie_breaker::Real=1.0e-6,
        wind_spill_penalty::Real=1.0e-3, risk_slack_penalty::Real=0.0)
    nb = size(case.bus, 1)
    ng = size(case.gen, 1)
    nl = size(case.branch, 1)
    nw = length(wind_t)
    kmax = length(reps)
    h = case.ptdf
    rates = case.line_rates
    gen_bus = case.gen_bus_idx
    wind_bus = case.wind_bus_idx
    gmax = case.gen[:, 9]
    gmin = case.gen[:, 10]
    is_conic = lowercase(divergence) in ("chi2", "chisq", "modified_chi2")
    model = is_conic ? Model(Clarabel.Optimizer) : Model(HiGHS.Optimizer)
    set_silent(model)
    # HiGHS accepts a wall-clock time_limit; the conic path keeps solver defaults.
    !is_conic && time_limit > 0 && set_optimizer_attribute(model, "time_limit", Float64(time_limit))

    @variable(model, g[1:ng])
    @variable(model, beta[1:ng] >= 0.0)
    @variable(model, rD[1:ng] >= 0.0)
    @variable(model, rU[1:ng] >= 0.0)
    @variable(model, 0.0 <= dL[b=1:nb] <= load_t[b])
    @variable(model, 0.0 <= wspill[w=1:nw] <= wind_t[w])
    @variable(model, tau)
    @variable(model, eta)
    @variable(model, nu >= 0.0)
    @variable(model, tvar[1:kmax] >= 0.0)
    @variable(model, alpha[1:kmax])
    @variable(model, lambda_var[1:kmax] >= 0.0)
    @variable(model, zeta[1:kmax])

    @constraint(model, [j in 1:ng], g[j] - rD[j] >= gmin[j])
    @constraint(model, [j in 1:ng], g[j] + rU[j] <= gmax[j])
    @constraint(model, sum(g) + sum(wind_t[w] - wspill[w] for w in 1:nw) == sum(load_t[b] - dL[b] for b in 1:nb))
    @constraint(model, sum(beta) == 1.0)
    @constraint(model, [k in 1:kmax], tvar[k] + eta - nu >= alpha[k])
    @constraint(model, [k in 1:kmax], tvar[k] <= 2.0 * nu)
    soft_risk = Float64(risk_slack_penalty) > 0.0
    risk_slack = nothing
    if soft_risk
        @variable(model, risk_slack_var >= 0.0)
        risk_slack = risk_slack_var
    end

    @expression(model, baseflow[e=1:nl],
        sum(h[e, gen_bus[j]] * g[j] for j in 1:ng) +
        sum(h[e, wind_bus[w]] * (wind_t[w] - wspill[w]) for w in 1:nw) -
        sum(h[e, b] * (load_t[b] - dL[b]) for b in 1:nb)
    )
    @expression(model, agcflow[e=1:nl], sum(h[e, gen_bus[j]] * beta[j] for j in 1:ng))
    @expression(model, risk_lhs, tau + (eta + nu * (delta_w - 1.0) + sum(pi_t[k] * tvar[k] for k in 1:kmax)) / epsilon)
    if soft_risk
        @constraint(model, risk_lhs <= risk_slack)
    else
        @constraint(model, risk_lhs <= 0.0)
    end

    svars = Vector{Vector{VariableRef}}(undef, kmax)
    uvars = Vector{Union{Nothing, Vector{VariableRef}}}(undef, kmax)
    for k in 1:kmax
        qk = size(reps[k], 1)
        svars[k] = @variable(model, [1:qk], base_name="s_$k")
        uvars[k] = nothing
        for i in 1:qk
            omega = vec(reps[k][i, :])
            omega_sum = sum(omega)
            @constraint(model, svars[k][i] >= -zeta[k])
            for j in 1:ng
                @constraint(model, svars[k][i] >= beta[j] * omega_sum - rD[j] - tau - zeta[k])
                @constraint(model, svars[k][i] >= -beta[j] * omega_sum - rU[j] - tau - zeta[k])
            end
            omega_flow = [dot(@view(h[e, :]), omega) for e in 1:nl]
            for e in 1:nl
                flow = baseflow[e] + omega_flow[e] - agcflow[e] * omega_sum
                @constraint(model, svars[k][i] >= flow - rates[e] - tau - zeta[k])
                @constraint(model, svars[k][i] >= -flow - rates[e] - tau - zeta[k])
            end
        end
        if lowercase(divergence) == "tv"
            @constraint(model, alpha[k] >= lambda_var[k] * rho_vec[k] + zeta[k] + sum(svars[k]) / qk)
            @constraint(model, [i in 1:qk], svars[k][i] <= lambda_var[k])
            @constraint(model, [i in 1:qk], svars[k][i] >= -lambda_var[k])
        elseif lowercase(divergence) in ("chi2", "chisq", "modified_chi2")
            # Modified chi-square: lambda*phi^*(s/lambda) = s + s^2/(2 lambda) on
            # s >= -lambda, represented by u_ik >= s_ik^2/lambda_k via the SOC
            # || [2 s_ik ; u_ik - lambda_k] ||_2 <= u_ik + lambda_k.
            u = @variable(model, [1:qk], lower_bound = 0.0, base_name = "u_$k")
            uvars[k] = u
            @constraint(model, alpha[k] >= lambda_var[k] * rho_vec[k] + zeta[k] +
                sum(svars[k][i] + 0.5 * u[i] for i in 1:qk) / qk)
            for i in 1:qk
                @constraint(model, svars[k][i] >= -lambda_var[k])
                @constraint(model, [u[i] + lambda_var[k], 2.0 * svars[k][i], u[i] - lambda_var[k]] in SecondOrderCone())
            end
        else
            error("Unknown divergence '$divergence'")
        end
    end

    @objective(model, Min, sum(dL) + wind_spill_penalty * sum(wspill) +
        (soft_risk ? Float64(risk_slack_penalty) * risk_slack : 0.0) +
        tie_breaker * (sum(rD) + sum(rU) + sum(g)))
    msize = model_size(model)
    optimize!(model)
    status = string(termination_status(model))
    has_vals = has_values(model) && is_optimal_status(status)
    if !has_vals
        return (
            status=status, has_values=false, objective=NaN, load_shed=NaN, solve_time=solve_time(model),
            lp_variables=msize.variables, lp_constraints=msize.constraints,
            g=Float64[], beta=Float64[], rD=Float64[], rU=Float64[], dL=Float64[],
            wind_spill=Float64[], wind_curtailment=NaN, tau=NaN, risk_lhs=NaN,
            risk_slack=NaN
        )
    end
    return (
        status=status, has_values=true, objective=objective_value(model),
        load_shed=sum(value.(dL)), solve_time=solve_time(model),
        lp_variables=msize.variables, lp_constraints=msize.constraints,
        g=value.(g), beta=value.(beta), rD=value.(rD), rU=value.(rU), dL=value.(dL),
        wind_spill=value.(wspill), wind_curtailment=sum(value.(wspill)),
        tau=value(tau), risk_lhs=value(risk_lhs),
        risk_slack=soft_risk ? value(risk_slack) : 0.0
    )
end

function solve_deterministic_ols(case::RBTSCase, load_t::Vector{Float64}, wind_t::Vector{Float64};
        time_limit::Real=120.0, tie_breaker::Real=1.0e-6,
        wind_spill_penalty::Real=1.0e-3)
    nb = size(case.bus, 1)
    ng = size(case.gen, 1)
    nl = size(case.branch, 1)
    nw = length(wind_t)
    h = case.ptdf
    rates = case.line_rates
    gen_bus = case.gen_bus_idx
    wind_bus = case.wind_bus_idx
    gmax = case.gen[:, 9]
    gmin = case.gen[:, 10]
    beta_ref_raw = max.(gmax .- gmin, 0.0)
    beta_ref = sum(beta_ref_raw) > SMALL ? beta_ref_raw ./ sum(beta_ref_raw) : fill(1.0 / ng, ng)
    model = Model(HiGHS.Optimizer)
    set_silent(model)
    time_limit > 0 && set_optimizer_attribute(model, "time_limit", Float64(time_limit))
    @variable(model, g[1:ng])
    @variable(model, beta[1:ng] >= 0.0)
    @variable(model, rD[1:ng] >= 0.0)
    @variable(model, rU[1:ng] >= 0.0)
    @variable(model, 0.0 <= dL[b=1:nb] <= load_t[b])
    @variable(model, 0.0 <= wspill[w=1:nw] <= wind_t[w])
    @variable(model, beta_dev_pos[1:ng] >= 0.0)
    @variable(model, beta_dev_neg[1:ng] >= 0.0)
    @constraint(model, [j in 1:ng], g[j] - rD[j] >= gmin[j])
    @constraint(model, [j in 1:ng], g[j] + rU[j] <= gmax[j])
    @constraint(model, sum(g) + sum(wind_t[w] - wspill[w] for w in 1:nw) == sum(load_t[b] - dL[b] for b in 1:nb))
    @constraint(model, sum(beta) == 1.0)
    @constraint(model, [j in 1:ng], beta[j] - beta_ref[j] == beta_dev_pos[j] - beta_dev_neg[j])
    @expression(model, baseflow[e=1:nl],
        sum(h[e, gen_bus[j]] * g[j] for j in 1:ng) +
        sum(h[e, wind_bus[w]] * (wind_t[w] - wspill[w]) for w in 1:nw) -
        sum(h[e, b] * (load_t[b] - dL[b]) for b in 1:nb)
    )
    @constraint(model, [e in 1:nl], baseflow[e] <= rates[e])
    @constraint(model, [e in 1:nl], -baseflow[e] <= rates[e])
    @objective(model, Min, sum(dL) + wind_spill_penalty * sum(wspill) +
        tie_breaker * (sum(rD) + sum(rU) + sum(g) + sum(beta_dev_pos) + sum(beta_dev_neg)))
    msize = model_size(model)
    optimize!(model)
    status = string(termination_status(model))
    has_vals = has_values(model) && is_optimal_status(status)
    if !has_vals
        return (
            status=status, has_values=false, objective=NaN, load_shed=NaN, solve_time=solve_time(model),
            lp_variables=msize.variables, lp_constraints=msize.constraints,
            g=Float64[], beta=Float64[], rD=Float64[], rU=Float64[], dL=Float64[],
            wind_spill=Float64[], wind_curtailment=NaN, tau=NaN, risk_lhs=NaN,
            risk_slack=NaN
        )
    end
    return (
        status=status, has_values=true, objective=objective_value(model),
        load_shed=sum(value.(dL)), solve_time=solve_time(model),
        lp_variables=msize.variables, lp_constraints=msize.constraints,
        g=value.(g), beta=value.(beta), rD=value.(rD), rU=value.(rU), dL=value.(dL),
        wind_spill=value.(wspill), wind_curtailment=sum(value.(wspill)),
        tau=NaN, risk_lhs=NaN, risk_slack=NaN
    )
end

function dispatched_wind(sol, wind_t::Vector{Float64})
    if hasproperty(sol, :wind_spill) && length(sol.wind_spill) == length(wind_t)
        return wind_t .- sol.wind_spill
    end
    return wind_t
end

function max_violation(case::RBTSCase, sol, load_t::Vector{Float64}, wind_t::Vector{Float64}, omega::Vector{Float64})
    !sol.has_values && return NaN
    h = case.ptdf
    rates = case.line_rates
    omega_sum = sum(omega)
    wind_dispatch = dispatched_wind(sol, wind_t)
    maxv = -Inf
    for j in eachindex(sol.g)
        maxv = max(maxv, sol.beta[j] * omega_sum - sol.rD[j])
        maxv = max(maxv, -sol.beta[j] * omega_sum - sol.rU[j])
    end
    for e in 1:size(h, 1)
        base = sum(h[e, case.gen_bus_idx[j]] * sol.g[j] for j in eachindex(sol.g)) +
               sum(h[e, case.wind_bus_idx[w]] * wind_dispatch[w] for w in eachindex(wind_dispatch)) -
               sum(h[e, b] * (load_t[b] - sol.dL[b]) for b in eachindex(load_t))
        agc = sum(h[e, case.gen_bus_idx[j]] * sol.beta[j] for j in eachindex(sol.g))
        flow = base + dot(@view(h[e, :]), omega) - agc * omega_sum
        maxv = max(maxv, flow - rates[e])
        maxv = max(maxv, -flow - rates[e])
    end
    return maxv
end

function total_positive_violation(case::RBTSCase, sol, load_t::Vector{Float64}, wind_t::Vector{Float64}, omega::Vector{Float64})
    !sol.has_values && return NaN
    h = case.ptdf
    rates = case.line_rates
    omega_sum = sum(omega)
    wind_dispatch = dispatched_wind(sol, wind_t)
    total = 0.0
    for j in eachindex(sol.g)
        total += max(sol.beta[j] * omega_sum - sol.rD[j], 0.0)
        total += max(-sol.beta[j] * omega_sum - sol.rU[j], 0.0)
    end
    for e in 1:size(h, 1)
        base = sum(h[e, case.gen_bus_idx[j]] * sol.g[j] for j in eachindex(sol.g)) +
               sum(h[e, case.wind_bus_idx[w]] * wind_dispatch[w] for w in eachindex(wind_dispatch)) -
               sum(h[e, b] * (load_t[b] - sol.dL[b]) for b in eachindex(load_t))
        agc = sum(h[e, case.gen_bus_idx[j]] * sol.beta[j] for j in eachindex(sol.g))
        flow = base + dot(@view(h[e, :]), omega) - agc * omega_sum
        total += max(flow - rates[e], 0.0)
        total += max(-flow - rates[e], 0.0)
    end
    return total
end

function emergency_shed(case::RBTSCase, sol, load_t::Vector{Float64}, wind_t::Vector{Float64},
        omega::Vector{Float64}; penalty::Real=1.0e5)
    !sol.has_values && return (shed=NaN, residual_slack=NaN, status="NO_DISPATCH")
    nb = size(case.bus, 1)
    ng = size(case.gen, 1)
    nl = size(case.branch, 1)
    h = case.ptdf
    rates = case.line_rates
    omega_sum = sum(omega)
    wind_dispatch = dispatched_wind(sol, wind_t)
    model = Model(HiGHS.Optimizer)
    set_silent(model)
    @variable(model, 0.0 <= shed[b=1:nb] <= max(load_t[b] - sol.dL[b], 0.0))
    @variable(model, slack[1:(2 * ng + 2 * nl)] >= 0.0)
    total_shed = sum(shed)
    omega_total = omega_sum + total_shed
    c = 0
    for j in 1:ng
        c += 1
        @constraint(model, sol.beta[j] * omega_total - sol.rD[j] <= slack[c])
        c += 1
        @constraint(model, -sol.beta[j] * omega_total - sol.rU[j] <= slack[c])
    end
    for e in 1:nl
        base = sum(h[e, case.gen_bus_idx[j]] * sol.g[j] for j in 1:ng) +
               sum(h[e, case.wind_bus_idx[w]] * wind_dispatch[w] for w in eachindex(wind_dispatch)) -
               sum(h[e, b] * (load_t[b] - sol.dL[b]) for b in 1:nb)
        agc = sum(h[e, case.gen_bus_idx[j]] * sol.beta[j] for j in 1:ng)
        flow = base + dot(@view(h[e, :]), omega) + sum(h[e, b] * shed[b] for b in 1:nb) - agc * omega_total
        c += 1
        @constraint(model, flow - rates[e] <= slack[c])
        c += 1
        @constraint(model, -flow - rates[e] <= slack[c])
    end
    @objective(model, Min, total_shed + penalty * sum(slack))
    optimize!(model)
    status = string(termination_status(model))
    if !has_values(model) || !is_optimal_status(status)
        return (shed=NaN, residual_slack=NaN, status=status)
    end
    return (shed=value(total_shed), residual_slack=sum(value.(slack)), status=status)
end

function emergency_shed_if_needed(case::RBTSCase, sol, load_t::Vector{Float64}, wind_t::Vector{Float64},
        omega::Vector{Float64}; violation::Real=NaN, tol::Real=1.0e-6)
    !sol.has_values && return (shed=NaN, residual_slack=NaN, status="NO_DISPATCH")
    v = isfinite(Float64(violation)) ? Float64(violation) : max_violation(case, sol, load_t, wind_t, omega)
    isfinite(v) || return (shed=NaN, residual_slack=NaN, status="NONFINITE_VIOLATION")
    v <= tol && return (shed=0.0, residual_slack=0.0, status="SKIPPED_NO_VIOLATION")
    return emergency_shed(case, sol, load_t, wind_t, omega)
end

function select_sample_indices(n::Integer, limit::Integer)
    n <= 0 && return Int[]
    limit <= 0 && return Int[]
    q = min(n, limit)
    return unique(round.(Int, range(1, n, length=q)))
end

function oos_stats(case::RBTSCase, sol, load_t::Vector{Float64}, wind_t::Vector{Float64},
        omega_samples::Matrix{Float64}; reliability_sample_limit::Integer=0)
    n = size(omega_samples, 1)
    empty_stats(samples::Integer=0) = (
        violation_rate=NaN, avg_positive_violation=NaN, avg_total_positive_violation=NaN,
        max_positive_violation=NaN, max_violation=NaN,
        eens_mwh=NaN, planned_eens_mwh=NaN, emergency_eens_mwh=NaN,
        lolp=NaN, lole_h=NaN, residual_security_rate=NaN, reliability_samples=samples
    )
    n == 0 && return empty_stats(0)
    sample_ids = select_sample_indices(n, reliability_sample_limit)
    !sol.has_values && return empty_stats(length(sample_ids))
    vals = [max_violation(case, sol, load_t, wind_t, vec(omega_samples[i, :])) for i in 1:n]
    positives = max.(vals, 0.0)
    total_positives = [total_positive_violation(case, sol, load_t, wind_t, vec(omega_samples[i, :])) for i in 1:n]
    emergency = Float64[]
    residuals = Float64[]
    for i in sample_ids
        em = emergency_shed_if_needed(case, sol, load_t, wind_t, vec(omega_samples[i, :]);
            violation=vals[i])
        push!(emergency, em.shed)
        push!(residuals, em.residual_slack)
    end
    planned = sol.has_values ? sol.load_shed : NaN
    total_unserved = [planned + e for e in emergency if isfinite(e) && isfinite(planned)]
    return (
        violation_rate=mean(vals .> 1.0e-6),
        avg_positive_violation=mean(positives),
        avg_total_positive_violation=finite_mean(total_positives),
        max_positive_violation=maximum(positives),
        max_violation=maximum(vals),
        eens_mwh=isempty(total_unserved) ? NaN : mean(total_unserved),
        planned_eens_mwh=planned,
        emergency_eens_mwh=isempty(emergency) ? NaN : finite_mean(emergency),
        lolp=isempty(total_unserved) ? NaN : mean(total_unserved .> 1.0e-6),
        lole_h=isempty(total_unserved) ? NaN : mean(total_unserved .> 1.0e-6),
        residual_security_rate=isempty(residuals) ? NaN : mean(residuals .> 1.0e-6),
        reliability_samples=length(sample_ids)
    )
end

finite_mean(v) = begin
    vals = [Float64(x) for x in v if x isa Real && isfinite(Float64(x))]
    isempty(vals) ? NaN : mean(vals)
end

finite_max(v) = begin
    vals = [Float64(x) for x in v if x isa Real && isfinite(Float64(x))]
    isempty(vals) ? NaN : maximum(vals)
end

finite_sum(v) = begin
    vals = [Float64(x) for x in v if x isa Real && isfinite(Float64(x))]
    isempty(vals) ? NaN : sum(vals)
end

finite_number(x) = x isa Real && isfinite(Float64(x))
safe_num(x; bad=Inf) = finite_number(x) ? Float64(x) : bad
metric_fmt(x; digits=4) = finite_number(x) ? @sprintf("%.*f", digits, Float64(x)) : "NaN"
function summary_edns_mw(row)
    eens = safe_num(row.total_oos_eens_mwh; bad=NaN)
    hours = safe_num(row.runs; bad=NaN)
    (!isfinite(eens) || !isfinite(hours) || hours <= 0.0) && return NaN
    return eens / hours
end

function summary_has_scheduled_shed(summary::DataFrame; tol::Real=1.0e-6)
    vals = Float64[]
    "avg_load_shed" in names(summary) && append!(vals, [safe_num(x; bad=0.0) for x in summary.avg_load_shed])
    "max_load_shed" in names(summary) && append!(vals, [safe_num(x; bad=0.0) for x in summary.max_load_shed])
    return any(x -> isfinite(x) && abs(x) > tol, vals)
end

function summarize_results(results::DataFrame)
    gd = groupby(results, :scenario_id)
    return combine(gd,
        :method => first => :method,
        :global_rep_mode => first => :global_rep_mode,
        :load_shed => finite_mean => :avg_load_shed,
        :load_shed => finite_max => :max_load_shed,
        :solve_time_sec => finite_mean => :avg_solve_time_sec,
        :lp_variables => finite_mean => :avg_lp_variables,
        :lp_constraints => finite_mean => :avg_lp_constraints,
        :risk_slack => finite_mean => :avg_risk_slack,
        :risk_slack => finite_max => :max_risk_slack,
        :realized_violated => finite_mean => :realized_violation_rate,
        :realized_eens_mwh => finite_sum => :total_realized_eens_mwh,
        :realized_lolp => finite_mean => :realized_lolp,
        :oos_violation_rate => finite_mean => :avg_oos_violation_rate,
        :oos_avg_positive_violation => finite_mean => :avg_oos_positive_violation,
        :oos_avg_total_positive_violation => finite_mean => :avg_oos_total_positive_violation,
        :oos_max_positive_violation => finite_max => :max_oos_positive_violation,
        :oos_eens_mwh => finite_sum => :total_oos_eens_mwh,
        :oos_lolp => finite_mean => :avg_oos_lolp,
        :oos_lole_h => finite_sum => :oos_lole_h,
        :oos_emergency_eens_mwh => finite_sum => :total_oos_emergency_eens_mwh,
        :oos_residual_security_rate => finite_mean => :avg_residual_security_rate,
        :status => (x -> count(==("OPTIMAL"), string.(x))) => :optimal_count,
        nrow => :runs)
end

function summary_row_complete(row)
    return row.optimal_count == row.runs &&
           finite_number(row.total_oos_eens_mwh) &&
           finite_number(row.avg_oos_lolp) &&
           finite_number(row.avg_oos_violation_rate)
end

function summary_row_has_metrics(row)
    return finite_number(row.total_oos_eens_mwh) &&
           finite_number(row.avg_oos_lolp) &&
           finite_number(row.avg_oos_violation_rate)
end

function summary_score(row)
    return safe_num(row.total_oos_eens_mwh) +
           100.0 * safe_num(row.avg_oos_lolp) +
           0.25 * safe_num(row.avg_oos_violation_rate) +
           1.0e-6 * safe_num(row.avg_load_shed; bad=0.0)
end

function select_best(summary::DataFrame, epsilon::Real)
    complete_for_comparison = findall(i -> summary_row_complete(summary[i, :]), 1:nrow(summary))
    ok = [i for i in complete_for_comparison if summary.avg_oos_lolp[i] <= epsilon]
    if !isempty(ok)
        local_idx = argmin([summary.total_oos_eens_mwh[i] + 1.0e-4 * summary.avg_load_shed[i] for i in ok])
        return summary[ok[local_idx], :]
    end
    candidates = !isempty(complete_for_comparison) ? complete_for_comparison : findall(i -> summary_row_has_metrics(summary[i, :]), 1:nrow(summary))
    isempty(candidates) && (candidates = collect(1:nrow(summary)))
    return summary[candidates[argmin([summary_score(summary[i, :]) for i in candidates])], :]
end

function method_best_summary(summary::DataFrame)
    rows = DataFrame()
    for sub in groupby(summary, :method)
        candidates = findall(i -> summary_row_complete(sub[i, :]), 1:nrow(sub))
        isempty(candidates) && (candidates = findall(i -> summary_row_has_metrics(sub[i, :]), 1:nrow(sub)))
        isempty(candidates) && (candidates = collect(1:nrow(sub)))
        push!(rows, sub[candidates[argmin([summary_score(sub[i, :]) for i in candidates])], :])
    end
    return rows
end

function improvement_text(base::Real, candidate::Real)
    if !isfinite(base) || !isfinite(candidate)
        return "n/a"
    elseif abs(base) <= 1.0e-9
        return abs(candidate) <= 1.0e-9 ? "tie" : "worse"
    else
        return @sprintf("%.1f%%", 100.0 * (base - candidate) / abs(base))
    end
end

function write_report(path::AbstractString, cfg, case::RBTSCase, data::ExperimentData,
        gmm::DiagGMM, results::DataFrame, summary::DataFrame, best)
    timestamp = Dates.format(now(), dateformat"yyyy-mm-dd HH:MM:SS")
    gmm_weights = join(round.(gmm.weights, digits=4), ", ")
    best_shed = metric_fmt(best.avg_load_shed)
    best_lolp = metric_fmt(best.avg_oos_lolp)
    best_eens = metric_fmt(best.total_oos_eens_mwh)
    best_status = summary_row_complete(best) ? "complete comparison row" : "diagnostic row"
    best_methods = method_best_summary(summary)
    include_scheduled_shed = summary_has_scheduled_shed(summary)
    open(path, "w") do io
        println(io, "# MA-DRCC-OLS Experiment Report")
        println(io)
        println(io, "- Generated at: $timestamp")
        println(io, "- Model: mixture phi-divergence DRCC-OLS with predictive-rolling weights and outer L1 weight ambiguity")
        println(io, "- Divergence: $(cfg["experiment"]["divergence"])")
        println(io, "- Buses/generators/lines: $(size(case.bus, 1))/$(size(case.gen, 1))/$(size(case.branch, 1))")
        println(io, "- Data rows used by loader: $(size(data.omega, 1))")
        println(io, "- GMM implementation: diagonal-covariance Gaussian mixture fitted on historical nodal net-injection errors.")
        println(io, "- Predictive error proxy: $(get(cfg["experiment"], "predictive_error", "previous_error")).")
        println(io, "- Global empirical/single-TV support mode: $(get(cfg["experiment"], "global_rep_mode", "all")).")
        if nrow(data.wind_quality) > 0
            cleaned_events = sum(data.wind_quality.missing_or_nonfinite) +
                sum(data.wind_quality.negative) +
                sum(data.wind_quality.above_capacity) +
                sum(data.wind_quality.isolated_spikes_repaired)
            total_obs = sum(data.wind_quality.observations)
            cleaned_share = total_obs == 0 ? 0.0 : cleaned_events / total_obs
            println(io, "- Wind data screening: $cleaned_events corrected events across $total_obs observations ($(round(100 * cleaned_share, digits=3))%).")
        end
        if nrow(data.load_quality) > 0
            cleaned_events = sum(data.load_quality.missing_or_nonfinite) +
                sum(data.load_quality.negative) +
                sum(data.load_quality.isolated_spikes_repaired)
            total_obs = sum(data.load_quality.observations)
            cleaned_share = total_obs == 0 ? 0.0 : cleaned_events / total_obs
            println(io, "- Load data screening: $cleaned_events corrected events across $total_obs observations ($(round(100 * cleaned_share, digits=3))%).")
        end
        println(io, "- GMM weights: $gmm_weights")
        println(io, "- Best scenario id: $(best.scenario_id) ($(best.method), $best_status)")
        println(io, "- Best scheduled pre-contingency load shedding: $best_shed MW")
        println(io, "- Best OOS EENS over evaluated hours: $best_eens MWh")
        println(io, "- Best average OOS LOLP: $best_lolp")
        println(io)
        if nrow(data.wind_quality) > 0
            println(io, "## Wind Data Quality")
            println(io)
            println(io, "|source|capacity MW|obs.|missing/nonfinite|negative|above cap.|isolated spikes|large jumps flagged|cleaned share|")
            println(io, "|---|---:|---:|---:|---:|---:|---:|---:|---:|")
            for row in eachrow(data.wind_quality)
                cap = isfinite(row.capacity_mw) ? @sprintf("%.2f", row.capacity_mw) : "NA"
                share = @sprintf("%.4f", row.cleaned_share)
                println(io, "|$(row.source)|$cap|$(row.observations)|$(row.missing_or_nonfinite)|$(row.negative)|$(row.above_capacity)|$(row.isolated_spikes_repaired)|$(row.suspicious_large_jumps)|$share|")
            end
            println(io)
        end
        if nrow(data.load_quality) > 0
            println(io, "## Load Data Quality")
            println(io)
            println(io, "|source|bus|obs.|missing/nonfinite|negative|isolated spikes|large jumps flagged|cleaned share|")
            println(io, "|---|---:|---:|---:|---:|---:|---:|---:|")
            for row in eachrow(data.load_quality)
                if row.missing_or_nonfinite == 0 && row.negative == 0 &&
                        row.isolated_spikes_repaired == 0 && row.suspicious_large_jumps == 0
                    continue
                end
                share = @sprintf("%.4f", row.cleaned_share)
                println(io, "|$(row.source)|$(row.bus)|$(row.observations)|$(row.missing_or_nonfinite)|$(row.negative)|$(row.isolated_spikes_repaired)|$(row.suspicious_large_jumps)|$share|")
            end
            println(io)
        end
        println(io, "## Scenario Summary")
        println(io)
        if include_scheduled_shed
            println(io, "|scenario|method|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|")
            println(io, "|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")
        else
            println(io, "|scenario|method|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|")
            println(io, "|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")
        end
        for row in eachrow(summary)
            shed = metric_fmt(row.avg_load_shed)
            edns = metric_fmt(summary_edns_mw(row))
            eens = metric_fmt(row.total_oos_eens_mwh)
            lolp = metric_fmt(row.avg_oos_lolp)
            lole = metric_fmt(row.oos_lole_h)
            sec_viol = metric_fmt(row.avg_oos_violation_rate)
            max_viol = metric_fmt(row.max_oos_positive_violation)
            mean_total_viol = metric_fmt(row.avg_oos_total_positive_violation)
            avg_solve = metric_fmt(row.avg_solve_time_sec; digits=3)
            lp_vars = metric_fmt(row.avg_lp_variables; digits=0)
            lp_cons = metric_fmt(row.avg_lp_constraints; digits=0)
            complete = summary_row_complete(row) ? "yes" : "no"
            if include_scheduled_shed
                println(io, "|$(row.scenario_id)|$(row.method)|$shed|$edns|$eens|$lolp|$lole|$sec_viol|$max_viol|$mean_total_viol|$avg_solve|$lp_vars|$lp_cons|$(row.optimal_count)/$(row.runs)|$complete|")
            else
                println(io, "|$(row.scenario_id)|$(row.method)|$edns|$eens|$lolp|$lole|$sec_viol|$max_viol|$mean_total_viol|$avg_solve|$lp_vars|$lp_cons|$(row.optimal_count)/$(row.runs)|$complete|")
            end
        end
        println(io)
        println(io, "## Best By Method")
        println(io)
        if include_scheduled_shed
            println(io, "|method|scenario|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|")
            println(io, "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")
        else
            println(io, "|method|scenario|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|")
            println(io, "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")
        end
        for row in eachrow(best_methods)
            shed = metric_fmt(row.avg_load_shed)
            edns = metric_fmt(summary_edns_mw(row))
            eens = metric_fmt(row.total_oos_eens_mwh)
            lolp = metric_fmt(row.avg_oos_lolp)
            lole = metric_fmt(row.oos_lole_h)
            sec_viol = metric_fmt(row.avg_oos_violation_rate)
            max_viol = metric_fmt(row.max_oos_positive_violation)
            mean_total_viol = metric_fmt(row.avg_oos_total_positive_violation)
            avg_solve = metric_fmt(row.avg_solve_time_sec; digits=3)
            lp_vars = metric_fmt(row.avg_lp_variables; digits=0)
            lp_cons = metric_fmt(row.avg_lp_constraints; digits=0)
            complete = summary_row_complete(row) ? "yes" : "no"
            if include_scheduled_shed
                println(io, "|$(row.method)|$(row.scenario_id)|$shed|$edns|$eens|$lolp|$lole|$sec_viol|$max_viol|$mean_total_viol|$avg_solve|$lp_vars|$lp_cons|$(row.optimal_count)/$(row.runs)|$complete|")
            else
                println(io, "|$(row.method)|$(row.scenario_id)|$edns|$eens|$lolp|$lole|$sec_viol|$max_viol|$mean_total_viol|$avg_solve|$lp_vars|$lp_cons|$(row.optimal_count)/$(row.runs)|$complete|")
            end
        end
        proposed_rows = best_methods[best_methods.method .== "proposed", :]
        if nrow(proposed_rows) > 0
            prop = proposed_rows[1, :]
            println(io)
            println(io, "## Proposed Advantage")
            println(io)
            println(io, "|baseline|EENS reduction|LOLP reduction|security-violation reduction|")
            println(io, "|---|---:|---:|---:|")
            for row in eachrow(best_methods)
                row.method == "proposed" && continue
                eens_gain = improvement_text(row.total_oos_eens_mwh, prop.total_oos_eens_mwh)
                lolp_gain = improvement_text(row.avg_oos_lolp, prop.avg_oos_lolp)
                sec_gain = improvement_text(row.avg_oos_violation_rate, prop.avg_oos_violation_rate)
                println(io, "|$(row.method)|$eens_gain|$lolp_gain|$sec_gain|")
            end
        end
        println(io)
        println(io, "## Notes")
        println(io)
        println(io, "- EDNS is computed as EENS divided by the evaluated rolling hours, so it reports the average unserved power in the out-of-sample reliability audit.")
        if include_scheduled_shed
            println(io, "- Scheduled shedding is the preventive load-shedding decision returned by the optimization model before out-of-sample forecast-error realizations are audited.")
        else
            println(io, "- Scheduled pre-contingency load shedding is omitted from the tables because it is zero for all retained rows in this run.")
        end
        println(io, "- EENS is computed as planned load shedding plus the minimum emergency load shedding needed to restore generator reserve and line constraints under sampled forecast errors.")
        println(io, "- LOLP is the sample probability that planned or emergency load shedding is positive; LOLE is the sum of hourly LOLP values over the evaluated rolling horizon.")
        println(io, "- `security viol.` is the probability of any raw operating-limit violation before emergency corrective shedding.")
        println(io, "- `max viol.` is the largest positive post-event physical-constraint exceedance over the sampled audit errors; `mean total viol.` averages the sum of positive generator and line exceedances per test case.")
        println(io, "- LP variables and constraints count the optimization model sent to the LP solver before presolve.")
        println(io, "- The tiny tie-breaker only stabilizes reserve/generation choices; the reported shedding remains the primary metric.")
    end
end

function global_representative_indices(gamma::Matrix{Float64}, budget::Integer; mode::AbstractString="all")
    n = size(gamma, 1)
    mode_l = lowercase(mode)
    if mode_l in ("all", "full", "training")
        return collect(1:n)
    elseif !(mode_l in ("budget_confidence", "confidence", "budgeted"))
        error("Unknown global representative mode '$mode'. Use 'all' or 'budget_confidence'.")
    end
    q = clamp(budget, 1, n)
    confidence = vec(maximum(gamma, dims=2))
    return sortperm(confidence, rev=true)[1:q]
end

# Regime-wise divergence radii.  Under a fixed total representative-support
# budget, regimes with fewer retained samples carry larger statistical
# uncertainty in their empirical reference law, so they are assigned a larger
# divergence radius.  This follows the data-driven phi-divergence radius scale
# rho_n ~ 1/n (Ben-Tal et al. 2013; Bayraksan & Love 2015): the count-weighted
# average radius is kept close to `rho_base` so the enhanced construction is
# directly comparable to the uniform-radius setting at the same budget.
# `mode = "uniform"` reproduces the original fill(rho_base, K) behaviour, and a
# single-support set (global empirical / single-TV) is invariant to the mode.
function regime_radii(rho_base::Real, reps::Vector{<:AbstractMatrix}, mode::AbstractString)
    k = length(reps)
    k == 0 && return Float64[]
    counts = Float64[max(size(r, 1), 1.0) for r in reps]
    m = lowercase(mode)
    if m in ("uniform", "", "none", "fixed")
        return fill(Float64(rho_base), k)
    end
    qbar = mean(counts)
    if m in ("inverse_count", "inv_count", "inverse")
        return [Float64(rho_base) * qbar / c for c in counts]
    elseif m in ("sqrt_inverse_count", "sqrt_inv_count", "sqrt")
        return [Float64(rho_base) * sqrt(qbar / c) for c in counts]
    else
        error("Unknown rho_regime_mode '$mode'. Use 'uniform', 'inverse_count', or 'sqrt_inverse_count'.")
    end
end

function method_cases(method::AbstractString, rho_grid::Vector{Float64}, delta_grid::Vector{Float64})
    m = lowercase(method)
    if m in ("deterministic", "deterministic_headroom")
        return [(rho=0.0, delta_w=0.0)]
    elseif m in ("empirical", "empirical_cvar")
        return [(rho=0.0, delta_w=0.0)]
    elseif m in ("single_tv", "single")
        return [(rho=rho, delta_w=0.0) for rho in rho_grid]
    elseif m in ("mixture_static", "static")
        return [(rho=rho, delta_w=0.0) for rho in rho_grid]
    elseif m in ("mixture_rolling", "rolling")
        return [(rho=rho, delta_w=0.0) for rho in rho_grid]
    elseif m in ("predictive_only", "predictive")
        return [(rho=rho, delta_w=0.0) for rho in rho_grid]
    elseif m == "proposed"
        return [(rho=rho, delta_w=delta_w) for rho in rho_grid for delta_w in delta_grid]
    else
        error("Unknown comparison method '$method'")
    end
end

"""Apply a reproducible, bounded wind-residual stress and conventional derating.

Raw observations and forecasts are retained in the caller's ExperimentData.
The new nodal errors are rebuilt from wind and load separately; a legacy global
error_scale is forbidden when wind-residual stress is active.
"""
function apply_physical_stress(case::RBTSCase, data::ExperimentData,
        capacities::Vector{Float64}; conventional_capacity_scale::Real=1.0,
        wind_error_multiplier::Real=1.0, error_scale::Real=1.0,
        load_error_mode::AbstractString="source_pair")
    c = Float64(conventional_capacity_scale)
    s = Float64(wind_error_multiplier)
    0.0 < c <= 1.0 || error("conventional_capacity_scale must be in (0,1]")
    s >= 1.0 || error("wind_error_multiplier must be at least one")
    load_error_mode in ("source_pair", "known_forecast") || error("Unknown load_error_mode")
    s != 1.0 && error_scale != 1.0 &&
        error("wind residual stress requires error_scale=1 to preserve the load error")
    length(capacities) == size(data.wind_actual, 2) || error("Wind capacities do not match farms")
    all(isfinite.(capacities) .& (capacities .> 0.0)) || error("Wind capacities must be positive and finite")
    gen = copy(case.gen)
    gen[:, 9] .*= c
    gen[:, 10] .*= c
    gen[:, 2] .= clamp.(gen[:, 2], gen[:, 10], gen[:, 9])
    stressed_case = RBTSCase(case.base_mva, case.bus, gen, case.branch,
        case.bus_ids, case.gen_bus_idx, case.wind_bus_idx, case.line_rates, case.ptdf)
    actual = copy(data.wind_actual)
    diagnostics = DataFrame()
    for w in eachindex(capacities)
        forecast = data.wind_forecast[:, w]
        old_error = data.wind_actual[:, w] .- forecast
        unbounded = forecast .+ s .* old_error
        actual[:, w] .= clamp.(unbounded, 0.0, capacities[w])
        new_error = actual[:, w] .- forecast
        push!(diagnostics, (farm=w, capacity_mw=capacities[w],
            conventional_capacity_scale=c, wind_error_multiplier=s,
            original_mean_actual_mw=mean(data.wind_actual[:, w]),
            stressed_mean_actual_mw=mean(actual[:, w]),
            original_error_std_mw=std(old_error), stressed_error_std_mw=std(new_error),
            original_error_q05_mw=quantile(old_error, 0.05),
            stressed_error_q05_mw=quantile(new_error, 0.05),
            lower_clip_share=mean(unbounded .< 0.0),
            upper_clip_share=mean(unbounded .> capacities[w]),
            min_actual_mw=minimum(actual[:, w]), max_actual_mw=maximum(actual[:, w])))
    end
    # Controlled wind-only experiment: the same prescribed demand is used in
    # dispatch and replay; no prediction/measurement semantics are inferred
    # from the two alternative source load files.
    load_actual = load_error_mode == "known_forecast" ? copy(data.load_forecast) : data.load_actual
    omega = .-(load_actual .- data.load_forecast)
    for (w, wb) in enumerate(case.wind_bus_idx)
        omega[:, wb] .+= actual[:, w] .- data.wind_forecast[:, w]
    end
    omega .*= Float64(error_scale)
    stressed_data = ExperimentData(data.times, data.load_forecast, load_actual,
        actual, data.wind_forecast, omega, data.wind_quality, data.load_quality)
    return stressed_case, stressed_data, diagnostics
end

function active_power_case(case::RBTSCase)
    keep = findall((abs.(case.gen[:, 9]) .> SMALL) .| (abs.(case.gen[:, 10]) .> SMALL))
    isempty(keep) && error("No active-power generating units remain")
    # A reactive-only device has no role in DC active-power balancing. Keeping
    # its two reserve inequalities inserts a nonnegative/identically-zero term
    # into max(G), inadvertently turning CVaR<=0 into pointwise robust security.
    return RBTSCase(case.base_mva, case.bus, case.gen[keep, :], case.branch,
        case.bus_ids, case.gen_bus_idx[keep], case.wind_bus_idx, case.line_rates, case.ptdf)
end

function run_experiment(config_path::AbstractString)
    cfg = TOML.parsefile(config_path)
    project_dir = normpath(joinpath(@__DIR__, ".."))
    resolve_path(rel::AbstractString) = abspath(joinpath(project_dir, rel))
    resolve_path(rels::AbstractVector) = [resolve_path(String(rel)) for rel in rels]
    p = key -> resolve_path(cfg["paths"][key])
    exp = cfg["experiment"]
    data_cfg = cfg["data"]
    data_format = lowercase(String(get(data_cfg, "format", "matpower")))
    case, data = if data_format in ("rts_gmlc", "gmlc")
        wind_columns = get(data_cfg, "wind_columns", String[])
        gmlc_root = p("gmlc_root")
        local_case = load_gmlc_case(gmlc_root;
            wind_columns=wind_columns,
            aggregate_generators=as_bool(get(data_cfg, "aggregate_generators", true)),
            pmin_scale=Float64(get(data_cfg, "pmin_scale", 0.0)))
        local_data = load_gmlc_experiment_data(local_case, gmlc_root;
            wind_columns=wind_columns,
            wind_scale=data_cfg["wind_scale"],
            load_scale=Float64(get(data_cfg, "load_scale", 1.0)),
            error_scale=Float64(get(data_cfg, "error_scale", 1.0)),
            wind_capacity_tolerance=Float64(get(data_cfg, "wind_capacity_tolerance", 0.02)),
            wind_jump_fraction=Float64(get(data_cfg, "wind_jump_fraction", 0.75)),
            wind_repair_isolated_spikes=as_bool(get(data_cfg, "wind_repair_isolated_spikes", true)),
            load_jump_fraction=Float64(get(data_cfg, "load_jump_fraction", 0.75)),
            load_repair_isolated_spikes=as_bool(get(data_cfg, "load_repair_isolated_spikes", true)))
        local_case, local_data
    else
        local_case = load_rbts(p("rbts");
            wind_bus=get(data_cfg, "wind_bus", Int[]),
            replace_gen_indices=get(data_cfg, "replace_gen_indices", Int[]),
            pmin_scale=Float64(get(data_cfg, "pmin_scale", 1.0)))
        local_data = load_experiment_data(local_case, p("system_loads"), p("bus_loads"), p("wind_xlsx");
            wind_scale=data_cfg["wind_scale"],
            wind_lag=Int(data_cfg["wind_forecast_lag_hours"]),
            error_scale=Float64(get(data_cfg, "error_scale", 1.0)),
            wind_capacity_tolerance=Float64(get(data_cfg, "wind_capacity_tolerance", 0.02)),
            wind_jump_fraction=Float64(get(data_cfg, "wind_jump_fraction", 0.75)),
            wind_repair_isolated_spikes=as_bool(get(data_cfg, "wind_repair_isolated_spikes", true)),
            load_jump_fraction=Float64(get(data_cfg, "load_jump_fraction", 0.75)),
            load_repair_isolated_spikes=as_bool(get(data_cfg, "load_repair_isolated_spikes", true)))
        local_case, local_data
    end

    stress_diagnostics = DataFrame()
    if haskey(data_cfg, "conventional_capacity_scale") || haskey(data_cfg, "wind_error_multiplier")
        nw = size(data.wind_actual, 2)
        scales = expand_to_length(as_float_vector(data_cfg["wind_scale"]), nw)
        capacities = if data_format in ("rts_gmlc", "gmlc")
            gmlc_wind_capacities(p("gmlc_root"), gmlc_wind_columns(p("gmlc_root"), get(data_cfg, "wind_columns", String[]))) .* scales
        else
            wind_capacity_from_filename.(as_string_vector(p("wind_xlsx"))) .* scales
        end
        case, data, stress_diagnostics = apply_physical_stress(case, data, capacities;
            conventional_capacity_scale=Float64(get(data_cfg, "conventional_capacity_scale", 1.0)),
            wind_error_multiplier=Float64(get(data_cfg, "wind_error_multiplier", 1.0)),
            error_scale=Float64(get(data_cfg, "error_scale", 1.0)),
            load_error_mode=String(get(data_cfg, "load_error_mode", "source_pair")))
    end

    if as_bool(get(data_cfg, "exclude_zero_active_power_units", false))
        case = active_power_case(case)
    end

    train_hours = Int(exp["train_hours"])
    eval_hours = Int(exp["eval_hours"])
    oos_sample_hours = Int(exp["oos_sample_hours"])
    eval_start_offset = Int(get(exp, "eval_start_offset", 0))
    eval_start = train_hours + eval_start_offset
    eval_offsets = haskey(exp, "eval_hour_offsets") ? as_int_vector(exp["eval_hour_offsets"]) : collect(1:eval_hours)
    !isempty(eval_offsets) && issorted(eval_offsets) && allunique(eval_offsets) && minimum(eval_offsets) >= 1 ||
        error("eval_hour_offsets must be a nonempty sorted list of distinct positive offsets")
    eval_hours = length(eval_offsets)
    eval_times = eval_start .+ eval_offsets
    # Each evaluated hour audits against a future sample-out block.  This avoids
    # reusing same-day OOS errors inside later rolling training windows.
    max_needed = maximum(eval_times) + oos_sample_hours
    max_needed <= size(data.omega, 1) || error("Not enough aligned data rows for the requested experiment")

    kmax = Int(exp["K"])
    rep_ratio_grid = as_float_vector(exp["rep_ratio_grid"])
    rho_grid = as_float_vector(exp["rho_grid"])
    delta_grid = as_float_vector(exp["delta_w_grid"])
    divergence = String(exp["divergence"])
    epsilon = Float64(exp["epsilon"])
    out_root = haskey(exp, "output_subdir") ? joinpath(project_dir, "results", String(exp["output_subdir"])) :
        joinpath(project_dir, "results", Dates.format(now(), dateformat"yyyymmdd_HHMMSS") * "_" * String(cfg["name"]))
    mkpath(out_root)
    open(joinpath(out_root, "config_used.json"), "w") do io
        JSON.print(io, cfg, 2)
    end
    nrow(stress_diagnostics) > 0 && CSV.write(joinpath(out_root, "stress_diagnostics.csv"), stress_diagnostics)
    if nrow(stress_diagnostics) > 0
        eval_ids = eval_times
        condition = DataFrame(eval_index=collect(1:eval_hours), time=data.times[eval_ids],
            conventional_capacity_mw=fill(sum(case.gen[:, 9]), eval_hours),
            load_forecast_mw=vec(sum(data.load_forecast[eval_ids, :]; dims=2)),
            wind_forecast_mw=vec(sum(data.wind_forecast[eval_ids, :]; dims=2)),
            wind_actual_mw=vec(sum(data.wind_actual[eval_ids, :]; dims=2)),
            aggregate_error_mw=vec(sum(data.omega[eval_ids, :]; dims=2)))
        condition.nominal_headroom_mw = condition.conventional_capacity_mw .+ condition.wind_forecast_mw .- condition.load_forecast_mw
        CSV.write(joinpath(out_root, "operating_conditions.csv"), condition)
    end

    results = DataFrame()
    scenario_id = 0
    methods = haskey(exp, "comparison_methods") ? as_string_vector(exp["comparison_methods"]) : ["proposed"]
    reliability_sample_limit = Int(get(exp, "reliability_sample_limit", min(oos_sample_hours, 24)))
    global_rep_mode = lowercase(String(get(exp, "global_rep_mode", "all")))
    rho_regime_mode = lowercase(String(get(exp, "rho_regime_mode", "uniform")))
    rolling_train_window = as_bool(get(exp, "rolling_train_window", false))
    representative_sample_limit = Int(get(exp, "representative_sample_limit", 0))
    report_gmm = nothing
    build_support = function(train_x::Matrix{Float64}, rep_ratio::Float64, seed::Integer)
        gmm = fit_diag_gmm(train_x, kmax; max_iter=Int(exp["gmm_max_iter"]), seed=seed)
        rep_ids = representative_indices(gmm.gamma_train, rep_ratio;
            max_per_regime=Int(exp["max_rep_per_regime"]),
            max_total=representative_sample_limit)
        mixture_reps = [train_x[ids, :] for ids in rep_ids]
        mixture_budget = sum(length.(rep_ids))
        global_budget = representative_sample_limit > 0 ? min(representative_sample_limit, size(train_x, 1)) : mixture_budget
        global_ids = global_representative_indices(gmm.gamma_train, global_budget; mode=global_rep_mode)
        global_reps = [train_x[global_ids, :]]
        return (
            gmm=gmm,
            mixture_reps=mixture_reps,
            global_reps=global_reps,
        )
    end
    build_rolling_context = function(hidx::Integer, rep_ratio::Float64)
        t = eval_times[hidx]
        train_lo = t - train_hours
        train_hi = t - 1
        train_lo >= 1 || error("Training window starts before the first aligned row. Increase train_hours or eval_start_offset.")
        train_x = data.omega[train_lo:train_hi, :]
        support = build_support(train_x, rep_ratio, Int(exp["random_seed"]) + hidx)
        return (
            gmm=support.gmm,
            gamma_history=support.gmm.gamma_train,
            mixture_reps=support.mixture_reps,
            global_reps=support.global_reps,
        )
    end
    build_fixed_contexts = function(rep_ratio::Float64)
        train_x = data.omega[1:train_hours, :]
        support = build_support(train_x, rep_ratio, Int(exp["random_seed"]))
        history_hi = maximum(eval_times) - 1
        gamma_all = responsibilities(support.gmm, data.omega[1:history_hi, :])
        return [
            (
                gmm=support.gmm,
                gamma_history=gamma_all[1:(eval_times[hidx] - 1), :],
                mixture_reps=support.mixture_reps,
                global_reps=support.global_reps,
            )
            for hidx in 1:eval_hours
        ]
    end
    for rep_ratio in rep_ratio_grid
        context_cache = rolling_train_window ?
            [build_rolling_context(hidx, rep_ratio) for hidx in 1:eval_hours] :
            build_fixed_contexts(rep_ratio)
        report_gmm === nothing && (report_gmm = context_cache[1].gmm)
        for method in methods
            method_l = lowercase(method)
            for mc in method_cases(method, rho_grid, delta_grid)
                scenario_id += 1
                println("Running scenario $scenario_id: method=$method_l, rho=$(mc.rho), delta_w=$(mc.delta_w), eval_hours=$eval_hours, reliability_samples=$reliability_sample_limit")
                flush(stdout)
                use_global = method_l in ("empirical", "empirical_cvar", "single_tv", "single")
                for hidx in 1:eval_hours
                    ctx = context_cache[hidx]
                    reps = use_global ? ctx.global_reps : ctx.mixture_reps
                    local_k = length(reps)
                    # Single-support methods (empirical / single-TV) keep the
                    # base radius; mixture methods may scale per regime by count.
                    rho_vec = use_global ? fill(mc.rho, local_k) :
                        regime_radii(mc.rho, reps, rho_regime_mode)
                    t = eval_times[hidx]
                    pred_mode = String(exp["predictive_error"])
                    omega_hat = pred_mode == "zero" ? zeros(Float64, size(data.omega, 2)) : vec(data.omega[max(1, t - 1), :])
                    load_t = vec(data.load_forecast[t, :])
                    wind_t = vec(data.wind_forecast[t, :])
                    wind_spill_penalty = Float64(get(exp, "wind_spill_penalty", 1.0e-3))
                    risk_slack_penalty = Float64(get(exp, "risk_slack_penalty", 0.0))
                    if method_l in ("deterministic", "deterministic_headroom")
                        pi_t = Float64[]
                        sol = solve_deterministic_ols(case, load_t, wind_t;
                            time_limit=Float64(exp["solver_time_limit_sec"]),
                            tie_breaker=Float64(exp["tie_breaker"]),
                            wind_spill_penalty=wind_spill_penalty)
                        if method_l == "deterministic_headroom" && sol.has_values
                            # Strong forecast-only baseline: expose all free physical
                            # generation headroom to the same fixed AGC policy.
                            sol = merge(sol, (rU=max.(case.gen[:, 9] .- sol.g, 0.0),
                                rD=max.(sol.g .- case.gen[:, 10], 0.0)))
                        end
                    else
                        pi_t = if use_global
                            [1.0]
                        elseif method_l in ("mixture_static", "static")
                            copy(ctx.gmm.weights)
                        elseif method_l in ("predictive_only", "predictive")
                            responsibility(ctx.gmm, omega_hat)
                        else
                            rolling_weights_from_history(ctx.gmm, ctx.gamma_history, omega_hat;
                                window=Int(exp["rolling_window"]),
                                kappa=Float64(exp["kappa"]),
                                blend_rho=Float64(exp["blend_rho"]))
                        end
                        sol = solve_drcc_ols(case, load_t, wind_t, pi_t, reps, rho_vec;
                            epsilon=epsilon, delta_w=mc.delta_w, divergence=divergence,
                            time_limit=Float64(exp["solver_time_limit_sec"]),
                            tie_breaker=Float64(exp["tie_breaker"]),
                            wind_spill_penalty=wind_spill_penalty,
                            risk_slack_penalty=risk_slack_penalty)
                    end
                    realized_omega = vec(data.omega[t, :])
                    realized_v = max_violation(case, sol, load_t, wind_t, realized_omega)
                    realized_em = emergency_shed_if_needed(case, sol, load_t, wind_t, realized_omega;
                        violation=realized_v)
                    realized_eens = sol.has_values && isfinite(realized_em.shed) ? sol.load_shed + realized_em.shed : NaN
                    oos_lo = t + 1
                    oos_hi = t + oos_sample_hours
                    oos_hi <= size(data.omega, 1) || error("Not enough aligned data rows for the requested per-hour OOS audit block")
                    oos_errors = data.omega[oos_lo:oos_hi, :]
                    stats = oos_stats(case, sol, load_t, wind_t, oos_errors;
                        reliability_sample_limit=reliability_sample_limit)
                    push!(results, (
                        scenario_id=scenario_id,
                        method=method_l,
                        eval_index=hidx,
                        time=data.times[t],
                        divergence=divergence,
                        K=method_l in ("deterministic", "deterministic_headroom", "empirical", "empirical_cvar", "single_tv", "single") ? local_k : kmax,
                        rep_ratio=rep_ratio,
                        global_rep_mode=global_rep_mode,
                        rho_regime_mode=(use_global ? "uniform" : rho_regime_mode),
                        rep_count=sum(size(r, 1) for r in reps),
                        rho=mc.rho,
                        delta_w=mc.delta_w,
                        status=sol.status,
                        has_values=sol.has_values,
                        objective=sol.objective,
                        load_shed=sol.load_shed,
                        wind_curtailment=sol.has_values ? sol.wind_curtailment : NaN,
                        solve_time_sec=sol.solve_time,
                        lp_variables=sol.lp_variables,
                        lp_constraints=sol.lp_constraints,
                        risk_lhs=sol.risk_lhs,
                        risk_slack=sol.risk_slack,
                        realized_max_violation=realized_v,
                        realized_violated=isfinite(realized_v) ? Float64(realized_v > 1.0e-6) : NaN,
                        realized_eens_mwh=realized_eens,
                        realized_lolp=isfinite(realized_eens) ? Float64(realized_eens > 1.0e-6) : NaN,
                        realized_emergency_shed_mwh=realized_em.shed,
                        realized_residual_slack=realized_em.residual_slack,
                        realized_wind_dispatch_shortfall_mw=sol.has_values ? sum(max.(sol.wind_spill .- vec(data.wind_actual[t, :]), 0.0)) : NaN,
                        oos_violation_rate=stats.violation_rate,
                        oos_avg_positive_violation=stats.avg_positive_violation,
                        oos_avg_total_positive_violation=stats.avg_total_positive_violation,
                        oos_max_positive_violation=stats.max_positive_violation,
                        oos_max_violation=stats.max_violation,
                        oos_eens_mwh=stats.eens_mwh,
                        oos_planned_eens_mwh=stats.planned_eens_mwh,
                        oos_emergency_eens_mwh=stats.emergency_eens_mwh,
                        oos_lolp=stats.lolp,
                        oos_lole_h=stats.lole_h,
                        oos_residual_security_rate=stats.residual_security_rate,
                        reliability_samples=stats.reliability_samples,
                        pi=isempty(pi_t) ? "" : join(round.(pi_t, digits=4), ";"),
                        beta=sol.has_values ? join(round.(sol.beta, digits=4), ";") : "",
                        dL=sol.has_values ? join(round.(sol.dL, digits=4), ";") : "",
                        wind_spill=sol.has_values ? join(round.(sol.wind_spill, digits=4), ";") : ""
                    ))
                    sol = nothing
                    stats = nothing
                    if hidx % 6 == 0
                        GC.gc()
                    end
                end
                CSV.write(joinpath(out_root, "dispatch_results_partial.csv"), results)
                flush(stdout)
                GC.gc()
            end
        end
    end
    summary = summarize_results(results)
    best = select_best(summary, epsilon)
    CSV.write(joinpath(out_root, "dispatch_results.csv"), results)
    CSV.write(joinpath(out_root, "summary.csv"), summary)
    nrow(data.wind_quality) > 0 && CSV.write(joinpath(out_root, "wind_quality.csv"), data.wind_quality)
    nrow(data.load_quality) > 0 && CSV.write(joinpath(out_root, "load_quality.csv"), data.load_quality)
    write_report(joinpath(out_root, "report.md"), cfg, case, data, report_gmm, results, summary, best)
    println("Results directory: $out_root")
    println("Best scenario: $(best.scenario_id) ($(best.method)), EENS=$(round(best.total_oos_eens_mwh, digits=4)) MWh, LOLP=$(round(best.avg_oos_lolp, digits=4))")
    return out_root
end

end # module
