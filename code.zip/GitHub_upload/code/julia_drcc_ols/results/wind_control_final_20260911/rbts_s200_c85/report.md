# MA-DRCC-OLS Experiment Report

- Generated at: 2026-09-11 17:19:46
- Model: mixture phi-divergence DRCC-OLS with predictive-rolling weights and outer L1 weight ambiguity
- Divergence: tv
- Buses/generators/lines: 6/10/9
- Data rows used by loader: 8736
- GMM implementation: diagonal-covariance Gaussian mixture fitted on historical nodal net-injection errors.
- Predictive error proxy: previous_error.
- Global empirical/single-TV support mode: budgeted.
- Wind data screening: 0 corrected events across 69999 observations (0.0%).
- Load data screening: 0 corrected events across 104832 observations (0.0%).
- GMM weights: 0.147, 0.6497, 0.2034
- Best scenario id: 5 (mixture_rolling, complete comparison row)
- Best scheduled pre-contingency load shedding: 2.4474 MW
- Best OOS EENS over evaluated hours: 176.3907 MWh
- Best average OOS LOLP: 0.1810

## Wind Data Quality

|source|capacity MW|obs.|missing/nonfinite|negative|above cap.|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|Wind farm site 5 (Nominal capacity-36MW).xlsx|36.00|69999|0|0|0|0|2|0.0000|

## Load Data Quality

|source|bus|obs.|missing/nonfinite|negative|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|

## Scenario Summary

|scenario|method|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|1|deterministic_headroom|0.0000|2.7558|198.4161|0.3398|24.4688|0.7457|7.2000|3.1701|0.001|67|114|72/72|yes|
|2|empirical_cvar|2.9468|2.9468|212.1673|0.2917|21.0000|0.0000|0.0000|0.0000|0.205|294|9913|72/72|yes|
|3|single_tv|3.1867|3.1867|229.4401|0.3056|22.0000|0.0000|0.0000|0.0000|0.176|294|9913|72/72|yes|
|4|mixture_static|2.8210|2.8210|203.1085|0.2778|20.0000|0.0000|0.0000|0.0000|0.199|302|9923|72/72|yes|
|5|mixture_rolling|2.4474|2.4499|176.3907|0.1810|13.0312|0.0431|1.2571|0.1835|0.253|302|9923|72/72|yes|
|6|proposed|2.5134|2.5134|180.9684|0.2222|16.0000|0.0234|0.2985|0.0215|0.237|302|9923|72/72|yes|

## Best By Method

|method|scenario|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|deterministic_headroom|1|0.0000|2.7558|198.4161|0.3398|24.4688|0.7457|7.2000|3.1701|0.001|67|114|72/72|yes|
|empirical_cvar|2|2.9468|2.9468|212.1673|0.2917|21.0000|0.0000|0.0000|0.0000|0.205|294|9913|72/72|yes|
|single_tv|3|3.1867|3.1867|229.4401|0.3056|22.0000|0.0000|0.0000|0.0000|0.176|294|9913|72/72|yes|
|mixture_static|4|2.8210|2.8210|203.1085|0.2778|20.0000|0.0000|0.0000|0.0000|0.199|302|9923|72/72|yes|
|mixture_rolling|5|2.4474|2.4499|176.3907|0.1810|13.0312|0.0431|1.2571|0.1835|0.253|302|9923|72/72|yes|
|proposed|6|2.5134|2.5134|180.9684|0.2222|16.0000|0.0234|0.2985|0.0215|0.237|302|9923|72/72|yes|

## Proposed Advantage

|baseline|EENS reduction|LOLP reduction|security-violation reduction|
|---|---:|---:|---:|
|deterministic_headroom|8.8%|34.6%|96.9%|
|empirical_cvar|14.7%|23.8%|worse|
|single_tv|21.1%|27.3%|worse|
|mixture_static|10.9%|20.0%|worse|
|mixture_rolling|-2.6%|-22.8%|45.6%|

## Notes

- EDNS is computed as EENS divided by the evaluated rolling hours, so it reports the average unserved power in the out-of-sample reliability audit.
- Scheduled shedding is the preventive load-shedding decision returned by the optimization model before out-of-sample forecast-error realizations are audited.
- EENS is computed as planned load shedding plus the minimum emergency load shedding needed to restore generator reserve and line constraints under sampled forecast errors.
- LOLP is the sample probability that planned or emergency load shedding is positive; LOLE is the sum of hourly LOLP values over the evaluated rolling horizon.
- `security viol.` is the probability of any raw operating-limit violation before emergency corrective shedding.
- `max viol.` is the largest positive post-event physical-constraint exceedance over the sampled audit errors; `mean total viol.` averages the sum of positive generator and line exceedances per test case.
- LP variables and constraints count the optimization model sent to the LP solver before presolve.
- The tiny tie-breaker only stabilizes reserve/generation choices; the reported shedding remains the primary metric.
