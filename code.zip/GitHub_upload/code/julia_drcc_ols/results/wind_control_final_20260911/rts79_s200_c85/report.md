# MA-DRCC-OLS Experiment Report

- Generated at: 2026-09-11 17:11:27
- Model: mixture phi-divergence DRCC-OLS with predictive-rolling weights and outer L1 weight ambiguity
- Divergence: tv
- Buses/generators/lines: 24/26/38
- Data rows used by loader: 8736
- GMM implementation: diagonal-covariance Gaussian mixture fitted on historical nodal net-injection errors.
- Predictive error proxy: previous_error.
- Global empirical/single-TV support mode: budgeted.
- Wind data screening: 20549 corrected events across 420879 observations (4.882%).
- Load data screening: 0 corrected events across 419328 observations (0.0%).
- GMM weights: 0.2962, 0.1422, 0.5616
- Best scenario id: 1 (deterministic_headroom, complete comparison row)
- Best scheduled pre-contingency load shedding: 0.0000 MW
- Best OOS EENS over evaluated hours: 1313.5698 MWh
- Best average OOS LOLP: 0.5187

## Wind Data Quality

|source|capacity MW|obs.|missing/nonfinite|negative|above cap.|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|Wind farm site 1 (Nominal capacity-99MW).xlsx|99.00|70176|0|0|0|0|0|0.0000|
|Wind farm site 2 (Nominal capacity-200MW).xlsx|200.00|70176|0|0|0|1|6|0.0000|
|Wind farm site 3 (Nominal capacity-99MW).xlsx|99.00|70176|0|12979|0|0|0|0.1849|
|Wind farm site 4 (Nominal capacity-66MW).xlsx|66.00|70176|0|0|0|0|2|0.0000|
|Wind farm site 5 (Nominal capacity-36MW).xlsx|36.00|69999|0|0|0|0|2|0.0000|
|Wind farm site 6 (Nominal capacity-96MW).xlsx|96.00|70176|0|7566|2|1|6|0.1079|

## Load Data Quality

|source|bus|obs.|missing/nonfinite|negative|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|

## Scenario Summary

|scenario|method|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|1|deterministic_headroom|54.7321|1313.5698|0.5187|12.4479|0.9813|132.2448|67.9304|0.002|186|346|24/24|yes|
|2|empirical_cvar|NaN|NaN|NaN|NaN|NaN|NaN|NaN|2.353|381|31639|0/24|no|
|3|single_tv|NaN|NaN|NaN|NaN|NaN|NaN|NaN|1.999|381|31639|0/24|no|
|4|mixture_static|NaN|NaN|NaN|NaN|NaN|NaN|NaN|2.569|389|31649|0/24|no|
|5|mixture_rolling|NaN|NaN|NaN|NaN|NaN|NaN|NaN|3.008|389|31649|0/24|no|
|6|proposed|NaN|NaN|NaN|NaN|NaN|NaN|NaN|2.790|389|31649|0/24|no|

## Best By Method

|method|scenario|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|deterministic_headroom|1|54.7321|1313.5698|0.5187|12.4479|0.9813|132.2448|67.9304|0.002|186|346|24/24|yes|
|empirical_cvar|2|NaN|NaN|NaN|NaN|NaN|NaN|NaN|2.353|381|31639|0/24|no|
|single_tv|3|NaN|NaN|NaN|NaN|NaN|NaN|NaN|1.999|381|31639|0/24|no|
|mixture_static|4|NaN|NaN|NaN|NaN|NaN|NaN|NaN|2.569|389|31649|0/24|no|
|mixture_rolling|5|NaN|NaN|NaN|NaN|NaN|NaN|NaN|3.008|389|31649|0/24|no|
|proposed|6|NaN|NaN|NaN|NaN|NaN|NaN|NaN|2.790|389|31649|0/24|no|

## Proposed Advantage

|baseline|EENS reduction|LOLP reduction|security-violation reduction|
|---|---:|---:|---:|
|deterministic_headroom|n/a|n/a|n/a|
|empirical_cvar|n/a|n/a|n/a|
|single_tv|n/a|n/a|n/a|
|mixture_static|n/a|n/a|n/a|
|mixture_rolling|n/a|n/a|n/a|

## Notes

- EDNS is computed as EENS divided by the evaluated rolling hours, so it reports the average unserved power in the out-of-sample reliability audit.
- Scheduled pre-contingency load shedding is omitted from the tables because it is zero for all retained rows in this run.
- EENS is computed as planned load shedding plus the minimum emergency load shedding needed to restore generator reserve and line constraints under sampled forecast errors.
- LOLP is the sample probability that planned or emergency load shedding is positive; LOLE is the sum of hourly LOLP values over the evaluated rolling horizon.
- `security viol.` is the probability of any raw operating-limit violation before emergency corrective shedding.
- `max viol.` is the largest positive post-event physical-constraint exceedance over the sampled audit errors; `mean total viol.` averages the sum of positive generator and line exceedances per test case.
- LP variables and constraints count the optimization model sent to the LP solver before presolve.
- The tiny tie-breaker only stabilizes reserve/generation choices; the reported shedding remains the primary metric.
