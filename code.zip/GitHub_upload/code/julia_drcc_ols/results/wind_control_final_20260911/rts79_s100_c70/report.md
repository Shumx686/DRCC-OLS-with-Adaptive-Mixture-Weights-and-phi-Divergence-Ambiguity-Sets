# MA-DRCC-OLS Experiment Report

- Generated at: 2026-09-11 16:56:32
- Model: mixture phi-divergence DRCC-OLS with predictive-rolling weights and outer L1 weight ambiguity
- Divergence: tv
- Buses/generators/lines: 24/26/38
- Data rows used by loader: 8736
- GMM implementation: diagonal-covariance Gaussian mixture fitted on historical nodal net-injection errors.
- Predictive error proxy: previous_error.
- Global empirical/single-TV support mode: budgeted.
- Wind data screening: 20549 corrected events across 420879 observations (4.882%).
- Load data screening: 0 corrected events across 419328 observations (0.0%).
- GMM weights: 0.2009, 0.1523, 0.6468
- Best scenario id: 1 (deterministic_headroom, complete comparison row)
- Best scheduled pre-contingency load shedding: 135.6628 MW
- Best OOS EENS over evaluated hours: 4517.6487 MWh
- Best average OOS LOLP: 0.8073

## Wind Data Quality

|source|capacity MW|obs.|missing/nonfinite|negative|above cap.|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|Wind farm site 1 (Nominal capacity-99MW).xlsx|99.00|70176|0|0|0|0|0|0.0000|
|Wind farm site 2 (Nominal capacity-200MW).xlsx|200.00|70176|0|0|0|1|6|0.0000|
|Wind farm site 3 (Nominal capacity-99MW).xlsx|99.00|70176|0|12979|0|0|0|0.1849|
|Wind farm site 4 (Nominal capacity-66MW).xlsx|66.00|70176|0|0|0|0|2|0.0000|
|Wind farm site 5 (Nominal capacity-36MW).xlsx|36.00|69999|0|0|0|0|2|0.0000|
|Wind farm site 6 (Nominal capacity-96MW).xlsx|96.00|70176|0|7566|2|1|6|0.1079|

## Load Data Quality

|source|bus|obs.|missing/nonfinite|negative|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|

## Scenario Summary

|scenario|method|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|1|deterministic_headroom|135.6628|188.2354|4517.6487|0.8073|19.3750|0.7435|114.0800|54.6206|0.003|186|346|24/24|yes|
|2|empirical_cvar|218.9847|222.5573|5341.3755|0.6992|16.7812|0.1115|73.4425|4.0830|2.702|381|31639|24/24|yes|
|3|single_tv|231.7339|234.1621|5619.8916|0.7678|18.4271|0.0942|62.0793|2.9866|2.236|381|31639|24/24|yes|
|4|mixture_static|230.6617|233.0044|5592.1060|0.6888|16.5313|0.0929|65.6432|2.9333|2.528|389|31649|24/24|yes|
|5|mixture_rolling|233.1038|235.2189|5645.2530|0.7266|17.4375|0.0812|71.7555|2.5605|2.236|389|31649|24/24|yes|
|6|proposed|233.5031|235.6504|5655.6103|0.7270|17.4479|0.0842|70.9786|2.8396|1.903|389|31649|24/24|yes|

## Best By Method

|method|scenario|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|deterministic_headroom|1|135.6628|188.2354|4517.6487|0.8073|19.3750|0.7435|114.0800|54.6206|0.003|186|346|24/24|yes|
|empirical_cvar|2|218.9847|222.5573|5341.3755|0.6992|16.7812|0.1115|73.4425|4.0830|2.702|381|31639|24/24|yes|
|single_tv|3|231.7339|234.1621|5619.8916|0.7678|18.4271|0.0942|62.0793|2.9866|2.236|381|31639|24/24|yes|
|mixture_static|4|230.6617|233.0044|5592.1060|0.6888|16.5313|0.0929|65.6432|2.9333|2.528|389|31649|24/24|yes|
|mixture_rolling|5|233.1038|235.2189|5645.2530|0.7266|17.4375|0.0812|71.7555|2.5605|2.236|389|31649|24/24|yes|
|proposed|6|233.5031|235.6504|5655.6103|0.7270|17.4479|0.0842|70.9786|2.8396|1.903|389|31649|24/24|yes|

## Proposed Advantage

|baseline|EENS reduction|LOLP reduction|security-violation reduction|
|---|---:|---:|---:|
|deterministic_headroom|-25.2%|9.9%|88.7%|
|empirical_cvar|-5.9%|-4.0%|24.5%|
|single_tv|-0.6%|5.3%|10.6%|
|mixture_static|-1.1%|-5.5%|9.3%|
|mixture_rolling|-0.2%|-0.1%|-3.7%|

## Notes

- EDNS is computed as EENS divided by the evaluated rolling hours, so it reports the average unserved power in the out-of-sample reliability audit.
- Scheduled shedding is the preventive load-shedding decision returned by the optimization model before out-of-sample forecast-error realizations are audited.
- EENS is computed as planned load shedding plus the minimum emergency load shedding needed to restore generator reserve and line constraints under sampled forecast errors.
- LOLP is the sample probability that planned or emergency load shedding is positive; LOLE is the sum of hourly LOLP values over the evaluated rolling horizon.
- `security viol.` is the probability of any raw operating-limit violation before emergency corrective shedding.
- `max viol.` is the largest positive post-event physical-constraint exceedance over the sampled audit errors; `mean total viol.` averages the sum of positive generator and line exceedances per test case.
- LP variables and constraints count the optimization model sent to the LP solver before presolve.
- The tiny tie-breaker only stabilizes reserve/generation choices; the reported shedding remains the primary metric.
