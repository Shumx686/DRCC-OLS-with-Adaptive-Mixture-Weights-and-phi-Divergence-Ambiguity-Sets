# MA-DRCC-OLS Experiment Report

- Generated at: 2026-09-11 17:15:49
- Model: mixture phi-divergence DRCC-OLS with predictive-rolling weights and outer L1 weight ambiguity
- Divergence: tv
- Buses/generators/lines: 6/10/9
- Data rows used by loader: 8736
- GMM implementation: diagonal-covariance Gaussian mixture fitted on historical nodal net-injection errors.
- Predictive error proxy: previous_error.
- Global empirical/single-TV support mode: budgeted.
- Wind data screening: 0 corrected events across 69999 observations (0.0%).
- Load data screening: 0 corrected events across 104832 observations (0.0%).
- GMM weights: 0.4627, 0.1689, 0.3684
- Best scenario id: 1 (deterministic_headroom, complete comparison row)
- Best scheduled pre-contingency load shedding: 2.2176 MW
- Best OOS EENS over evaluated hours: 332.5181 MWh
- Best average OOS LOLP: 0.4988

## Wind Data Quality

|source|capacity MW|obs.|missing/nonfinite|negative|above cap.|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|Wind farm site 5 (Nominal capacity-36MW).xlsx|36.00|69999|0|0|0|0|2|0.0000|

## Load Data Quality

|source|bus|obs.|missing/nonfinite|negative|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|

## Scenario Summary

|scenario|method|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|1|deterministic_headroom|2.2176|4.6183|332.5181|0.4988|35.9167|0.5632|6.2895|2.2648|0.001|67|114|72/72|yes|
|2|empirical_cvar|16.1816|16.1816|1165.0752|0.6250|45.0000|0.0000|0.0000|0.0000|0.189|294|9913|72/72|yes|
|3|single_tv|17.0017|17.0017|1224.1195|0.6389|46.0000|0.0000|0.0000|0.0000|0.207|294|9913|72/72|yes|
|4|mixture_static|16.3994|16.3994|1180.7602|0.6250|45.0000|0.0000|0.0000|0.0000|0.207|302|9923|72/72|yes|
|5|mixture_rolling|13.9553|13.9553|1004.7825|0.5139|37.0000|0.0000|0.0000|0.0000|0.228|302|9923|72/72|yes|
|6|proposed|14.4523|14.4523|1040.5649|0.5417|39.0000|0.0000|0.0000|0.0000|0.232|302|9923|72/72|yes|

## Best By Method

|method|scenario|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|deterministic_headroom|1|2.2176|4.6183|332.5181|0.4988|35.9167|0.5632|6.2895|2.2648|0.001|67|114|72/72|yes|
|empirical_cvar|2|16.1816|16.1816|1165.0752|0.6250|45.0000|0.0000|0.0000|0.0000|0.189|294|9913|72/72|yes|
|single_tv|3|17.0017|17.0017|1224.1195|0.6389|46.0000|0.0000|0.0000|0.0000|0.207|294|9913|72/72|yes|
|mixture_static|4|16.3994|16.3994|1180.7602|0.6250|45.0000|0.0000|0.0000|0.0000|0.207|302|9923|72/72|yes|
|mixture_rolling|5|13.9553|13.9553|1004.7825|0.5139|37.0000|0.0000|0.0000|0.0000|0.228|302|9923|72/72|yes|
|proposed|6|14.4523|14.4523|1040.5649|0.5417|39.0000|0.0000|0.0000|0.0000|0.232|302|9923|72/72|yes|

## Proposed Advantage

|baseline|EENS reduction|LOLP reduction|security-violation reduction|
|---|---:|---:|---:|
|deterministic_headroom|-212.9%|-8.6%|100.0%|
|empirical_cvar|10.7%|13.3%|tie|
|single_tv|15.0%|15.2%|tie|
|mixture_static|11.9%|13.3%|tie|
|mixture_rolling|-3.6%|-5.4%|tie|

## Notes

- EDNS is computed as EENS divided by the evaluated rolling hours, so it reports the average unserved power in the out-of-sample reliability audit.
- Scheduled shedding is the preventive load-shedding decision returned by the optimization model before out-of-sample forecast-error realizations are audited.
- EENS is computed as planned load shedding plus the minimum emergency load shedding needed to restore generator reserve and line constraints under sampled forecast errors.
- LOLP is the sample probability that planned or emergency load shedding is positive; LOLE is the sum of hourly LOLP values over the evaluated rolling horizon.
- `security viol.` is the probability of any raw operating-limit violation before emergency corrective shedding.
- `max viol.` is the largest positive post-event physical-constraint exceedance over the sampled audit errors; `mean total viol.` averages the sum of positive generator and line exceedances per test case.
- LP variables and constraints count the optimization model sent to the LP solver before presolve.
- The tiny tie-breaker only stabilizes reserve/generation choices; the reported shedding remains the primary metric.
