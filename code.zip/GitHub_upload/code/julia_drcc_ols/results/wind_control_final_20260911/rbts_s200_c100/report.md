# MA-DRCC-OLS Experiment Report

- Generated at: 2026-09-11 17:20:34
- Model: mixture phi-divergence DRCC-OLS with predictive-rolling weights and outer L1 weight ambiguity
- Divergence: tv
- Buses/generators/lines: 6/10/9
- Data rows used by loader: 8736
- GMM implementation: diagonal-covariance Gaussian mixture fitted on historical nodal net-injection errors.
- Predictive error proxy: previous_error.
- Global empirical/single-TV support mode: budgeted.
- Wind data screening: 0 corrected events across 69999 observations (0.0%).
- Load data screening: 0 corrected events across 104832 observations (0.0%).
- GMM weights: 0.147, 0.6497, 0.2034
- Best scenario id: 2 (empirical_cvar, complete comparison row)
- Best scheduled pre-contingency load shedding: 0.0000 MW
- Best OOS EENS over evaluated hours: 0.0000 MWh
- Best average OOS LOLP: 0.0000

## Wind Data Quality

|source|capacity MW|obs.|missing/nonfinite|negative|above cap.|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|Wind farm site 5 (Nominal capacity-36MW).xlsx|36.00|69999|0|0|0|0|2|0.0000|

## Load Data Quality

|source|bus|obs.|missing/nonfinite|negative|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|

## Scenario Summary

|scenario|method|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|1|deterministic_headroom|2.7558|198.4161|0.3398|24.4688|0.8938|7.2000|3.7219|0.001|67|114|72/72|yes|
|2|empirical_cvar|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.204|294|9913|72/72|yes|
|3|single_tv|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.162|294|9913|72/72|yes|
|4|mixture_static|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.192|302|9923|72/72|yes|
|5|mixture_rolling|0.0028|0.1985|0.0006|0.0417|0.0509|1.2860|0.2073|0.217|302|9923|72/72|yes|
|6|proposed|0.0000|0.0000|0.0000|0.0000|0.0323|0.2937|0.0335|0.228|302|9923|72/72|yes|

## Best By Method

|method|scenario|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|deterministic_headroom|1|2.7558|198.4161|0.3398|24.4688|0.8938|7.2000|3.7219|0.001|67|114|72/72|yes|
|empirical_cvar|2|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.204|294|9913|72/72|yes|
|single_tv|3|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.162|294|9913|72/72|yes|
|mixture_static|4|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.0000|0.192|302|9923|72/72|yes|
|mixture_rolling|5|0.0028|0.1985|0.0006|0.0417|0.0509|1.2860|0.2073|0.217|302|9923|72/72|yes|
|proposed|6|0.0000|0.0000|0.0000|0.0000|0.0323|0.2937|0.0335|0.228|302|9923|72/72|yes|

## Proposed Advantage

|baseline|EENS reduction|LOLP reduction|security-violation reduction|
|---|---:|---:|---:|
|deterministic_headroom|100.0%|100.0%|96.4%|
|empirical_cvar|tie|tie|worse|
|single_tv|tie|tie|worse|
|mixture_static|tie|tie|worse|
|mixture_rolling|100.0%|100.0%|36.6%|

## Notes

- EDNS is computed as EENS divided by the evaluated rolling hours, so it reports the average unserved power in the out-of-sample reliability audit.
- Scheduled pre-contingency load shedding is omitted from the tables because it is zero for all retained rows in this run.
- EENS is computed as planned load shedding plus the minimum emergency load shedding needed to restore generator reserve and line constraints under sampled forecast errors.
- LOLP is the sample probability that planned or emergency load shedding is positive; LOLE is the sum of hourly LOLP values over the evaluated rolling horizon.
- `security viol.` is the probability of any raw operating-limit violation before emergency corrective shedding.
- `max viol.` is the largest positive post-event physical-constraint exceedance over the sampled audit errors; `mean total viol.` averages the sum of positive generator and line exceedances per test case.
- LP variables and constraints count the optimization model sent to the LP solver before presolve.
- The tiny tie-breaker only stabilizes reserve/generation choices; the reported shedding remains the primary metric.
