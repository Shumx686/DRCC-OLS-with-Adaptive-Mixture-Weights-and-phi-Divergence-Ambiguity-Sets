# MA-DRCC-OLS Experiment Report

- Generated at: 2026-09-11 17:16:59
- Model: mixture phi-divergence DRCC-OLS with predictive-rolling weights and outer L1 weight ambiguity
- Divergence: tv
- Buses/generators/lines: 6/10/9
- Data rows used by loader: 8736
- GMM implementation: diagonal-covariance Gaussian mixture fitted on historical nodal net-injection errors.
- Predictive error proxy: previous_error.
- Global empirical/single-TV support mode: budgeted.
- Wind data screening: 0 corrected events across 69999 observations (0.0%).
- Load data screening: 0 corrected events across 104832 observations (0.0%).
- GMM weights: 0.1552, 0.6631, 0.1818
- Best scenario id: 5 (mixture_rolling, complete comparison row)
- Best scheduled pre-contingency load shedding: 2.3420 MW
- Best OOS EENS over evaluated hours: 168.7378 MWh
- Best average OOS LOLP: 0.1808

## Wind Data Quality

|source|capacity MW|obs.|missing/nonfinite|negative|above cap.|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|Wind farm site 5 (Nominal capacity-36MW).xlsx|36.00|69999|0|0|0|0|2|0.0000|

## Load Data Quality

|source|bus|obs.|missing/nonfinite|negative|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|

## Scenario Summary

|scenario|method|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|1|deterministic_headroom|0.0000|2.6840|193.2473|0.3398|24.4688|0.7448|7.2000|2.8755|0.001|67|114|72/72|yes|
|2|empirical_cvar|2.8535|2.8535|205.4526|0.2917|21.0000|0.0000|0.0000|0.0000|0.177|294|9913|72/72|yes|
|3|single_tv|3.1561|3.1561|227.2427|0.3056|22.0000|0.0000|0.0000|0.0000|0.143|294|9913|72/72|yes|
|4|mixture_static|2.6266|2.6266|189.1118|0.2639|19.0000|0.0000|0.0000|0.0000|0.206|302|9923|72/72|yes|
|5|mixture_rolling|2.3420|2.3436|168.7378|0.1808|13.0208|0.0425|1.3235|0.1235|0.270|302|9923|72/72|yes|
|6|proposed|2.3959|2.3959|172.5046|0.1806|13.0000|0.0315|0.4666|0.0606|0.252|302|9923|72/72|yes|

## Best By Method

|method|scenario|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|deterministic_headroom|1|0.0000|2.6840|193.2473|0.3398|24.4688|0.7448|7.2000|2.8755|0.001|67|114|72/72|yes|
|empirical_cvar|2|2.8535|2.8535|205.4526|0.2917|21.0000|0.0000|0.0000|0.0000|0.177|294|9913|72/72|yes|
|single_tv|3|3.1561|3.1561|227.2427|0.3056|22.0000|0.0000|0.0000|0.0000|0.143|294|9913|72/72|yes|
|mixture_static|4|2.6266|2.6266|189.1118|0.2639|19.0000|0.0000|0.0000|0.0000|0.206|302|9923|72/72|yes|
|mixture_rolling|5|2.3420|2.3436|168.7378|0.1808|13.0208|0.0425|1.3235|0.1235|0.270|302|9923|72/72|yes|
|proposed|6|2.3959|2.3959|172.5046|0.1806|13.0000|0.0315|0.4666|0.0606|0.252|302|9923|72/72|yes|

## Proposed Advantage

|baseline|EENS reduction|LOLP reduction|security-violation reduction|
|---|---:|---:|---:|
|deterministic_headroom|10.7%|46.9%|95.8%|
|empirical_cvar|16.0%|38.1%|worse|
|single_tv|24.1%|40.9%|worse|
|mixture_static|8.8%|31.6%|worse|
|mixture_rolling|-2.2%|0.2%|25.9%|

## Notes

- EDNS is computed as EENS divided by the evaluated rolling hours, so it reports the average unserved power in the out-of-sample reliability audit.
- Scheduled shedding is the preventive load-shedding decision returned by the optimization model before out-of-sample forecast-error realizations are audited.
- EENS is computed as planned load shedding plus the minimum emergency load shedding needed to restore generator reserve and line constraints under sampled forecast errors.
- LOLP is the sample probability that planned or emergency load shedding is positive; LOLE is the sum of hourly LOLP values over the evaluated rolling horizon.
- `security viol.` is the probability of any raw operating-limit violation before emergency corrective shedding.
- `max viol.` is the largest positive post-event physical-constraint exceedance over the sampled audit errors; `mean total viol.` averages the sum of positive generator and line exceedances per test case.
- LP variables and constraints count the optimization model sent to the LP solver before presolve.
- The tiny tie-breaker only stabilizes reserve/generation choices; the reported shedding remains the primary metric.
