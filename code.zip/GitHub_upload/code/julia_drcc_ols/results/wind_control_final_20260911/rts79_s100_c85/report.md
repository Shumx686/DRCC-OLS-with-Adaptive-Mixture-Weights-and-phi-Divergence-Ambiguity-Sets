# MA-DRCC-OLS Experiment Report

- Generated at: 2026-09-11 16:56:22
- Model: mixture phi-divergence DRCC-OLS with predictive-rolling weights and outer L1 weight ambiguity
- Divergence: tv
- Buses/generators/lines: 24/26/38
- Data rows used by loader: 8736
- GMM implementation: diagonal-covariance Gaussian mixture fitted on historical nodal net-injection errors.
- Predictive error proxy: previous_error.
- Global empirical/single-TV support mode: budgeted.
- Wind data screening: 20549 corrected events across 420879 observations (4.882%).
- Load data screening: 0 corrected events across 419328 observations (0.0%).
- GMM weights: 0.2009, 0.1523, 0.6468
- Best scenario id: 2 (empirical_cvar, complete comparison row)
- Best scheduled pre-contingency load shedding: 15.9389 MW
- Best OOS EENS over evaluated hours: 453.4658 MWh
- Best average OOS LOLP: 0.5855

## Wind Data Quality

|source|capacity MW|obs.|missing/nonfinite|negative|above cap.|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|Wind farm site 1 (Nominal capacity-99MW).xlsx|99.00|70176|0|0|0|0|0|0.0000|
|Wind farm site 2 (Nominal capacity-200MW).xlsx|200.00|70176|0|0|0|1|6|0.0000|
|Wind farm site 3 (Nominal capacity-99MW).xlsx|99.00|70176|0|12979|0|0|0|0.1849|
|Wind farm site 4 (Nominal capacity-66MW).xlsx|66.00|70176|0|0|0|0|2|0.0000|
|Wind farm site 5 (Nominal capacity-36MW).xlsx|36.00|69999|0|0|0|0|2|0.0000|
|Wind farm site 6 (Nominal capacity-96MW).xlsx|96.00|70176|0|7566|2|1|6|0.1079|

## Load Data Quality

|source|bus|obs.|missing/nonfinite|negative|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|

## Scenario Summary

|scenario|method|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|1|deterministic_headroom|0.0000|52.5725|1261.7405|0.5846|14.0313|0.9800|114.0800|52.1561|0.003|186|346|24/24|yes|
|2|empirical_cvar|15.9389|18.8944|453.4658|0.5855|14.0521|0.1207|74.3425|3.8248|2.627|381|31639|24/24|yes|
|3|single_tv|22.6470|24.6566|591.7584|0.6133|14.7187|0.0825|64.4198|2.6193|2.164|381|31639|24/24|yes|
|4|mixture_static|21.7040|23.5947|566.2727|0.5707|13.6979|0.0820|66.5526|2.4699|2.566|389|31649|24/24|yes|
|5|mixture_rolling|20.6849|22.8314|547.9530|0.5703|13.6875|0.0903|73.7610|2.8346|2.293|389|31649|24/24|yes|
|6|proposed|21.0916|23.2260|557.4238|0.5703|13.6875|0.0903|72.7628|2.8357|1.912|389|31649|24/24|yes|

## Best By Method

|method|scenario|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|deterministic_headroom|1|0.0000|52.5725|1261.7405|0.5846|14.0313|0.9800|114.0800|52.1561|0.003|186|346|24/24|yes|
|empirical_cvar|2|15.9389|18.8944|453.4658|0.5855|14.0521|0.1207|74.3425|3.8248|2.627|381|31639|24/24|yes|
|single_tv|3|22.6470|24.6566|591.7584|0.6133|14.7187|0.0825|64.4198|2.6193|2.164|381|31639|24/24|yes|
|mixture_static|4|21.7040|23.5947|566.2727|0.5707|13.6979|0.0820|66.5526|2.4699|2.566|389|31649|24/24|yes|
|mixture_rolling|5|20.6849|22.8314|547.9530|0.5703|13.6875|0.0903|73.7610|2.8346|2.293|389|31649|24/24|yes|
|proposed|6|21.0916|23.2260|557.4238|0.5703|13.6875|0.0903|72.7628|2.8357|1.912|389|31649|24/24|yes|

## Proposed Advantage

|baseline|EENS reduction|LOLP reduction|security-violation reduction|
|---|---:|---:|---:|
|deterministic_headroom|55.8%|2.4%|90.8%|
|empirical_cvar|-22.9%|2.6%|25.2%|
|single_tv|5.8%|7.0%|-9.5%|
|mixture_static|1.6%|0.1%|-10.1%|
|mixture_rolling|-1.7%|-0.0%|0.0%|

## Notes

- EDNS is computed as EENS divided by the evaluated rolling hours, so it reports the average unserved power in the out-of-sample reliability audit.
- Scheduled shedding is the preventive load-shedding decision returned by the optimization model before out-of-sample forecast-error realizations are audited.
- EENS is computed as planned load shedding plus the minimum emergency load shedding needed to restore generator reserve and line constraints under sampled forecast errors.
- LOLP is the sample probability that planned or emergency load shedding is positive; LOLE is the sum of hourly LOLP values over the evaluated rolling horizon.
- `security viol.` is the probability of any raw operating-limit violation before emergency corrective shedding.
- `max viol.` is the largest positive post-event physical-constraint exceedance over the sampled audit errors; `mean total viol.` averages the sum of positive generator and line exceedances per test case.
- LP variables and constraints count the optimization model sent to the LP solver before presolve.
- The tiny tie-breaker only stabilizes reserve/generation choices; the reported shedding remains the primary metric.
