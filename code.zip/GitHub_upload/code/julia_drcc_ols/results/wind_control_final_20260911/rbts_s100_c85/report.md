# MA-DRCC-OLS Experiment Report

- Generated at: 2026-09-11 17:14:14
- Model: mixture phi-divergence DRCC-OLS with predictive-rolling weights and outer L1 weight ambiguity
- Divergence: tv
- Buses/generators/lines: 6/10/9
- Data rows used by loader: 8736
- GMM implementation: diagonal-covariance Gaussian mixture fitted on historical nodal net-injection errors.
- Predictive error proxy: previous_error.
- Global empirical/single-TV support mode: budgeted.
- Wind data screening: 0 corrected events across 69999 observations (0.0%).
- Load data screening: 0 corrected events across 104832 observations (0.0%).
- GMM weights: 0.4627, 0.1689, 0.3684
- Best scenario id: 5 (mixture_rolling, complete comparison row)
- Best scheduled pre-contingency load shedding: 2.3895 MW
- Best OOS EENS over evaluated hours: 172.0455 MWh
- Best average OOS LOLP: 0.2361

## Wind Data Quality

|source|capacity MW|obs.|missing/nonfinite|negative|above cap.|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|Wind farm site 5 (Nominal capacity-36MW).xlsx|36.00|69999|0|0|0|0|2|0.0000|

## Load Data Quality

|source|bus|obs.|missing/nonfinite|negative|isolated spikes|large jumps flagged|cleaned share|
|---|---:|---:|---:|---:|---:|---:|---:|

## Scenario Summary

|scenario|method|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|1|deterministic_headroom|0.0000|2.4007|172.8540|0.3398|24.4688|0.7394|6.2895|2.3350|0.001|67|114|72/72|yes|
|2|empirical_cvar|2.7631|2.7631|198.9432|0.2639|19.0000|0.0000|0.0000|0.0000|0.189|294|9913|72/72|yes|
|3|single_tv|3.1548|3.1548|227.1481|0.3056|22.0000|0.0000|0.0000|0.0000|0.216|294|9913|72/72|yes|
|4|mixture_static|2.8535|2.8535|205.4494|0.2917|21.0000|0.0000|0.0000|0.0000|0.202|302|9923|72/72|yes|
|5|mixture_rolling|2.3895|2.3895|172.0455|0.2361|17.0000|0.0001|0.0134|0.0000|0.224|302|9923|72/72|yes|
|6|proposed|2.4936|2.4936|179.5401|0.2639|19.0000|0.0000|0.0000|0.0000|0.211|302|9923|72/72|yes|

## Best By Method

|method|scenario|Scheduled shedding MW|EDNS MW|EENS MWh|LOLP|LOLE h|security viol.|max viol. MW|mean total viol. MW|avg solve s|LP vars|LP cons.|optimal/runs|complete|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
|deterministic_headroom|1|0.0000|2.4007|172.8540|0.3398|24.4688|0.7394|6.2895|2.3350|0.001|67|114|72/72|yes|
|empirical_cvar|2|2.7631|2.7631|198.9432|0.2639|19.0000|0.0000|0.0000|0.0000|0.189|294|9913|72/72|yes|
|single_tv|3|3.1548|3.1548|227.1481|0.3056|22.0000|0.0000|0.0000|0.0000|0.216|294|9913|72/72|yes|
|mixture_static|4|2.8535|2.8535|205.4494|0.2917|21.0000|0.0000|0.0000|0.0000|0.202|302|9923|72/72|yes|
|mixture_rolling|5|2.3895|2.3895|172.0455|0.2361|17.0000|0.0001|0.0134|0.0000|0.224|302|9923|72/72|yes|
|proposed|6|2.4936|2.4936|179.5401|0.2639|19.0000|0.0000|0.0000|0.0000|0.211|302|9923|72/72|yes|

## Proposed Advantage

|baseline|EENS reduction|LOLP reduction|security-violation reduction|
|---|---:|---:|---:|
|deterministic_headroom|-3.9%|22.3%|100.0%|
|empirical_cvar|9.8%|0.0%|tie|
|single_tv|21.0%|13.6%|tie|
|mixture_static|12.6%|9.5%|tie|
|mixture_rolling|-4.4%|-11.8%|100.0%|

## Notes

- EDNS is computed as EENS divided by the evaluated rolling hours, so it reports the average unserved power in the out-of-sample reliability audit.
- Scheduled shedding is the preventive load-shedding decision returned by the optimization model before out-of-sample forecast-error realizations are audited.
- EENS is computed as planned load shedding plus the minimum emergency load shedding needed to restore generator reserve and line constraints under sampled forecast errors.
- LOLP is the sample probability that planned or emergency load shedding is positive; LOLE is the sum of hourly LOLP values over the evaluated rolling horizon.
- `security viol.` is the probability of any raw operating-limit violation before emergency corrective shedding.
- `max viol.` is the largest positive post-event physical-constraint exceedance over the sampled audit errors; `mean total viol.` averages the sum of positive generator and line exceedances per test case.
- LP variables and constraints count the optimization model sent to the LP solver before presolve.
- The tiny tie-breaker only stabilizes reserve/generation choices; the reported shedding remains the primary metric.
