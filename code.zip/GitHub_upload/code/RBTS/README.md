Input files are kept separately. See ../../docs/DATA.md and ../../data_manifest.json.
