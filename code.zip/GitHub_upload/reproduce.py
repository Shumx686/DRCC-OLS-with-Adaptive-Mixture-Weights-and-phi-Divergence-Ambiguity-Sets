"""Portable entry points for checking, reporting and replicating archived experiments."""
from pathlib import Path
import argparse,csv,datetime,hashlib,json,os,shutil,subprocess,sys,tomllib

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT/'code/julia_drcc_ols'
MAIN=PROJECT/'results/wind_control_final_20260911'
SUPP=PROJECT/'results/review_supplement_20260913'

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readcsv(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def data_check():
    failures=[]
    for row in json.loads((ROOT/'data_manifest.json').read_text(encoding='utf-8')):
        p=ROOT/row['path']
        if not p.is_file() or digest(p)!=row['sha256']:failures.append(row['path'])
    if failures:raise RuntimeError('Missing or different input files:\n'+'\n'.join(failures)+'\nUse: python reproduce.py install-data --source PATH')
def install_data(source):
    for row in json.loads((ROOT/'data_manifest.json').read_text(encoding='utf-8')):
        relative=Path(row['path']).relative_to('code');p=source/relative;q=ROOT/row['path']
        if not p.is_file() or digest(p)!=row['sha256']:raise RuntimeError('Input hash mismatch: '+str(p))
        if q.exists() and digest(q)!=row['sha256']:raise RuntimeError('Refusing to overwrite different input: '+str(q))
    for row in json.loads((ROOT/'data_manifest.json').read_text(encoding='utf-8')):
        q=ROOT/row['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/Path(row['path']).relative_to('code'),q)
    data_check();print('All 13 input files installed and verified.')
def verify():
    manifest=json.loads((ROOT/'checksums.json').read_text(encoding='utf-8'))
    for row in manifest:
        p=ROOT/row['path']
        if not p.is_file() or digest(p)!=row['sha256']:raise RuntimeError('Distributed file changed: '+row['path'])
    rows=readcsv(MAIN/'manifest.csv');assert len(rows)==18
    statuses={};total=0
    for row in rows:
        cfg=tomllib.loads((ROOT/row['config_path']).read_text(encoding='utf-8-sig'))
        d=readcsv(ROOT/row['result_dir']/'dispatch_results.csv')
        assert len(d)==6*int(row['eval_hours'])
        assert cfg['data']['wind_error_multiplier']==float(row['wind_error_multiplier'])
        assert cfg['data']['conventional_capacity_scale']==float(row['conventional_capacity_scale'])
        assert cfg['experiment']['comparison_methods']==['deterministic_headroom','empirical_cvar','single_tv','mixture_static','mixture_rolling','proposed']
        for x in d:statuses[x['status']]=statuses.get(x['status'],0)+1
        total+=len(d)
    assert total==5184
    sm=json.loads((SUPP/'manifest.json').read_text(encoding='utf-8'));expected={(v['id'],str(t)) for vs in sm.values() for v in vs for t in v['hours']}
    d=readcsv(SUPP/'all_hourly.csv');assert len(d)==2106 and {(x['variant'],x['t']) for x in d}==expected
    print(json.dumps({'files_verified':len(manifest),'main_cells':len(rows),'main_method_hours':total,'main_statuses':statuses,'supplement_variants':sum(map(len,sm.values())),'supplement_method_hours':len(d)},indent=2))
def run(cmd,cwd=ROOT,env=None):
    print('Running:',subprocess.list2cmdline([str(x) for x in cmd]),flush=True)
    subprocess.run([str(x) for x in cmd],cwd=cwd,env=env,check=True)
def new_output(name,kind,dry):
    name=name or kind+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    if not name or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in name):raise ValueError('Output name must contain only letters, numbers, underscore or hyphen.')
    out=PROJECT/'results/replications'/name
    if out.exists():raise FileExistsError('Choose a new output name: '+str(out))
    if not dry:out.mkdir(parents=True)
    return out
def replicate_main(args):
    rows=readcsv(MAIN/'manifest.csv')
    if args.case:
        rows=[r for r in rows if r['case_id']==args.case]
        if not rows:raise ValueError('Unknown case: '+args.case)
    out=new_output(args.name,'main',args.dry_run)
    for row in rows:
        original=ROOT/row['config_path']
        cfg=tomllib.loads(original.read_text(encoding='utf-8-sig'))
        print(row['case_id'],'hours=',row['eval_hours'],'output=',out/row['case_id'])
        if args.dry_run:continue
        text=original.read_text(encoding='utf-8-sig')
        import re
        value=(out.relative_to(PROJECT/'results')/row['case_id']).as_posix()
        text,n=re.subn(r'^output_subdir\s*=.*$',lambda m:'output_subdir = '+json.dumps(value),text,flags=re.M)
        assert n==1
        path=out/(row['case_id']+'.toml');path.write_text(text,encoding='utf-8')
        run([args.julia,'--startup-file=no','--threads=1','--project='+str(PROJECT),PROJECT/'scripts/run_experiment_no_update.jl',path])
def replicate_supplement(args):
    out=new_output(args.name,'supplement',args.dry_run)
    print('Supplement group:',args.group,'output:',out)
    if args.dry_run:return
    shutil.copy2(SUPP/'manifest.json',out/'manifest.json')
    env=os.environ.copy();env['DRCC_SUPPLEMENT_OUTPUT']=str(out)
    run([args.julia,'--startup-file=no','--threads=1','--project='+str(PROJECT),PROJECT/'scripts/review_supplement.jl',args.group],env=env)
def rebuild():
    """Recompute reports in a new workspace; saved reference results stay intact."""
    target=ROOT/'outputs'/('rebuild_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
    target.mkdir(parents=True,exist_ok=False)
    project=target/'code/julia_drcc_ols'
    shutil.copytree(PROJECT,project,ignore=shutil.ignore_patterns('replications','__pycache__'))
    (target/'paper/auto_figures').mkdir(parents=True)
    scripts=project/'scripts';main=project/'results/wind_control_final_20260911';report=project/'results/wind_control_final_report'
    def py(name,*args):run([sys.executable,scripts/name,*args],cwd=target)
    py('check_capacity_grid_consistency.py',main)
    check=json.loads((main/'grid_consistency.json').read_text(encoding='utf-8'))
    assert not check['issues'] and all(x['status']=='complete' for x in check['availability'])
    py('report_capacity_wind_stress.py','--manifest',main/'manifest.csv','--output-dir',report)
    py('summarize_control_common.py','--report-dir',report)
    py('summarize_control_components.py','--report-dir',report)
    py('summarize_control_checks.py','--root',main,'--report-dir',report)
    py('refine_paper_presentation.py','--report-dir',report)
    py('report_review_supplement.py')
    py('verify_review_supplement.py')
    print('Reports and figures:',target)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    for name in ['verify','check-data','rebuild']:sub.add_parser(name)
    p=sub.add_parser('install-data');p.add_argument('--source',type=Path,required=True)
    p=sub.add_parser('main');p.add_argument('--case')
    q=sub.add_parser('supplement');q.add_argument('--group',choices=['sensitivity','chronological_rbts','chronological_rts79'],required=True)
    for s in [p,q]:s.add_argument('--name');s.add_argument('--julia',default='julia');s.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    if args.command=='verify':verify()
    elif args.command=='install-data':install_data(args.source.resolve())
    elif args.command=='check-data':data_check();print('Input hashes verified.')
    elif args.command=='rebuild':verify();rebuild()
    else:
        if not args.dry_run:data_check()
        if args.command=='main':replicate_main(args)
        else:replicate_supplement(args)
