# 使用说明

本仓库提供考虑自适应混合权重与 φ-散度分布不确定集的分布鲁棒机会约束最优切负荷模型，以及论文实验所用的配置、结果和复现脚本。完整方法与实验范围见论文；运行命令见 [英文 README](README.md)。

## 验证结果并生成图表

下载并解压 `code.zip`，在包含 `reproduce.py` 的目录打开终端。使用 Python 3.11 或更高版本运行：

```sh
python reproduce.py verify
python -m pip install -r requirements.txt
python reproduce.py rebuild
```

第一条命令检查文件完整性及实验记录。后两条命令安装绘图依赖，并从已保存结果重新生成表格和图片，无需安装 Julia 或准备原始输入数据。输出位于 `outputs/rebuild_<时间戳>/`。

## 重新运行实验

实验使用 Julia 1.12.1。先准备包含 `RBTS/` 和 `RTS_79/` 两个子目录的输入数据目录，再安装依赖并导入数据：

```sh
julia --project=code/julia_drcc_ols -e "using Pkg; Pkg.instantiate()"
python reproduce.py install-data --source /path/to/inputs
python reproduce.py main --dry-run
```

将 `/path/to/inputs` 替换为实际的数据目录路径。文件名称、来源和校验要求见 [数据说明](docs/DATA.md)。导入时会核对 13 个输入文件的 SHA-256；新实验结果写入 `results/replications/` 下单独命名的目录。

## 结果口径

主实验包含 18 个压力工况和 5,184 条方法—小时记录，补充实验包含 70 个变体和 2,106 条记录。求解状态与逐小时结果一并保留。

同小时实际未供电量（ENS）包含预防性切负荷和误差实现后的应急切负荷；未来误差扰动下的期望未供电量（EENS）用于评估固定调度方案对后续误差的敏感性。后者属于条件压力测试，不能直接解释为年可靠性指标。共同有效小时上的比较需结合求解覆盖率及弃风可实施性检查理解，详见 [实验协议](docs/PROTOCOL.md)。

请保留压缩包内的完整目录结构和说明文件，`verify` 会检查清单中列出的每个文件。原始输入数据由各自的数据提供方分发，不包含在代码包中。
