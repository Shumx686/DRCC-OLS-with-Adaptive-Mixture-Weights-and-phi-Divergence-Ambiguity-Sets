# Wind uncertainty / conventional capacity stress report

Manifest: `code/julia_drcc_ols/results/wind_control_final_20260911/manifest.csv`
Manifest SHA-256: `358ec655a6d7ce3e3fe490ae44df710b1a079465c6e74552fe79092e84d23dde`

The saved manifest and configuration files define the complete comparison set. Coverage includes every planned run; energy and security summaries use the valid outcomes described below.

## Complete planned coverage

| System | Method | Optimal/planned hours | Audited/planned hours | Planned ENS (MWh) | Realized emergency ENS (MWh) | Realized total ENS (MWh) | Raw violation (%) | Residual violation (%) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| RTS79 | Det. + headroom | 216/216 | 216/216 | 9,767.72 | 5,950.27 | 15,718.00 | 83.80 | 46.30 |
| RTS79 | Empirical CVaR | 72/216 | 72/216 | -- | -- | -- | -- | -- |
| RTS79 | Single-TV | 72/216 | 72/216 | -- | -- | -- | -- | -- |
| RTS79 | Mixture-static | 72/216 | 72/216 | -- | -- | -- | -- | -- |
| RTS79 | Mixture-rolling | 72/216 | 72/216 | -- | -- | -- | -- | -- |
| RTS79 | Proposed | 72/216 | 72/216 | -- | -- | -- | -- | -- |
| RBTS | Det. + headroom | 648/648 | 648/648 | 478.99 | 1,639.07 | 2,118.06 | 63.89 | 25.00 |
| RBTS | Empirical CVaR | 648/648 | 648/648 | 4,153.07 | 0 | 4,153.07 | 0 | 0 |
| RBTS | Single-TV | 648/648 | 648/648 | 4,360.96 | 0 | 4,360.96 | 0 | 0 |
| RBTS | Mixture-static | 648/648 | 648/648 | 4,096.60 | 0 | 4,096.60 | 0 | 0 |
| RBTS | Mixture-rolling | 648/648 | 648/648 | 3,048.88 | 0 | 3,048.88 | 0 | 0 |
| RBTS | Proposed | 648/648 | 648/648 | 3,590.76 | 0 | 3,590.76 | 0 | 0 |

## Definitions and interpretation

- Each dispatch interval is one hour. Planned ENS equals scheduled shedding MW times one hour. Realized emergency ENS replays the same hour's realized error; realized total ENS is their sum. CSV `*_eens_mwh` names retain the engine's historical naming, but unprefixed values here are realized ENS. Only `future_*` metrics average over the next 96 errors and have the interpretation of a perturbation-audit EENS.
- ENS totals describe the planned finite stress exposures, not annual EENS. Adjacent future audit blocks can overlap. No independence-based confidence intervals or statistical significance claims are made.
- Raw violation is the chronological frequency of any generator/reserve/line violation before emergency correction. Residual security is the frequency of remaining positive security slack after corrective load shedding.
- OPTIMAL plus available primal values defines a solved dispatch. Complete reliability metrics are additionally required for the primary energy and security comparisons. A failed or missing planned hour makes the corresponding complete-cell metric missing; `observed_*` fields retain partial data.
- A positive corrective residual means the emergency model has not restored all security constraints. ENS and residual security must therefore be interpreted together. The wind-deliverability diagnostic additionally counts hours and energy where scheduled wind curtailment exceeds realized wind availability; these are not certified as physically feasible merely because residual generator/line slack is zero.
- `paired_comparisons.csv` reports proposed-minus-baseline differences on identical hours; negative differences favor the proposed method. Primary differences require every planned pair. Counts of lower/tied/higher results preserve all ties, including common zeros.
- Figure colors for ENS use log(1+x) only where needed; annotations and CSV values remain in MWh. Methods appear in separate rows so overlapping curves cannot hide equal outcomes.

## Reproduction

```powershell
python "code/julia_drcc_ols/scripts/report_capacity_wind_stress.py" --manifest "code/julia_drcc_ols/results/wind_control_final_20260911/manifest.csv"
```

## Planned runs

| Run | Wind multiplier s | Capacity c | Calendar days | Planned hours | Seed |
|---|---:|---:|---:|---:|---:|
| rts79_s100_c100 | 1 | 1 | 31 | 24 | 20260515 |
| rts79_s100_c85 | 1 | 0.85 | 31 | 24 | 20260515 |
| rts79_s100_c70 | 1 | 0.7 | 31 | 24 | 20260515 |
| rts79_s150_c100 | 1.5 | 1 | 31 | 24 | 20260515 |
| rts79_s150_c85 | 1.5 | 0.85 | 31 | 24 | 20260515 |
| rts79_s150_c70 | 1.5 | 0.7 | 31 | 24 | 20260515 |
| rts79_s200_c100 | 2 | 1 | 31 | 24 | 20260515 |
| rts79_s200_c85 | 2 | 0.85 | 31 | 24 | 20260515 |
| rts79_s200_c70 | 2 | 0.7 | 31 | 24 | 20260515 |
| rbts_s100_c100 | 1 | 1 | 31;151;271 | 72 | 20260515 |
| rbts_s100_c85 | 1 | 0.85 | 31;151;271 | 72 | 20260515 |
| rbts_s100_c70 | 1 | 0.7 | 31;151;271 | 72 | 20260515 |
| rbts_s150_c100 | 1.5 | 1 | 31;151;271 | 72 | 20260515 |
| rbts_s150_c85 | 1.5 | 0.85 | 31;151;271 | 72 | 20260515 |
| rbts_s150_c70 | 1.5 | 0.7 | 31;151;271 | 72 | 20260515 |
| rbts_s200_c100 | 2 | 1 | 31;151;271 | 72 | 20260515 |
| rbts_s200_c85 | 2 | 0.85 | 31;151;271 | 72 | 20260515 |
| rbts_s200_c70 | 2 | 0.7 | 31;151;271 | 72 | 20260515 |

## Retained files

- `hourly_audit.csv`: every planned method-hour, including missing rows and exact source statuses.
- `window_summary.csv`: every fixed window by method.
- `grid_summary.csv`: all wind/capacity cells by method.
- `method_summary.csv`: planned full-grid exposure by method.
- `paired_comparisons.csv`: paired deltas and lower/tied/higher counts, with planned denominators.
- `provenance.json`: source hashes and reporting definitions.
