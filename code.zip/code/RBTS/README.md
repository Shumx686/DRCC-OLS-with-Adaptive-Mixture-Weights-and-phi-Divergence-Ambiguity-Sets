# RBTS inputs

The input filenames and checksums are listed in [data_manifest.json](../../data_manifest.json). See [Input data](../../docs/DATA.md) for sources and installation instructions.
