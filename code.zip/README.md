# Adaptive-mixture distributionally robust load shedding

Code and numerical results for **Distributionally Robust Chance-Constrained Optimal Load Shedding with Adaptive Mixture Weights and phi-Divergence Ambiguity Sets**.

The model uses a Gaussian mixture model to identify recurring wind forecast-error regimes. Local phi-divergence ambiguity sets represent uncertainty within each regime, while an outer L1 set protects the updated mixture weights. Total variation gives a linear program; modified chi-square divergence gives a second-order cone program.

[中文说明](README.zh-CN.md) · [Experiment protocol](docs/PROTOCOL.md) · [Input data](docs/DATA.md)

## Getting started

Download and extract `code.zip`, then open a terminal in the directory containing `reproduce.py`. Python 3.11 or later is required.

Check the code, configurations, and recorded results:

```sh
python reproduce.py verify
```

This command uses only the Python standard library. The reference results cover 18 stress-grid cases with 5,184 method-hour outcomes, plus 70 supplementary variants with 2,106 outcomes. All solver statuses are included.

## Rebuild tables and figures

```sh
python -m pip install -r requirements.txt
python reproduce.py rebuild
```

The reports are calculated from the recorded results, so this step requires neither Julia nor the original input data. Each run creates `outputs/rebuild_<timestamp>/`, with figures and LaTeX table fragments in `paper/` and CSV reports in `code/julia_drcc_ols/results/`. The saved reference results remain available for comparison.

## Run the experiments

The recorded experiments used Julia 1.12.1. Dependency versions are specified in `code/julia_drcc_ols/Manifest.toml`.

```sh
julia --project=code/julia_drcc_ols -e "using Pkg; Pkg.instantiate()"
python reproduce.py install-data --source /path/to/inputs
python reproduce.py check-data
```

The input directory must contain `RBTS/` and `RTS_79/`. The installer checks all 13 files against `data_manifest.json` before copying them. See [Input data](docs/DATA.md) for sources and file requirements.

Preview the main experiment configurations, run one case, or run the full grid:

```sh
python reproduce.py main --dry-run
python reproduce.py main --case rbts_s100_c100 --name rbts_replication
python reproduce.py main --name main_replication
```

Run a supplementary experiment group:

```sh
python reproduce.py supplement --group sensitivity --name sensitivity_replication
python reproduce.py supplement --group chronological_rbts --name rbts_chronology
python reproduce.py supplement --group chronological_rts79 --name rts79_chronology
```

Use a new name for each run. Results are written to `code/julia_drcc_ols/results/replications/<name>/`. The commands use the saved configurations and supplementary manifest, with output paths redirected to the new directory. Julia runs with one thread; the supplementary runner also sets one BLAS thread. Solve times can vary across machines.

## Repository structure

| Path | Contents |
|---|---|
| `reproduce.py` | Commands for verification, data installation, report generation, and experiment runs |
| `code/julia_drcc_ols/src/DRCCOLS.jl` | Optimization model and evaluation routines |
| `code/julia_drcc_ols/config/` | RBTS and RTS79 configuration templates |
| `code/julia_drcc_ols/scripts/` | Experiment runners and reporting scripts |
| `code/julia_drcc_ols/results/wind_control_final_20260911/` | Main experiment: 18 configurations, run manifest, and hourly results |
| `code/julia_drcc_ols/results/wind_control_final_report/` | Aggregate reports and source-file checksums |
| `code/julia_drcc_ols/results/review_supplement_20260913/` | Supplementary experiment manifest and results |
| `data_manifest.json` | Input filenames, sizes, and SHA-256 checksums |
| `checksums.json` | SHA-256 checksums for the distributed files |

The dated directories identify the reference experiment runs. Main experiments use the 18 TOML files listed in the saved manifest; the two files in `config/` are templates. Use `reproduce.py` to run experiments. The lower-level `run_wind_isolation.jl` records how the original grid was constructed.

## Interpreting the results

The experiments examine wind forecast uncertainty and conventional-capacity scarcity under controlled conditions. Same-hour realized energy not served (ENS) and future-error expected energy not served (EENS) measure different outcomes. Comparisons on common successful hours should be read alongside solver coverage and the wind-curtailment admissibility checks. The [experiment protocol](docs/PROTOCOL.md) defines these quantities and the scope of the results.

Original input data are distributed by their respective providers and are not included in `code.zip`. Their sources are listed in [Input data](docs/DATA.md).
