# Generated figures and tables

Run `python reproduce.py rebuild` from the repository root to generate figures and LaTeX table fragments. Each run writes them to `outputs/rebuild_<timestamp>/paper/`. The manuscript is provided separately.
