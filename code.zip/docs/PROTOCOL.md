# Experiment protocol

## Main experiment

The main comparison combines two systems, RBTS and RTS79, with wind-residual multipliers of 1, 1.5, and 2 and conventional-capacity factors of 1, 0.85, and 0.7. These combinations form 18 stress-grid cases.

The first 720 hours are used for offline fitting and support construction. RBTS is evaluated on days 31, 151, and 271, giving 72 hours per case. RTS79 is evaluated on day 31, giving 24 hours per case. Each case compares deterministic dispatch with physical headroom, empirical CVaR, Single-TV, static mixture, rolling mixture, and the proposed protected mixture.

The main settings are K=3 regimes, a risk level of epsilon=0.05, a total cap of 240 representative samples, local TV radii rho=0.05, and an outer weight radius delta_w=0.05 for the proposed method. Total variation uses the unscaled L1 convention. The saved TOML files specify the settings for each method and case.

Wind residuals are amplified before the resulting wind generation is clipped to physical bounds. The residual multiplier therefore does not equal the ratio of observed standard deviations. Demand is known in both dispatch and replay. Devices with zero active-power capacity are excluded from the active-power control set for all methods.

## Energy, security, and coverage

The reference records contain all 5,184 planned method-hour outcomes: 4,464 optimal, 715 infeasible, 3 time-limit, and 2 other failures. Energy and security comparisons use optimal dispatches with the required replay metrics. Infeasibility, a time limit, and other failures remain separate solver statuses.

Same-hour realized energy not served (ENS) is the sum of preventive shedding and additional emergency shedding after the observed error is applied. A secondary evaluation applies the next 96 error vectors to each fixed dispatch and reports future-error expected energy not served (EENS). These overlapping error blocks provide a conditional stress test rather than independent samples for an annual reliability estimate.

Pre-correction violations measure breaches of reserve or line limits before emergency correction. Residual violations measure security constraints that remain unsatisfied after correction. Comparisons on common successful hours are reported together with full-grid solver coverage. A separate admissibility check identifies scheduled wind curtailment that exceeds realized wind availability.

## Supplementary experiments

The 70-variant manifest covers ambiguity radii, mixture weights, regime count, support size and selection, rolling windows, regularization, divergence geometry, feasibility diagnostics, and chronological replay.

The chronological replay evaluates every hour of days 32–38 using the fixed offline supports. RBTS uses the central stress condition, s=1.5 and c=0.85; RTS79 uses s=1 and c=0.85. The common physically admissible comparison contains 168 RBTS hours and 107 RTS79 hours. All recorded outcomes remain in `all_hourly.csv`, including hours that fail the scheduled-curtailment admissibility check.

The 60-second dispatch limit applies to the HiGHS LP runs. Modified chi-square experiments use Clarabel defaults. Equal numerical divergence radii do not imply equal statistical coverage, and recorded solve times depend on the computing environment.

## Reproduction commands

`reproduce.py main` reads the saved grid configurations. `reproduce.py supplement` reads the saved supplementary manifest. Both write new results to a separately named directory, retaining the reference results for comparison. Input files are checked against `data_manifest.json`.

`reproduce.py rebuild` calculates reports from the recorded CSV files without running a solver. It uses the same missing-value and common-hour conventions as the reference reports. Earlier diagnostic records are retained for traceability; the complete final replay supplies the chronological comparison.
