# Input data

The original network, load, and wind files are required to run the optimization experiments. Tables and figures can be rebuilt from the recorded results without these inputs.

`data_manifest.json` lists the 13 input files, their sizes, and SHA-256 checksums:

- **RBTS:** `RBTS.m`, `BUS_LOADS.csv`, `SYSTEM_LOADS.csv`, and the wind-farm site 5 workbook.
- **RTS79:** `RTS.m`, `BUS_LOADS.csv`, `SYSTEM_LOADS.csv`, and the wind-farm site 1–6 workbooks.

Place the files in `RBTS/` and `RTS_79/` subdirectories, preserving their original filenames, then run:

```sh
python reproduce.py install-data --source /path/to/inputs
```

The installer verifies all files before copying them. If a file differs from the recorded input, the command reports a checksum mismatch. This check also prevents an existing, different file from being overwritten.

## Sources

- Yongbao Chen and Junjie Xu, *Solar and wind power data from the Chinese State Grid Renewable Energy Generation Forecasting Competition*, Scientific Data 9, 577 (2022). [Dataset description and data links](https://www.nature.com/articles/s41597-022-01696-6).
- Grigg et al., *The IEEE Reliability Test System-1996*, IEEE Transactions on Power Systems 14(3), 1010–1020 (1999). [Publication](https://doi.org/10.1109/59.780914).
- Josif Figueroa, Kush Bubbar and Greg Young-Morris, *An Open-Source Tool for Composite Power System Reliability Assessment in Julia*, Energies 17(20), 5023 (2024). [Benchmark implementation and references](https://www.mdpi.com/1996-1073/17/20/5023).

The network cases use MATPOWER format. The checksums identify the specific input versions used in the experiments; current upstream downloads may differ. The wind and load records come from different calendar years and are aligned as a synthetic benchmark. The model code performs the configured preprocessing, so replication should start from the input files listed in the manifest rather than independently cleaned versions.

Input data are not included in `code.zip`. Redistribution and reuse are subject to the terms of the original data providers.
